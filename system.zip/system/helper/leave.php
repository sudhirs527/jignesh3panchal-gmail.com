<?php
/*
Plugin Name: WFH, Rota system for PL
Description: A custom plugin for interacting with a custom REST API.
Site url: https://wewant360.com/
Author: Wewant360
Author URI: https://wewant360.com/
*/
?>

<?php
function checkAvailability($data=array()) {

    $total_leave = $data['total_leave'];
    $applied_leave = $data['applied_leave'];
    $current_month = date('m',strtotime($data['to_date']));

    $available_leave = canLeave($data);
    if($applied_leave<=$available_leave)
    {
        $return['allow']=1;
    }
    else
    {
        $return['allow']=0;
    }
    $return['applied_leave'] = $applied_leave;
    $return['available_leave'] = $available_leave;

    return $return;
}
function canLeave($data=array())
{
    $total_leave = $data['total_leave'];
    $taken_leave = $data['taken_leave'];
    $current_month = date('m',strtotime($data['to_date']));

    $state = getStateFromArea($data['user_info']['unit']);//1 = Maharashtra, 2 = Gujarat, 3 = Delhi, 4 = Karnataka, 5 = Tamil Nadu

    $can_leave = 0;

    if($current_month=="01")
    {
        $can_leave = 2;
    }
    else if($current_month=="02")
    {
        $can_leave = 4;
    }
    else if($current_month=="03")
    {
        $can_leave = 6;
    }
    else if($current_month=="04")
    {
        $can_leave = 8;
    }
    else if($current_month=="05")
    {
        $can_leave = 10;
    }
    else if($current_month=="06")
    {
        $can_leave = 12;
    }
    else if($current_month=="07")
    {
        if($state==1)
        {
            $can_leave = 14;
        }
        else if($state==2)
        {
            $can_leave = 14;
        }
        else if($state==3)
        {
            $can_leave = 14;
        }
        else if($state==4)
        {
             $can_leave = 14;
        }
        else if($state==5)
        {
             $can_leave = 12;
        }
    }
    else if($current_month=="08")
    {
        if($state==1)
        {
            $can_leave = 16;
        }
        else if($state==2)
        {
            $can_leave = 16;
        }
        else if($state==3)
        {
            $can_leave = 15;
        }
        else if($state==4)
        {
             $can_leave = 16;
        }
        else if($state==5)
        {
             $can_leave = 12;
        }
        
    }
    else if($current_month=="09")
    {
        if($state==1)
        {
            $can_leave = 18;
        }
        else if($state==2)
        {
            $can_leave = 18;
        }
        else if($state==3)
        {
            $can_leave = 15;
        }
        else if($state==4)
        {
             $can_leave = 18;
        }
        else if($state==5)
        {
             $can_leave = 12;
        }
    }
    else if($current_month=="10")
    {
        if($state==1)
        {
            $can_leave = 20;
        }
        else if($state==2)
        {
            $can_leave = 20;
        }
        else if($state==3)
        {
            $can_leave = 15;
        }
        else if($state==4)
        {
             $can_leave = 18;
        }
        else if($state==5)
        {
             $can_leave = 12;
        }
    }
    else if($current_month=="11")
    {
        if($state==1)
        {
            $can_leave = 21;
        }
        else if($state==2)
        {
            $can_leave = 21;
        }
        else if($state==3)
        {
            $can_leave = 15;
        }
        else if($state==4)
        {
             $can_leave = 18;
        }
        else if($state==5)
        {
             $can_leave = 12;
        }
    }
    else if($current_month=="12")
    {
        if($state==1)
        {
            $can_leave = 21;
        }
        else if($state==2)
        {
            $can_leave = 21;
        }
        else if($state==3)
        {
            $can_leave = 15;
        }
        else if($state==4)
        {
            $can_leave = 18;
        }
        else if($state==5)
        {
            $can_leave = 12;
        }
    }

    if(!empty($data['prev_year_pl_leave']))
    {
        $can_leave = $can_leave + $data['prev_year_pl_leave'];
    }
    $can_leave = $can_leave - $taken_leave;
    return $can_leave;
}
function totalAvailableLeave($data=array())
{
    $total_leave = $data['total_leave'];
    $taken_leave = $data['taken_leave'];
    $current_month = date('m',strtotime($data['to_date']));

    $state = getStateFromArea($data['user_info']['unit']);//1 = Maharashtra, 2 = Gujarat, 3 = Delhi, 4 = Karnataka, 5 = Tamil Nadu

    $can_leave = 0;

    if($current_month=="01")
    {
        $can_leave = 2;
    }
    else if($current_month=="02")
    {
        $can_leave = 4;
    }
    else if($current_month=="03")
    {
        $can_leave = 6;
    }
    else if($current_month=="04")
    {
        $can_leave = 8;
    }
    else if($current_month=="05")
    {
        $can_leave = 10;
    }
    else if($current_month=="06")
    {
        $can_leave = 12;
    }
    else if($current_month=="07")
    {
        if($state==1)
        {
            $can_leave = 14;
        }
        else if($state==2)
        {
            $can_leave = 14;
        }
        else if($state==3)
        {
            $can_leave = 14;
        }
        else if($state==4)
        {
             $can_leave = 14;
        }
        else if($state==5)
        {
             $can_leave = 12;
        }
    }
    else if($current_month=="08")
    {
        if($state==1)
        {
            $can_leave = 16;
        }
        else if($state==2)
        {
            $can_leave = 16;
        }
        else if($state==3)
        {
            $can_leave = 15;
        }
        else if($state==4)
        {
             $can_leave = 16;
        }
        else if($state==5)
        {
             $can_leave = 12;
        }
        
    }
    else if($current_month=="09")
    {
        if($state==1)
        {
            $can_leave = 18;
        }
        else if($state==2)
        {
            $can_leave = 18;
        }
        else if($state==3)
        {
            $can_leave = 15;
        }
        else if($state==4)
        {
             $can_leave = 18;
        }
        else if($state==5)
        {
             $can_leave = 12;
        }
    }
    else if($current_month=="10")
    {
        if($state==1)
        {
            $can_leave = 20;
        }
        else if($state==2)
        {
            $can_leave = 20;
        }
        else if($state==3)
        {
            $can_leave = 15;
        }
        else if($state==4)
        {
             $can_leave = 18;
        }
        else if($state==5)
        {
             $can_leave = 12;
        }
    }
    else if($current_month=="11")
    {
        if($state==1)
        {
            $can_leave = 21;
        }
        else if($state==2)
        {
            $can_leave = 21;
        }
        else if($state==3)
        {
            $can_leave = 15;
        }
        else if($state==4)
        {
             $can_leave = 18;
        }
        else if($state==5)
        {
             $can_leave = 12;
        }
    }
    else if($current_month=="12")
    {
        if($state==1)
        {
            $can_leave = 21;
        }
        else if($state==2)
        {
            $can_leave = 21;
        }
        else if($state==3)
        {
            $can_leave = 15;
        }
        else if($state==4)
        {
            $can_leave = 18;
        }
        else if($state==5)
        {
            $can_leave = 12;
        }
    }

    if(!empty($data['prev_year_pl_leave']))
    {
        $can_leave = $can_leave + $data['prev_year_pl_leave'];
    }
    return $can_leave;
}
function getStateFromArea($area)
{
    //1 = Maharashtra, 2 = Gujarat, 3 = Delhi, 4 = Karnataka, 5 = Tamil Nadu
    if($area=="Mumbai" || $area == "Pune" || $area == "SaiSiddhiServices" || $area =="MonitronSecurity" || $area=="AdeccoofficeboysMumbai" || $area=="AdeccoofficeboysPune")
    {
        $state = 1;
    }
    else if($area=="Ahmedabad" || $area == "AdeccoofficeboysAhmedabad" )
    {
        $state = 2;
    }
    else if($area=="Delhi" || $area =="AdeccoofficeboysDelhi")
    {
        $state = 3;
    }
    else if($area == "Bangalore" || $area == "AdeccoofficeboysChennai")
    {
        $state = 4;
    }
    else if($area=="Coimbatore" || $area=="Chennai"  ||  $area =="AdeccoofficeboysBangalore")
    {
        $state = 5;
    }
}
