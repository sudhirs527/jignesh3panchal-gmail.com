<?php
// HTTP
define('HTTP_SERVER', 'http://125.99.122.186/attendance/');

// HTTPS
define('HTTPS_SERVER', 'http://125.99.122.186/attendance/');

// DIR
define('DIR_APPLICATION', '/usr/share/nginx/html/attendance/catalog/');
define('DIR_SYSTEM', '/usr/share/nginx/html/attendance/system/');
define('DIR_DATABASE', '/usr/share/nginx/html/attendance/system/database/');
define('DIR_LANGUAGE', '/usr/share/nginx/html/attendance/catalog/language/');
define('DIR_TEMPLATE', '/usr/share/nginx/html/attendance/catalog/view/theme/');
define('DIR_CONFIG', '/usr/share/nginx/html/attendance/system/config/');
define('DIR_IMAGE', '/usr/share/nginx/html/attendance/image/');
define('DIR_CACHE', '/usr/share/nginx/html/attendance/system/cache/');
define('DIR_DOWNLOAD', '/usr/share/nginx/html/attendance/download/');
define('DIR_LOGS', '/usr/share/nginx/html/attendance/system/logs/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'testuser');
define('DB_PASSWORD', 'admin');
define('DB_DATABASE', 'db_attendance');
define('DB_PREFIX', 'oc_');
?>
