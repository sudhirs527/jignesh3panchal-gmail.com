<?php 
//echo phpinfo();exit;
$data = file_get_contents('php://input');
$datas = json_decode($data,true);
//$handle = fopen('log.txt', 'a+'); 
//fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r($datas, true)  . "\n");
//fclose($handle);
//exit;

// $data['21463']['name'] = 'EVEREST M FARGOSE';
// $data['21463']['month_year'] = '201605';
// $data['21463']['department'] = 'P.L.D.';
// $data['21463']['emp_code'] = '21463';
// $data['21463']['present_count'] = '20.5';
// $data['21463']['absent_count'] = '0';
// $data['21463']['week_count'] = '5';
// $data['21463']['holiday_count'] = '1';
// $data['21463']['pl_cnt'] = '0';
// $data['21463']['encash'] = '0';
// $data['21463']['sl_cnt'] = '0';
// $data['21463']['cl_cnt'] = '3.5';
// $data['21463']['leave_wo_pay'] = '0';

$serverName = "192.168.0.150";
//$serverName = "agm1\AGM1";
$connectionInfo = array( "Database"=>"C001", "UID"=>"sa", "PWD"=>"1234");
$conn = sqlsrv_connect( $serverName, $connectionInfo);
if( $conn ) {
     //$dat['connection'] = 'Connection established';
     //echo "Connection established.<br />";
}else{
     //echo "Connection could not be established.<br />";
     $dat['connection'] = 'Connection could not be established';
     //echo '<pre>';
     //print_r(sqlsrv_errors());
     //exit;
     //die( print_r( sqlsrv_errors(), true));
}
//echo 'out';exit;
$total_affected = 0;
foreach($datas as $dkey => $dvalue){
	$sql = "SELECT emp_code,emp_name,ticket_no FROM dbo.empinfo WHERE ticket_no = '".$dvalue['emp_code']."' ";
	$params = array();
	$options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
	$stmt = sqlsrv_query($conn, $sql, $params, $options);
	if( $stmt === false) {
	   //echo'<pre>';
	   //print_r(sqlsrv_errors());
	   //exit;
	}
	$emp_code = 0;
	while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
	    //echo'<pre>';
	   	//print_r($row);
	   	//exit;
	    $emp_code = $row['emp_code'];
	}
	//echo 'out';exit;
	if($emp_code){
		$sql = "UPDATE [dbo].[atten] SET
			day_present = '".$dvalue['present_count']."',
			sk_leave = '".$dvalue['sl_cnt']."',
			priv_leave = '".$dvalue['pl_cnt']."',
			cas_leave = '".$dvalue['cl_cnt']."',
			wkly_off = '".$dvalue['week_count']."',
			paid_holiday = '".$dvalue['holiday_count']."',
			day_absent = '".$dvalue['absent_count']."',
			plench = '".$dvalue['encash']."'
			WHERE mnth_year = '".$dvalue['month_year']."' AND emp_code = '".$emp_code."' ";
		//echo $sql;exit;
		$stmt = sqlsrv_query($conn, $sql);
		if($stmt === false) {
     		$dat['query_error'] = json_encode(sqlsrv_errors());
     		//echo'<pre>';
	   		//print_r(sqlsrv_errors());
	   		//exit;		
		} else {
			$rows_affected = sqlsrv_rows_affected($stmt);
			$total_affected = $rows_affected + $total_affected;
			//echo'<pre>';
	   		//print_r($rows_affected);
	   		//exit;
		}
	}
	// mssql_query($sql);
}
$dat['rows_affected'] = $total_affected;
exit(json_encode($dat));
//exit;

// $sql = "SELECT emp_code,emp_name,ticket_no FROM dbo.empinfo";
// $params = array();
// $options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
// $stmt = sqlsrv_query($conn, $sql, $params, $options);
// if( $stmt === false) {
//    echo'<pre>';
//    print_r(sqlsrv_errors());
//    exit;
// }

// while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
//     echo '<pre>';
//     print_r($row);
// 	//echo $row[0].", ".$row[1]."<br />";
// }
// exit;
// $row_count = sqlsrv_num_rows($stmt);
// if ($row_count === false){
//    echo "Error in retrieveing row count.";
// } else {
//    echo $row_count;
// }
// exit;
// echo $numFields;exit;
// while( sqlsrv_fetch( $stmt )) {
//    // Iterate through the fields of each row.
//    for($i = 0; $i < $numFields; $i++) { 
//       echo sqlsrv_get_field($stmt, $i)." ";
//    }
//    echo "<br />";
// }

echo '<pre>';
print_r('Done');
exit;



// Do a simple query, select the version of 
// MSSQL and print it.

//mssql_close($link);
echo '<pre>';
print_r($data);
exit;

?>