<?php 
//echo phpinfo();exit;
//$data = file_get_contents('php://input');
//$datas = json_decode($data,true);
//$handle = fopen('log.txt', 'a+'); 
//fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r($datas, true)  . "\n");
//fclose($handle);
//exit;

// $data['21463']['name'] = 'EVEREST M FARGOSE';
// $data['21463']['month_year'] = '201605';
// $data['21463']['department'] = 'P.L.D.';
// $data['21463']['emp_code'] = '21463';
// $data['21463']['present_count'] = '20.5';
// $data['21463']['absent_count'] = '0';
// $data['21463']['week_count'] = '5';
// $data['21463']['holiday_count'] = '1';
// $data['21463']['pl_cnt'] = '0';
// $data['21463']['encash'] = '0';
// $data['21463']['sl_cnt'] = '0';
// $data['21463']['cl_cnt'] = '3.5';
// $data['21463']['leave_wo_pay'] = '0';

$serverName = "192.168.0.150";
//$serverName = "agm1\AGM1";
$connectionInfo = array( "Database"=>"C001", "UID"=>"sa", "PWD"=>"1234");
$conn = sqlsrv_connect( $serverName, $connectionInfo);
if( $conn ) {
    //echo "Connection established.<br />";
}else{
     //echo "Connection could not be established.<br />";
     $dat['connection'] = 'Connection could not be established';
     //echo '<pre>';
     //print_r(sqlsrv_errors());
     //exit;
     //die( print_r( sqlsrv_errors(), true));
}
//echo 'out';exit;
$total_affected = 0;
$final_datas = array();
$cur_month = date('m');
$cur_year = date('Y');
$compare_date = $cur_year.'-'.$cur_month.'-01';
$sql = "SELECT emp_code,emp_name,ticket_no,do_birth,do_join,date_cm,do_left,UnitID,CategoryID,gr_code,dept,DesigId,GroupId,br_code,DivisionId,NameTitle  FROM dbo.empinfo WHERE CAST(do_left as DATE) >= '".$compare_date."' ";
//echo $sql;exit;
$params = array();
$options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
$stmt = sqlsrv_query($conn, $sql, $params, $options);
if( $stmt === false) {
   //echo'<pre>';
   //print_r(sqlsrv_errors());
   //exit;
}
$emp_code = 0;
$i=0;
while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    $i++;
    // echo'<pre>';
   	// print_r($row['do_birth']->format('Y-m-d H:i:s'));
   	// exit;
   	$row['do_birth'] = $row['do_birth']->format('Y-m-d');
   	$row['do_join'] = $row['do_join']->format('Y-m-d');
   	$row['date_cm'] = $row['date_cm']->format('Y-m-d');
   	$row['do_left'] = $row['do_left']->format('Y-m-d');

   	$usql = "SELECT UnitName FROM dbo.EmpUnit WHERE UnitID = '".$row['UnitID']."' ";
	$uparams = array();
	$uoptions =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
	$ustmt = sqlsrv_query($conn, $usql, $uparams, $uoptions);
	$unit_name = '';
	while($urow = sqlsrv_fetch_array($ustmt, SQLSRV_FETCH_ASSOC)) {
	    $unit_name = $urow['UnitName'];
	}
	$row['unit_name'] = $unit_name;
	unset($row['UnitID']);

	$csql = "SELECT CategoryName FROM dbo.EmpCategory WHERE CategoryID = '".$row['CategoryID']."' ";
	$cparams = array();
	$coptions =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
	$cstmt = sqlsrv_query($conn, $csql, $cparams, $coptions);
	$category_name = '';
	while($crow = sqlsrv_fetch_array($cstmt, SQLSRV_FETCH_ASSOC)) {
	    $category_name = $crow['CategoryName'];
	}
	$row['category_name'] = $category_name;
	unset($row['CategoryID']);

	$dsql = "SELECT DesigName FROM dbo.DesigMaster WHERE DesigId = '".$row['DesigId']."' ";
	$dparams = array();
	$doptions =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
	$dstmt = sqlsrv_query($conn, $dsql, $dparams, $doptions);
	$desig_name = '';
	while($drow = sqlsrv_fetch_array($dstmt, SQLSRV_FETCH_ASSOC)) {
	    $desig_name = $drow['DesigName'];
	}
	$row['desig_name'] = $desig_name;
	unset($row['DesigId']);

	$gsql = "SELECT GroupName FROM dbo.EmpGroup WHERE GroupId = '".$row['GroupId']."' ";
	$gparams = array();
	$goptions =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
	$gstmt = sqlsrv_query($conn, $gsql, $gparams, $goptions);
	$group_name = '';
	while($grow = sqlsrv_fetch_array($gstmt, SQLSRV_FETCH_ASSOC)) {
	    $group_name = $grow['GroupName'];
	}
	$row['group_name'] = $group_name;
	unset($row['GroupId']);

   	// echo'<pre>';
   	// print_r($row);
   	// exit;
   	$final_datas[$i] = $row;
}
//echo'<pre>';
//print_r($final_datas);
//exit;
//echo 'out';exit;
$dat['final_datas'] = $final_datas;
exit(json_encode($dat));
//exit;

// $sql = "SELECT emp_code,emp_name,ticket_no FROM dbo.empinfo";
// $params = array();
// $options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
// $stmt = sqlsrv_query($conn, $sql, $params, $options);
// if( $stmt === false) {
//    echo'<pre>';
//    print_r(sqlsrv_errors());
//    exit;
// }

// while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
//     echo '<pre>';
//     print_r($row);
// 	//echo $row[0].", ".$row[1]."<br />";
// }
// exit;
// $row_count = sqlsrv_num_rows($stmt);
// if ($row_count === false){
//    echo "Error in retrieveing row count.";
// } else {
//    echo $row_count;
// }
// exit;
// echo $numFields;exit;
// while( sqlsrv_fetch( $stmt )) {
//    // Iterate through the fields of each row.
//    for($i = 0; $i < $numFields; $i++) { 
//       echo sqlsrv_get_field($stmt, $i)." ";
//    }
//    echo "<br />";
// }

echo '<pre>';
print_r('Done');
exit;



// Do a simple query, select the version of 
// MSSQL and print it.

//mssql_close($link);
echo '<pre>';
print_r($data);
exit;

?>