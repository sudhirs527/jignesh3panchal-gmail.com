<?php 
$date = date('Y-m-d');
if(!file_exists('/var/www/html/db_backup/'.$date)){
	mkdir('/var/www/html/db_backup/'.$date);
	chmod('/var/www/html/db_backup/'.$date, 0777);
}

exec('mysqldump --user=root --password=rwitc --host=125.99.122.186 db_openpay > "/var/www/html/db_backup/'.$date.'/db_openpay_bk_'.$date.'.sql" ');
exec('mysqldump --user=root --password=rwitc --host=125.99.122.186 db_attendance_1 > "/var/www/html/db_backup/'.$date.'/db_attendance_bk_'.$date.'.sql" ');
exec('mysqldump --user=root --password=rwitc --host=125.99.122.186 db_cms > "/var/www/html/db_backup/'.$date.'/db_cms_bk_'.$date.'.sql" ');
exec('mysqldump --user=root --password=rwitc --host=125.99.122.186 db_openccs > "/var/www/html/db_backup/'.$date.'/db_openccs_bk_'.$date.'.sql" ');
exec('mysqldump --user=root --password=rwitc --host=125.99.122.186 db_openccs_2017 > "/var/www/html/db_backup/'.$date.'/db_openccs_2017_bk_'.$date.'.sql" ');
exec('mysqldump --user=root --password=rwitc --host=125.99.122.186 db_openchr > "/var/www/html/db_backup/'.$date.'/db_openchr_bk_'.$date.'.sql" ');
exec('mysqldump --user=root --password=rwitc --host=125.99.122.186 db_openchr_2017 > "/var/www/html/db_backup/'.$date.'/db_openchr_2017_bk_'.$date.'.sql" ');       	    
exec('mysqldump --user=root --password=rwitc --host=125.99.122.186 db_opengym > "/var/www/html/db_backup/'.$date.'/db_opengym_bk_'.$date.'.sql" ');
exec('mysqldump --user=root --password=rwitc --host=127.0.0.1 db_members_attendance > "/var/www/html/db_backup/'.$date.'/db_members_attendance_bk_'.$date.'.sql" ');

exec('sshpass -p "x2MWXZzs9c" scp /var/www/html/db_backup/'.$date.'/db_openpay_bk_'.$date.'.sql root@64.79.95.89:/var/www/db_backup/');
exec('sshpass -p "x2MWXZzs9c" scp /var/www/html/db_backup/'.$date.'/db_attendance_bk_'.$date.'.sql root@64.79.95.89:/var/www/db_backup/');
exec('sshpass -p "x2MWXZzs9c" scp /var/www/html/db_backup/'.$date.'/db_cms_bk_'.$date.'.sql root@64.79.95.89:/var/www/db_backup/');
exec('sshpass -p "x2MWXZzs9c" scp /var/www/html/db_backup/'.$date.'/db_openccs_bk_'.$date.'.sql root@64.79.95.89:/var/www/db_backup/');
exec('sshpass -p "x2MWXZzs9c" scp /var/www/html/db_backup/'.$date.'/db_openccs_2017_bk_'.$date.'.sql root@64.79.95.89:/var/www/db_backup/');
exec('sshpass -p "x2MWXZzs9c" scp /var/www/html/db_backup/'.$date.'/db_openchr_bk_'.$date.'.sql root@64.79.95.89:/var/www/db_backup/');
exec('sshpass -p "x2MWXZzs9c" scp /var/www/html/db_backup/'.$date.'/db_openchr_2017_bk_'.$date.'.sql root@64.79.95.89:/var/www/db_backup/');
exec('sshpass -p "x2MWXZzs9c" scp /var/www/html/db_backup/'.$date.'/db_opengym_bk_'.$date.'.sql root@64.79.95.89:/var/www/db_backup/');
exec('sshpass -p "x2MWXZzs9c" scp /var/www/html/db_backup/'.$date.'/db_members_attendance_bk_'.$date.'.sql root@64.79.95.89:/var/www/db_backup/');




$srcPath = '/var/www/html/db_backup/*';
$todaysdate = date("Y-m-d");
 foreach(glob($srcPath) as $key=>$object){
    $file_dates = explode('/', $object);
    $file_date = end($file_dates);
    $datetime1 = new DateTime($todaysdate);
    $datetime2 = new DateTime($file_date);
    $interval = $datetime1->diff($datetime2);
    $days = $interval->days;
    if($days > 10){
        delete_file($object);   
    }
}
echo 'Done';
function delete_file($filename){
    exec('rm -r '.$filename.' ');
}

?>
