<?php
$link = new mysqli("localhost", "root", "", "db_attendance");


// $connect = mysql_connect('localhost','root',"");
// $connect1 = mysql_select_db("db_attendance",$connect);

$sql = "INSERT INTO `oc_transaction` SET `emp_id` = '11111' ";
$query = $link->query($sql);
//mysql_query($sql);

echo 'aaaa';exit;
?>