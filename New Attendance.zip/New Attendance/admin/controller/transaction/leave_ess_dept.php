<?php    
class ControllerTransactionLeaveEssdept extends Controller { 
	private $error = array();

	public function index() {

		date_default_timezone_set("Asia/Kolkata");
		if(isset($this->session->data['emp_code'])){
			$emp_code = $this->session->data['emp_code'];
			$is_set = $this->db->query("SELECT `is_set` FROM `oc_employee` WHERE `emp_code` = '".$emp_code."' ")->row['is_set'];	
			if($is_set == '1'){
				//$this->redirect($this->url->link('transaction/leave_ess', 'token=' . $this->session->data['token'], 'SSL'));
			} else {
				$this->redirect($this->url->link('user/password_change', 'token=' . $this->session->data['token'].'&emp_code='.$emp_code, 'SSL'));
			}
		} elseif(isset($this->session->data['is_dept'])){
			$emp_code = $this->session->data['d_emp_id'];
			$is_set = $this->db->query("SELECT `is_set` FROM `oc_employee` WHERE `emp_code` = '".$emp_code."' ")->row['is_set'];	
			if($is_set == '1'){
				//$this->redirect($this->url->link('transaction/leave_ess', 'token=' . $this->session->data['token'], 'SSL'));
			} else {
				$this->redirect($this->url->link('user/password_change', 'token=' . $this->session->data['token'].'&emp_code='.$emp_code, 'SSL'));
			}
		} elseif(isset($this->session->data['is_super'])){
			$emp_code = $this->session->data['d_emp_id'];
			$is_set = $this->db->query("SELECT `is_set` FROM `oc_employee` WHERE `emp_code` = '".$emp_code."' ")->row['is_set'];	
			if($is_set == '1'){
				//$this->redirect($this->url->link('transaction/leave_ess', 'token=' . $this->session->data['token'], 'SSL'));
			} else {
				$this->redirect($this->url->link('user/password_change', 'token=' . $this->session->data['token'].'&emp_code='.$emp_code, 'SSL'));
			}
		}

		$this->language->load('transaction/leave');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('transaction/transaction');
		$this->load->model('catalog/shift');
		$this->load->model('catalog/employee');
		$this->load->model('report/attendance');

		$this->getList();
	}

	public function insert() {
		$this->language->load('transaction/leave');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('transaction/transaction');
		$this->load->model('catalog/shift');
		$this->load->model('catalog/employee');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			// echo '<pre>';
			// print_r($this->request->post);
			// exit;
			$data = $this->request->post;
			
			$emp_data = $this->model_transaction_transaction->getEmployees_dat($data['e_name_id']);
			if(isset($emp_data['emp_code'])){
				$department = $emp_data['department'];
				$unit = $emp_data['unit'];
				$group = $emp_data['group'];
				$reporting_to = $emp_data['reporting_to'];
			} else {
				$department = '';
				$unit = '';
				$group = '';
				$reporting_to = '';
			}

			$days = $this->GetDays($data['from'], $data['to']);
			$day = array();
			foreach ($days as $dkey => $dvalue) {
	        	$dates = explode('-', $dvalue);
	        	$day[$dkey]['day'] = $dates[2];
	        	$day[$dkey]['date'] = $dvalue;
	        }

	        if($data['multi_day'] == 1){
	        	$data['leave_amount'] = '';
	        	$data['type'] = '';
	        } else {
	        	$data['days'] = '';
	        	$data['encash'] = '';
	        }

	        $batch_id_sql = "SELECT `batch_id` FROM `oc_leave_transaction_temp` ORDER BY `batch_id` DESC LIMIT 1";
			$obatch_ids = $this->db->query($batch_id_sql);
			if($obatch_ids->num_rows == 0){
				$batch_id = 1;
			} else{
				$obatch_id = $obatch_ids->row['batch_id'];
				$batch_id = $obatch_id + 1;
			}

			if($data['enable_encash'] == 0){
				$data['encash'] = '';
			}
			//echo $batch_id;exit;
			foreach($day as $dkey => $dvalue){
				$sql = "INSERT INTO `oc_leave_transaction_temp` SET 
					`emp_id` = '".$data['e_name_id']."', 
					`leave_type` = '".$data['leave_type']."',
					`date` = '".$dvalue['date']."',
					`date_cof` = '".$data['date_cof']."',
					`leave_amount` = '".$data['leave_amount']."',
					`type` = '".$data['type']."',
					`days` = '".$data['days']."',
					`encash` = '".$data['encash']."',
					`leave_reason` = '".$this->db->escape($data['leave_reason'])."',
					`a_status` = '0',
					`unit` = '".$unit."',
					`group` = '".$group."',
					`year` = '".date('Y', strtotime($dvalue['date']))."',
					`dot` = '".date('Y-m-d')."',
					`dept_name` = '".$this->db->escape($department)."',
					`reporting_to` = '".$reporting_to."',
					`batch_id` = '".$batch_id."' ";
				//echo $sql;
				//echo '<br />';
				$this->db->query($sql);
			}

			// if($data['enable_encash'] == 1 && $data['encash'] > 0 && $data['leave_type'] = 'PL'){
			// 	//$pl_bal_sql = "SELECT `pl_bal` FROM `oc_leave` WHERE emp_id = '".$data['e_name_id']."' ";
			// 	//$pl_bal_res = $this->db->query($pl_bal_sql);

			// 	$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($data['e_name_id']);
			// 	$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($data['e_name_id'], 'PL');
			// 	$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($data['e_name_id'], 'PL');
			// 	$total_bal_pl = 0;
			// 	if(isset($total_bal['pl_acc'])){
			// 		if(isset($total_bal_pro['bal_p'])){
			// 			$total_bal_pl = $total_bal['pl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
			// 		} else {
			// 			$total_bal_pl = $total_bal['pl_acc'];
			// 		}
			// 	}

			// 	if($total_bal_pl > 0){
			// 		$pl_balance = $total_bal_pl;
			// 		$pl_balance = $pl_balance - $data['encash'];
			// 		$upd_pl_bal_sql = "UPDATE `oc_leave` SET `pl_bal` = '".$pl_balance."' WHERE `emp_id` = '".$data['e_name_id']."' AND `close_status` = '0' ";
			// 		//echo $upd_pl_bal_sql;
			// 		//echo '<br />';
			// 		$this->db->query($upd_pl_bal_sql);
			// 	}
			// }

			//exit;
			$this->session->data['success'] = 'You have Inserted the Leave Transaction';	
			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}

			if (isset($this->request->get['filter_name_id'])) {
				$url .= '&filter_name_id=' . $this->request->get['filter_name_id'];
			}

			if (isset($this->request->get['filter_name_id_1'])) {
				$url .= '&filter_name_id_1=' . $this->request->get['filter_name_id_1'];
			}

			if (isset($this->request->get['filter_dept'])) {
				$url .= '&filter_dept=' . $this->request->get['filter_dept'];
			}

			if (isset($this->request->get['filter_unit'])) {
				$url .= '&filter_unit=' . $this->request->get['filter_unit'];
			}

			if (isset($this->request->get['filter_group'])) {
				$url .= '&filter_group=' . $this->request->get['filter_group'];
			}

			if (isset($this->request->get['filter_approval_1'])) {
				$url .= '&filter_approval_1=' . $this->request->get['filter_approval_1'];
			}

			if (isset($this->request->get['filter_approval_1_by'])) {
				$url .= '&filter_approval_1_by=' . $this->request->get['filter_approval_1_by'];
			}

			if (isset($this->request->get['filter_approval_2'])) {
				$url .= '&filter_approval_2=' . $this->request->get['filter_approval_2'];
			}

			if (isset($this->request->get['filter_proc'])) {
				$url .= '&filter_proc=' . $this->request->get['filter_proc'];
			}

			if (isset($this->request->get['filter_leavetype'])) {
				$url .= '&filter_leavetype=' . $this->request->get['filter_leavetype'];
			}

			$this->redirect($this->url->link('transaction/leave_ess_dept', 'token=' . $this->session->data['token'].$url.'&batch_id='.$batch_id, 'SSL'));
		}

		$this->getForm();
	}

	public function delete() {
		$this->language->load('transaction/leave');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('transaction/transaction');
		$this->load->model('catalog/shift');
		$this->load->model('catalog/employee');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $batch_id) {
				// $leav_data_sql = "SELECT * FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$batch_id."' ";
				// $leav_data = $this->db->query($leav_data_sql)->row;
				// if(isset($leav_data['encash']) && $leav_data['encash'] != ''){
				// 	$encah_leave = $leav_data['encash'];
				// 	$sql = "SELECT * FROM `oc_leave` WHERE `emp_id` = '".$leav_data['emp_id']."' AND `close_status` = '0' ";
				// 	$query1 = $this->db->query($sql);
				// 	if($query1->num_rows > 0){
				// 		if($query->row['leave_type'] == 'PL'){
				// 			//$balance = $query1->row['pl_bal'];
				// 			$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($leav_data['emp_id']);
				// 			$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($leav_data['emp_id'], 'PL');
				// 			$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($leav_data['emp_id'], 'PL');
				// 			$total_bal_pl = 0;
				// 			if(isset($total_bal['pl_acc'])){
				// 				if(isset($total_bal_pro['bal_p'])){
				// 					$total_bal_pl = $total_bal['pl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
				// 				} else {
				// 					$total_bal_pl = $total_bal['pl_acc'];
				// 				}
				// 			}
				// 			$balance = $total_bal_pl + $leav_data['encash'];
				// 			$upd_bal_sql = "UPDATE `oc_leave` SET `pl_bal` = '".$balance."' WHERE `emp_id` = '".$query1->row['emp_id']."' AND `close_status` = '0' ";
				// 			$this->db->query($upd_bal_sql);
				// 			$this->log->write($upd_bal_sql);
				// 		} 
				// 	}
				// }
				$can_leave_sql = "DELETE FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$batch_id."' ";
				$this->db->query($can_leave_sql);

				$can_leave_sql = "DELETE FROM `oc_leave_transaction` WHERE `linked_batch_id` = '".$batch_id."' ";
				$this->db->query($can_leave_sql);
			}

			$this->session->data['success'] = 'Leave Deleted Successfully';

			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}

			if (isset($this->request->get['filter_name_id'])) {
				$url .= '&filter_name_id=' . $this->request->get['filter_name_id'];
			}

			if (isset($this->request->get['filter_name_id_1'])) {
				$url .= '&filter_name_id_1=' . $this->request->get['filter_name_id_1'];
			}

			if (isset($this->request->get['filter_dept'])) {
				$url .= '&filter_dept=' . $this->request->get['filter_dept'];
			}

			if (isset($this->request->get['filter_unit'])) {
				$url .= '&filter_unit=' . $this->request->get['filter_unit'];
			}

			if (isset($this->request->get['filter_group'])) {
				$url .= '&filter_group=' . $this->request->get['filter_group'];
			}

			if (isset($this->request->get['filter_approval_1'])) {
				$url .= '&filter_approval_1=' . $this->request->get['filter_approval_1'];
			}

			if (isset($this->request->get['filter_approval_1_by'])) {
				$url .= '&filter_approval_1_by=' . $this->request->get['filter_approval_1_by'];
			}

			if (isset($this->request->get['filter_approval_2'])) {
				$url .= '&filter_approval_2=' . $this->request->get['filter_approval_2'];
			}

			if (isset($this->request->get['filter_proc'])) {
				$url .= '&filter_proc=' . $this->request->get['filter_proc'];
			}

			if (isset($this->request->get['filter_leavetype'])) {
				$url .= '&filter_leavetype=' . $this->request->get['filter_leavetype'];
			}

			$this->redirect($this->url->link('transaction/leave_ess_dept', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		} elseif(isset($this->request->get['batch_id']) && $this->validateDelete()){
			$batch_id = $this->request->get['batch_id'];
			// $leav_data_sql = "SELECT * FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$batch_id."' ";
			// $leav_data = $this->db->query($leav_data_sql)->row;
			// if(isset($leav_data['encash']) && $leav_data['encash'] != ''){
			// 	$encah_leave = $leav_data['encash'];
			// 	$sql = "SELECT * FROM `oc_leave` WHERE `emp_id` = '".$leav_data['emp_id']."' AND `close_status` = '0' ";
			// 	$query1 = $this->db->query($sql);
			// 	if($query1->num_rows > 0){
			// 		if($leav_data['leave_type'] == 'PL'){
			// 			//$balance = $query1->row['pl_bal'];
			// 			$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($leav_data['emp_id']);
			// 			$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($leav_data['emp_id'], 'PL');
			// 			$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($leav_data['emp_id'], 'PL');
			// 			$total_bal_pl = 0;
			// 			if(isset($total_bal['pl_acc'])){
			// 				if(isset($total_bal_pro['bal_p'])){
			// 					$total_bal_pl = $total_bal['pl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
			// 				} else {
			// 					$total_bal_pl = $total_bal['pl_acc'];
			// 				}
			// 			}
			// 			$balance = $total_bal_pl + $leav_data['encash'];
			// 			$upd_bal_sql = "UPDATE `oc_leave` SET `pl_bal` = '".$balance."' WHERE `emp_id` = '".$query1->row['emp_id']."' AND `close_status` = '0' ";
			// 			$this->db->query($upd_bal_sql);
			// 			$this->log->write($upd_bal_sql);
			// 		} 
			// 	}
			// }
			$can_leave_sql = "DELETE FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$this->request->get['batch_id']."' ";
			$this->db->query($can_leave_sql);

			$can_leave_sql = "DELETE FROM `oc_leave_transaction` WHERE `linked_batch_id` = '".$batch_id."' ";
			$this->db->query($can_leave_sql);
			$this->session->data['success'] = 'Leave Deleted Successfully';

			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}

			if (isset($this->request->get['filter_name_id'])) {
				$url .= '&filter_name_id=' . $this->request->get['filter_name_id'];
			}

			if (isset($this->request->get['filter_name_id_1'])) {
				$url .= '&filter_name_id_1=' . $this->request->get['filter_name_id_1'];
			}

			if (isset($this->request->get['filter_dept'])) {
				$url .= '&filter_dept=' . $this->request->get['filter_dept'];
			}

			if (isset($this->request->get['filter_group'])) {
				$url .= '&filter_group=' . $this->request->get['filter_group'];
			}

			if (isset($this->request->get['filter_unit'])) {
				$url .= '&filter_unit=' . $this->request->get['filter_unit'];
			}

			if (isset($this->request->get['filter_approval_1'])) {
				$url .= '&filter_approval_1=' . $this->request->get['filter_approval_1'];
			}

			if (isset($this->request->get['filter_approval_1_by'])) {
				$url .= '&filter_approval_1_by=' . $this->request->get['filter_approval_1_by'];
			}

			if (isset($this->request->get['filter_approval_2'])) {
				$url .= '&filter_approval_2=' . $this->request->get['filter_approval_2'];
			}

			if (isset($this->request->get['filter_proc'])) {
				$url .= '&filter_proc=' . $this->request->get['filter_proc'];
			}

			if (isset($this->request->get['filter_leavetype'])) {
				$url .= '&filter_leavetype=' . $this->request->get['filter_leavetype'];
			}

			$this->redirect($this->url->link('transaction/leave_ess_dept', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}

		$this->getList();
	}

	public function approve() {
		$this->language->load('transaction/leave');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('transaction/transaction');
		$this->load->model('catalog/shift');
		$this->load->model('catalog/employee');


		if (isset($this->request->post['selected'])) {
			
			foreach ($this->request->post['selected'] as $batch_id) {
				$batch_id_sql = "SELECT `batch_id` FROM `oc_leave_transaction` ORDER BY `batch_id` DESC LIMIT 1";
				$obatch_ids = $this->db->query($batch_id_sql);
				if($obatch_ids->num_rows == 0){
					$new_batch_id = 1;
				} else{
					$obatch_id = $obatch_ids->row['batch_id'];
					$new_batch_id = $obatch_id + 1;
				}

				$leav_data_sql = "SELECT * FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$batch_id."' ";
				$leav_data = $this->db->query($leav_data_sql)->rows;
				if($leav_data[0]['approval_1'] == '0' && $leav_data[0]['approval_2'] == '0'){
					$from_date = date('d-m-Y', strtotime($leav_data[0]['date']));
					end($leav_data);
					$lkey = key($leav_data);
					$to_date = date('d-m-Y', strtotime($leav_data[$lkey]['date']));

					foreach($leav_data as $lkey => $lvalue){
						$sql = "INSERT INTO `oc_leave_transaction` SET 
							`emp_id` = '".$lvalue['emp_id']."', 
							`leave_type` = '".$lvalue['leave_type']."',
							`date` = '".$lvalue['date']."',
							`date_cof` = '".$lvalue['date_cof']."',
							`leave_amount` = '".$lvalue['leave_amount']."',
							`type` = '".$lvalue['type']."',
							`days` = '".$lvalue['days']."',
							`encash` = '".$lvalue['encash']."',
							`leave_reason` = '".$this->db->escape($lvalue['leave_reason'])."',
							`a_status` = '1',
							`unit` = '".$lvalue['unit']."',
							`group` = '".$lvalue['group']."',
							`year` = '".$lvalue['year']."',
							`dot` = '".$lvalue['dot']."',
							`batch_id` = '".$new_batch_id."',
							`linked_batch_id` = '".$batch_id."' ";
							//echo $sql;
							//echo '<br />';
							$this->db->query($sql);
					}
					// if(isset($leav_data[0]['encash']) && $leav_data[0]['encash'] != ''){
					// 	$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($leav_data[0]['emp_id']);
					// 	$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($leav_data[0]['emp_id'], 'PL');
					// 	$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($leav_data[0]['emp_id'], 'PL');
					// 	$total_bal_pl = 0;
					// 	if(isset($total_bal['pl_acc'])){
					// 		if(isset($total_bal_pro['bal_p'])){
					// 			$total_bal_pl = $total_bal['pl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
					// 		} else {
					// 			$total_bal_pl = $total_bal['pl_acc'];
					// 		}
					// 	}

					// 	if($total_bal_pl > 0){
					// 		$pl_balance = $total_bal_pl;
					// 		$pl_balance = $pl_balance - $leav_data[0]['encash'];
					// 		$upd_pl_bal_sql = "UPDATE `oc_leave` SET `pl_bal` = '".$pl_balance."' WHERE `emp_id` = '".$leav_data[0]['emp_id']."' AND `close_status` = '0' ";
					// 		//echo $upd_pl_bal_sql;
					// 		//echo '<br />';
					// 		$this->db->query($upd_pl_bal_sql);
					// 		$this->log->write($upd_pl_bal_sql);
					// 	}
					// }

						            
		            require_once(DIR_SYSTEM . 'library/PHPMailer/PHPMailerAutoload.php');
					require_once(DIR_SYSTEM . 'library/PHPMailer/class.phpmailer.php');
					require_once(DIR_SYSTEM . 'library/PHPMailer/class.smtp.php');

					$dept_heads = $this->db->query("SELECT `reporting_to`, `department`, emp_code, `title`, `name`, `email` FROM `oc_employee` WHERE 1=1 AND `emp_code` = '".$leav_data[0]['emp_id']."' ")->row;
					$mail = new PHPMailer();
					//$message = 'You have a ' . $data['leave_type'] . ' Leave From '. date('d-m-Y', strtotime($data['from'])) . ' to '. date('d-m-Y', strtotime($data['to'])) .' Pending For Approval by Employee ' . $date['e_name'] . "\n\n";
					$message = 'Hello, ' . "\n\n";
					$message .= 'Your '.$leav_data[0]['leave_type'].' Leave From '.$from_date.' to '.$to_date.' is Approved'."\n\n";
					$message .= '-- Regards'."\n";
					$message .= 'Admin.';
					$subject = 'Leave Approved';
					$from_email = 'alm@indiafactoring.in';
					$to_email = $dept_heads['email'];
					if($to_email != ''){
						$to_emails_array = explode(',', $to_email);
					}
					$to_name = $dept_heads['title'].' '.$dept_heads['name'];
					//$mail->SMTPDebug = 3;
					$mail->IsSMTP();
					//$mail->SMTPAuth = false;
					$mail->Host = '10.64.100.203';//$this->config->get('config_smtp_host');
					$mail->Port = '25';//$this->config->get('config_smtp_port');
					$mail->Username = 'alm@indiafactoring.in';//$this->config->get('config_smtp_username');
					//$mail->Password = 'India@123';//$this->config->get('config_smtp_password');
					//$mail->SMTPSecure = 'ssl';
					$mail->SetFrom($from_email, 'India Factoring & Finance Solutions Pvt.Ltd.');
					$mail->Subject = $subject;
					$mail->Body = html_entity_decode($message);
					foreach($to_emails_array as $ekey => $evalue){
						$mail->AddAddress($evalue);
					}
					if($mail->Send()) {
						// echo 'Mail Sent';
						// echo '<br />';
						$this->log->write('Department Approval Mail Sent');
					} else {
						// echo 'Mail Sent';
						// echo '<br />';
						// echo '<pre>';
						// print_r($mail->ErrorInfo);
						// echo '<br />';
						$this->log->write('Department Approval Mail Not Sent');
						$this->log->write(print_r($mail->ErrorInfo, true));
					}
					

					/*
					$dept_heads = $this->db->query("SELECT `reporting_to`, `department`, emp_code, `title`, `name`, `email` FROM `oc_employee` WHERE 1=1 AND `emp_code` = '".$leav_data[0]['emp_id']."' ")->row;
					//$message = 'You have a ' . $data['leave_type'] . ' Leave From '. date('d-m-Y', strtotime($data['from'])) . ' to '. date('d-m-Y', strtotime($data['to'])) .' Pending For Approval by Employee ' . $date['e_name'] . "\n\n";
					$message = 'Hello, ' . "<br>";
					$message .= 'Your '.$leav_data[0]['leave_type'].' Leave From '.$from_date.' to '.$to_date.' is Approved'."<br>";
					$message .= '-- Regards'."<br>";
					$message .= 'Admin.';
					$subject = 'Leave Approved';
					$from_email = 'alm@indiafactoring.in';
					$to_email = $dept_heads['email'];
					//$to_email = 'eric.fargose@gmail.com';
					$to_name = $dept_heads['title'].' '.$dept_heads['name'];

					require(DIR_SYSTEM . 'library/Mailin.php');
		            $mailin = new Mailin("https://api.sendinblue.com/v2.0","N12OPU6qLfTsxnK7");
		            $mail_data = array( "to" => array($to_email=>$to_name),
		                            "from" => array($from_email, "India Factoring & Finance Solutions Pvt.Ltd."),
		                            "subject" => $subject,
		                            "html" => html_entity_decode($message)
		                         );
		            $mailin->send_email($mail_data);
					*/

				}
				date_default_timezone_set("Asia/Kolkata");
				if(isset($this->session->data['is_super']) || isset($this->session->data['is_super1'])){
					$approve_sql = "UPDATE `oc_leave_transaction_temp` SET `a_status` = '1', `approval_2` = '1', `approval_date_2` = '".date('Y-m-d h:i:s')."', `reject_date_2` = '0000-00-00 00:00:00' WHERE `batch_id` = '".$batch_id."' ";
				} elseif(isset($this->session->data['is_dept'])){
					$approve_sql = "UPDATE `oc_leave_transaction_temp` SET `a_status` = '1', `approval_1` = '1', `approval_date_1` = '".date('Y-m-d h:i:s')."', `approved_1_by` = '".$this->session->data['d_emp_id']."', `reject_date_1` = '0000-00-00 00:00:00' WHERE `batch_id` = '".$batch_id."' ";
				}
				$this->db->query($approve_sql);
				$this->db->query("DELETE FROM `oc_requestform` WHERE `batch_id` = '".$batch_id."' ");
			}

			$this->session->data['success'] = 'Leave Approved Successfully';

			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}

			if (isset($this->request->get['filter_name_id'])) {
				$url .= '&filter_name_id=' . $this->request->get['filter_name_id'];
			}

			if (isset($this->request->get['filter_name_id_1'])) {
				$url .= '&filter_name_id_1=' . $this->request->get['filter_name_id_1'];
			}

			if (isset($this->request->get['filter_dept'])) {
				$url .= '&filter_dept=' . $this->request->get['filter_dept'];
			}

			if (isset($this->request->get['filter_group'])) {
				$url .= '&filter_group=' . $this->request->get['filter_group'];
			}

			if (isset($this->request->get['filter_unit'])) {
				$url .= '&filter_unit=' . $this->request->get['filter_unit'];
			}

			if (isset($this->request->get['filter_approval_1'])) {
				$url .= '&filter_approval_1=' . $this->request->get['filter_approval_1'];
			}

			if (isset($this->request->get['filter_approval_1_by'])) {
				$url .= '&filter_approval_1_by=' . $this->request->get['filter_approval_1_by'];
			}

			if (isset($this->request->get['filter_approval_2'])) {
				$url .= '&filter_approval_2=' . $this->request->get['filter_approval_2'];
			}

			if (isset($this->request->get['filter_proc'])) {
				$url .= '&filter_proc=' . $this->request->get['filter_proc'];
			}

			if (isset($this->request->get['filter_leavetype'])) {
				$url .= '&filter_leavetype=' . $this->request->get['filter_leavetype'];
			}

			$this->redirect($this->url->link('transaction/leave_ess_dept', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		} elseif(isset($this->request->get['batch_id'])){
			$batch_id = $this->request->get['batch_id'];
			$batch_id_sql = "SELECT `batch_id` FROM `oc_leave_transaction` ORDER BY `batch_id` DESC LIMIT 1";
			$obatch_ids = $this->db->query($batch_id_sql);
			if($obatch_ids->num_rows == 0){
				$new_batch_id = 1;
			} else{
				$obatch_id = $obatch_ids->row['batch_id'];
				$new_batch_id = $obatch_id + 1;
			}

			$leav_data_sql = "SELECT * FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$batch_id."' ";
			$leav_data = $this->db->query($leav_data_sql)->rows;

			// echo '<pre>';
			// print_r($this->session->data);
			// exit;
			if(($leav_data[0]['approval_1'] == '0' || $leav_data[0]['approval_1'] == '2') && $leav_data[0]['approval_2'] == '0'){
				$from_date = date('d-m-Y', strtotime($leav_data[0]['date']));
				end($leav_data);
				$lkey = key($leav_data);
				$to_date = date('d-m-Y', strtotime($leav_data[$lkey]['date']));
				
				foreach($leav_data as $lkey => $lvalue){
					$sql = "INSERT INTO `oc_leave_transaction` SET 
						`emp_id` = '".$lvalue['emp_id']."', 
						`leave_type` = '".$lvalue['leave_type']."',
						`date` = '".$lvalue['date']."',
						`date_cof` = '".$lvalue['date_cof']."',
						`leave_amount` = '".$lvalue['leave_amount']."',
						`type` = '".$lvalue['type']."',
						`days` = '".$lvalue['days']."',
						`encash` = '".$lvalue['encash']."',
						`leave_reason` = '".$this->db->escape($lvalue['leave_reason'])."',
						`a_status` = '1',
						`unit` = '".$lvalue['unit']."',
						`group` = '".$lvalue['group']."',
						`year` = '".$lvalue['year']."',
						`dot` = '".$lvalue['dot']."',
						`batch_id` = '".$new_batch_id."',
						`linked_batch_id` = '".$batch_id."' ";
						//echo $sql;
						//echo '<br />';
						$this->db->query($sql);
						$this->log->write($sql);
				}
				
				require_once(DIR_SYSTEM . 'library/PHPMailer/PHPMailerAutoload.php');
				require_once(DIR_SYSTEM . 'library/PHPMailer/class.phpmailer.php');
				require_once(DIR_SYSTEM . 'library/PHPMailer/class.smtp.php');

				$dept_heads = $this->db->query("SELECT `reporting_to`, `department`, emp_code, `title`, `name`, `email` FROM `oc_employee` WHERE 1=1 AND `emp_code` = '".$leav_data[0]['emp_id']."' ")->row;
				$mail = new PHPMailer();
				//$message = 'You have a ' . $data['leave_type'] . ' Leave From '. date('d-m-Y', strtotime($data['from'])) . ' to '. date('d-m-Y', strtotime($data['to'])) .' Pending For Approval by Employee ' . $date['e_name'] . "\n\n";
				$message = 'Hello, ' . "\n\n";
				$message .= 'Your '.$leav_data[0]['leave_type'].' Leave From '.$from_date.' to '.$to_date.' is Approved'."\n\n";
				$message .= '-- Regards'."\n";
				$message .= 'Admin.';
				$subject = 'Leave Approved';
				$from_email = 'alm@indiafactoring.in';
				$to_email = "poonam@wewant360.com";//$dept_heads['email'];
				if($to_email != ''){
					$to_emails_array = explode(',', $to_email);
				}
				$to_name = $dept_heads['title'].' '.$dept_heads['name'];
				//$mail->SMTPDebug = 3;
				$mail->IsSMTP();
				//$mail->SMTPAuth = false;
				$mail->Host = '10.64.100.203';//$this->config->get('config_smtp_host');
				$mail->Port = '25';//$this->config->get('config_smtp_port');
				$mail->Username = 'alm@indiafactoring.in';//$this->config->get('config_smtp_username');
				//$mail->Password = 'India@123';//$this->config->get('config_smtp_password');
				//$mail->SMTPSecure = 'ssl';
				$mail->SetFrom($from_email, 'India Factoring & Finance Solutions Pvt.Ltd.');
				$mail->Subject = $subject;
				$mail->Body = html_entity_decode($message);
				foreach($to_emails_array as $ekey => $evalue){
					$mail->AddAddress($evalue);
				}
				if($mail->Send()) {
					//echo 'Mail Sent';
					//echo '<br />';
					$this->log->write('Department Approval Mail Sent');
				} else {
					// echo 'Mail Sent';
					// echo '<br />';
					//echo '<pre>';
					//print_r($mail->ErrorInfo);
					//echo '<br />';
					$this->log->write('Department Approval Mail Not Sent');
					$this->log->write(print_r($mail->ErrorInfo, true));
				}
				//echo 'out';exit;
				
				/*	
				$dept_heads = $this->db->query("SELECT `reporting_to`, `department`, emp_code, `title`, `name`, `email` FROM `oc_employee` WHERE 1=1 AND `emp_code` = '".$leav_data[0]['emp_id']."' ")->row;
				//$message = 'You have a ' . $data['leave_type'] . ' Leave From '. date('d-m-Y', strtotime($data['from'])) . ' to '. date('d-m-Y', strtotime($data['to'])) .' Pending For Approval by Employee ' . $date['e_name'] . "\n\n";
				$message = 'Hello, ' . "<br>";
				$message .= 'Your '.$leav_data[0]['leave_type'].' Leave From '.$from_date.' to '.$to_date.' is Approved'."<br>";
				$message .= '-- Regards'."<br>";
				$message .= 'Admin.';
				//$message = 'Your '.$leav_data[0]['leave_type'].' Leave From '.$from_date.' to '.$to_date.' is Approved'."<br>";
				$subject = 'Leave Approved';
				$from_email = 'alm@indiafactoring.in';
				$to_email = $dept_heads['email'];
				//$to_email = 'eric.fargose@gmail.com';
				$to_name = $dept_heads['title'].' '.$dept_heads['name'];

				require(DIR_SYSTEM . 'library/Mailin.php');
	            $mailin = new Mailin("https://api.sendinblue.com/v2.0","N12OPU6qLfTsxnK7");
	            $mail_data = array( "to" => array($to_email=>$to_name),
	                            "from" => array($from_email, "India Factoring & Finance Solutions Pvt.Ltd."),
	                            "subject" => $subject,
	                            "html" => html_entity_decode($message)
	                         );
	            $mailin->send_email($mail_data);
				*/

	            // if(isset($leav_data[0]['encash']) && $leav_data[0]['encash'] != ''){
				// 	$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($leav_data[0]['emp_id']);
				// 	$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($leav_data[0]['emp_id'], 'PL');
				// 	$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($leav_data[0]['emp_id'], 'PL');
				// 	$total_bal_pl = 0;
				// 	if(isset($total_bal['pl_acc'])){
				// 		if(isset($total_bal_pro['bal_p'])){
				// 			$total_bal_pl = $total_bal['pl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
				// 		} else {
				// 			$total_bal_pl = $total_bal['pl_acc'];
				// 		}
				// 	}

				// 	if($total_bal_pl > 0){
				// 		$pl_balance = $total_bal_pl;
				// 		$pl_balance = $pl_balance - $leav_data[0]['encash'];
				// 		$upd_pl_bal_sql = "UPDATE `oc_leave` SET `pl_bal` = '".$pl_balance."' WHERE `emp_id` = '".$leav_data[0]['emp_id']."' AND `close_status` = '0' ";
				// 		//echo $upd_pl_bal_sql;
				// 		//echo '<br />';
				// 		$this->db->query($upd_pl_bal_sql);
				// 		$this->log->write($upd_pl_bal_sql);
				// 	}
				// }
			}
		
			date_default_timezone_set("Asia/Kolkata");
			//if(isset($this->session->data['is_super']) || isset($this->session->data['is_super1'])){
				$approve_sql_1 = "UPDATE `oc_leave_transaction_temp` SET `a_status` = '1', `approval_2` = '1', `approval_date_2` = '".date('Y-m-d h:i:s')."', `reject_reason_2` = '', `reject_date_2` = '0000-00-00 00:00:00' WHERE `batch_id` = '".$batch_id."' ";
			//} elseif(isset($this->session->data['is_dept'])){
				$approve_sql_2 = "UPDATE `oc_leave_transaction_temp` SET `a_status` = '1', `approval_1` = '1', `approval_date_1` = '".date('Y-m-d h:i:s')."', `reject_reason_1` = '', `approved_1_by` = '".$this->session->data['emp_code']."', `reject_date_1` = '0000-00-00 00:00:00', `a_status` = '1' WHERE `batch_id` = '".$batch_id."' ";
			//}
			$this->db->query($approve_sql_1);
			$this->db->query($approve_sql_2);
			$this->db->query("DELETE FROM `oc_requestform` WHERE `batch_id` = '".$batch_id."' ");
			
			$this->session->data['success'] = 'Leave Approved Successfully';

			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}

			if (isset($this->request->get['filter_name_id'])) {
				$url .= '&filter_name_id=' . $this->request->get['filter_name_id'];
			}

			if (isset($this->request->get['filter_name_id_1'])) {
				$url .= '&filter_name_id_1=' . $this->request->get['filter_name_id_1'];
			}

			if (isset($this->request->get['filter_group'])) {
				$url .= '&filter_group=' . $this->request->get['filter_group'];
			}

			if (isset($this->request->get['filter_dept'])) {
				$url .= '&filter_dept=' . $this->request->get['filter_dept'];
			}

			if (isset($this->request->get['filter_unit'])) {
				$url .= '&filter_unit=' . $this->request->get['filter_unit'];
			}

			if (isset($this->request->get['filter_approval_1'])) {
				$url .= '&filter_approval_1=' . $this->request->get['filter_approval_1'];
			}

			if (isset($this->request->get['filter_approval_1_by'])) {
				$url .= '&filter_approval_1_by=' . $this->request->get['filter_approval_1_by'];
			}

			if (isset($this->request->get['filter_approval_2'])) {
				$url .= '&filter_approval_2=' . $this->request->get['filter_approval_2'];
			}

			if (isset($this->request->get['filter_proc'])) {
				$url .= '&filter_proc=' . $this->request->get['filter_proc'];
			}

			if (isset($this->request->get['filter_leavetype'])) {
				$url .= '&filter_leavetype=' . $this->request->get['filter_leavetype'];
			}

			$this->redirect($this->url->link('transaction/leave_ess_dept', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}

		$this->getList();
	}

	public function cancel() {
		date_default_timezone_set("Asia/Kolkata");
		$this->language->load('transaction/leave');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('transaction/transaction');
		$this->load->model('catalog/shift');
		$this->load->model('catalog/employee');

		if (isset($this->request->post['selected'])) {
			foreach ($this->request->post['selected'] as $batch_id) {
				if(isset($this->session->data['is_super']) || isset($this->session->data['is_super1'])){
					$approve_sql = "UPDATE `oc_leave_transaction_temp` SET `a_status` = '0', `approval_2` = '0', `approval_date_2` = '0000-00-00 00:00:00', `reject_date_2` = '".date('Y-m-d h:i:s')."' WHERE `batch_id` = '".$batch_id."' ";
				} elseif(isset($this->session->data['is_dept'])){
					$approve_sql = "UPDATE `oc_leave_transaction_temp` SET `a_status` = '0', `approval_1` = '2', `approval_date_1` = '0000-00-00 00:00:00', `approved_1_by` = '0', `reject_date_1` = '".date('Y-m-d h:i:s')."' WHERE `batch_id` = '".$batch_id."' ";
				}
				$this->db->query($approve_sql);
				$leav_data_sql = "SELECT * FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$batch_id."' ";
				$leav_data = $this->db->query($leav_data_sql)->rows;
				if($leav_data[0]['approval_1'] == '0' && $leav_data[0]['approval_2'] == '0'){
					
					// if(isset($leav_data[0]['encash']) && $leav_data[0]['encash'] != ''){
					// 	$encah_leave = $leav_data[0]['encash'];
					// 	$sql = "SELECT * FROM `oc_leave` WHERE `emp_id` = '".$leav_data[0]['emp_id']."' AND `close_status` = '0' ";
					// 	$query1 = $this->db->query($sql);
					// 	if($query1->num_rows > 0){
					// 		if($leav_data[0]['leave_type'] == 'PL'){
					// 			//$balance = $query1->row['pl_bal'];
					// 			$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($leav_data[0]['emp_id']);
					// 			$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($leav_data[0]['emp_id'], 'PL');
					// 			$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($leav_data[0]['emp_id'], 'PL');
					// 			$total_bal_pl = 0;
					// 			if(isset($total_bal['pl_acc'])){
					// 				if(isset($total_bal_pro['bal_p'])){
					// 					$total_bal_pl = $total_bal['pl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
					// 				} else {
					// 					$total_bal_pl = $total_bal['pl_acc'];
					// 				}
					// 			}
					// 			$balance = $total_bal_pl + $leav_data[0]['encash'];
					// 			$upd_bal_sql = "UPDATE `oc_leave` SET `pl_bal` = '".$balance."' WHERE `emp_id` = '".$query1->row['emp_id']."' AND `close_status` = '0' ";
					// 			$this->db->query($upd_bal_sql);
					// 			$this->log->write($upd_bal_sql);
					// 		} 
					// 	}
					// }
					$from_date = date('d-m-Y', strtotime($leav_data[0]['date']));
					end($leav_data);
					$lkey = key($leav_data);
					$to_date = date('d-m-Y', strtotime($leav_data[$lkey]['date']));

					
		            require_once(DIR_SYSTEM . 'library/PHPMailer/PHPMailerAutoload.php');
					require_once(DIR_SYSTEM . 'library/PHPMailer/class.phpmailer.php');
					require_once(DIR_SYSTEM . 'library/PHPMailer/class.smtp.php');

					$dept_heads = $this->db->query("SELECT `reporting_to`, `department`, emp_code, `title`, `name`, `email` FROM `oc_employee` WHERE 1=1 AND `emp_code` = '".$leav_data[0]['emp_id']."' ")->row;
					$mail = new PHPMailer();
					//$message = 'You have a ' . $data['leave_type'] . ' Leave From '. date('d-m-Y', strtotime($data['from'])) . ' to '. date('d-m-Y', strtotime($data['to'])) .' Pending For Approval by Employee ' . $date['e_name'] . "\n\n";
					$message = 'Hello, ' . "\n\n";
					$message .= 'Your '.$leav_data[0]['leave_type'].' Leave From '.$from_date.' to '.$to_date.' is Rejected'."\n\n";
					$message .= '-- Regards'."\n";
					$message .= 'Admin.';
					$subject = 'Leave Rejected';
					$from_email = 'alm@indiafactoring.in';
					$to_email = $dept_heads['email'];
					if($to_email != ''){
						$to_emails_array = explode(',', $to_email);
					}
					$to_name = $dept_heads['title'].' '.$dept_heads['name'];
					//$mail->SMTPDebug = 3;
					$mail->IsSMTP();
					//$mail->SMTPAuth = false;
					$mail->Host = '10.64.100.203';//$this->config->get('config_smtp_host');
					$mail->Port = '25';//$this->config->get('config_smtp_port');
					$mail->Username = 'alm@indiafactoring.in';//$this->config->get('config_smtp_username');
					//$mail->Password = 'India@123';//$this->config->get('config_smtp_password');
					//$mail->SMTPSecure = 'ssl';
					$mail->SetFrom($from_email, 'India Factoring & Finance Solutions Pvt.Ltd.');
					$mail->Subject = $subject;
					$mail->Body = html_entity_decode($message);
					foreach($to_emails_array as $ekey => $evalue){
						$mail->AddAddress($evalue);
					}
					if($mail->Send()) {
						// echo 'Mail Sent';
						// echo '<br />';
						$this->log->write('Department Rejected Mail Sent');
					} else {
						// echo 'Mail Sent';
						// echo '<br />';
						// echo '<pre>';
						// print_r($mail->ErrorInfo);
						// echo '<br />';
						$this->log->write('Department Rejected Mail Not Sent');
						$this->log->write(print_r($mail->ErrorInfo, true));
					}
					
					/*
					$dept_heads = $this->db->query("SELECT `reporting_to`, `department`, emp_code, `title`, `name`, `email` FROM `oc_employee` WHERE 1=1 AND `emp_code` = '".$leav_data[0]['emp_id']."' ")->row;
					//$message = 'You have a ' . $data['leave_type'] . ' Leave From '. date('d-m-Y', strtotime($data['from'])) . ' to '. date('d-m-Y', strtotime($data['to'])) .' Pending For Approval by Employee ' . $date['e_name'] . "\n\n";
					$message = 'Hello, ' . "<br>";
					$message .= 'Your '.$leav_data[0]['leave_type'].' Leave From '.$from_date.' to '.$to_date.' is Rejected'."<br>";
					$message .= '-- Regards'."<br>";
					$message .= 'Admin.';
					//$message = 'Your '.$leav_data[0]['leave_type'].' Leave From '.$from_date.' to '.$to_date.' is Rejected'."<br>";
					$subject = 'Leave Rejected';
					$from_email = 'alm@indiafactoring.in';
					$to_email = $dept_heads['email'];
					//$to_email = 'eric.fargose@gmail.com';
					$to_name = $dept_heads['title'].' '.$dept_heads['name'];

					require(DIR_SYSTEM . 'library/Mailin.php');
		            $mailin = new Mailin("https://api.sendinblue.com/v2.0","N12OPU6qLfTsxnK7");
		            $mail_data = array( "to" => array($to_email=>$to_name),
		                            "from" => array($from_email, "India Factoring & Finance Solutions Pvt.Ltd."),
		                            "subject" => $subject,
		                            "html" => html_entity_decode($message)
		                         );
		            $mailin->send_email($mail_data);
		            */
		            $approve_sql = "DELETE FROM `oc_leave_transaction` WHERE `linked_batch_id` = '".$batch_id."' ";
					$this->db->query($approve_sql);	
				}
			}

			$this->session->data['success'] = 'Leave Canceled Successfully';

			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}

			if (isset($this->request->get['filter_name_id'])) {
				$url .= '&filter_name_id=' . $this->request->get['filter_name_id'];
			}

			if (isset($this->request->get['filter_name_id_1'])) {
				$url .= '&filter_name_id_1=' . $this->request->get['filter_name_id_1'];
			}

			if (isset($this->request->get['filter_dept'])) {
				$url .= '&filter_dept=' . $this->request->get['filter_dept'];
			}

			if (isset($this->request->get['filter_group'])) {
				$url .= '&filter_group=' . $this->request->get['filter_group'];
			}

			if (isset($this->request->get['filter_unit'])) {
				$url .= '&filter_unit=' . $this->request->get['filter_unit'];
			}

			if (isset($this->request->get['filter_approval_1'])) {
				$url .= '&filter_approval_1=' . $this->request->get['filter_approval_1'];
			}

			if (isset($this->request->get['filter_approval_1_by'])) {
				$url .= '&filter_approval_1_by=' . $this->request->get['filter_approval_1_by'];
			}

			if (isset($this->request->get['filter_approval_2'])) {
				$url .= '&filter_approval_2=' . $this->request->get['filter_approval_2'];
			}

			if (isset($this->request->get['filter_proc'])) {
				$url .= '&filter_proc=' . $this->request->get['filter_proc'];
			}

			if (isset($this->request->get['filter_leavetype'])) {
				$url .= '&filter_leavetype=' . $this->request->get['filter_leavetype'];
			}

			$this->redirect($this->url->link('transaction/leave_ess_dept', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		} elseif (isset($this->request->post['reject_reason_1']) || isset($this->request->post['reject_reason_2'])) {
			$batch_id = $this->request->get['batch_id'];
			//if(isset($this->session->data['is_super']) || isset($this->session->data['is_super1'])){
				$reject_reason_2 = $this->request->post['reject_reason_2'];
				$approve_sql_1 = "UPDATE `oc_leave_transaction_temp` SET `a_status` = '0', `approval_2` = '0', `approval_date_2` = '0000-00-00 00:00:00', `reject_reason_2` = '".$reject_reason_2."', `reject_date_2` = '".date('Y-m-d h:i:s')."' WHERE `batch_id` = '".$batch_id."' ";
			//} elseif(isset($this->session->data['is_dept'])){
				$reject_reason_1 = $this->request->post['reject_reason_1'];
				$approve_sql_2 = "UPDATE `oc_leave_transaction_temp` SET `a_status` = '0', `approval_1` = '0', `approval_date_1` = '0000-00-00 00:00:00', `approved_1_by` = '', `reject_reason_1` = '".$reject_reason_1."', `reject_date_1` = '".date('Y-m-d h:i:s')."' WHERE `batch_id` = '".$batch_id."' ";
			//}
			$this->db->query($approve_sql_1);
			$this->db->query($approve_sql_2);

			$leav_data_sql = "SELECT * FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$batch_id."' ";
			$leav_data = $this->db->query($leav_data_sql)->rows;
			if($leav_data[0]['approval_1'] == '0' && $leav_data[0]['approval_2'] == '0'){
				
				// if(isset($leav_data[0]['encash']) && $leav_data[0]['encash'] != ''){
				// 	$encah_leave = $leav_data[0]['encash'];
				// 	$sql = "SELECT * FROM `oc_leave` WHERE `emp_id` = '".$leav_data[0]['emp_id']."' AND `close_status` = '0' ";
				// 	$query1 = $this->db->query($sql);
				// 	if($query1->num_rows > 0){
				// 		if($leav_data[0]['leave_type'] == 'PL'){
				// 			//$balance = $query1->row['pl_bal'];
				// 			$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($leav_data[0]['emp_id']);
				// 			$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($leav_data[0]['emp_id'], 'PL');
				// 			$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($leav_data[0]['emp_id'], 'PL');
				// 			$total_bal_pl = 0;
				// 			if(isset($total_bal['pl_acc'])){
				// 				if(isset($total_bal_pro['bal_p'])){
				// 					$total_bal_pl = $total_bal['pl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
				// 				} else {
				// 					$total_bal_pl = $total_bal['pl_acc'];
				// 				}
				// 			}
				// 			$balance = $total_bal_pl + $leav_data[0]['encash'];
				// 			$upd_bal_sql = "UPDATE `oc_leave` SET `pl_bal` = '".$balance."' WHERE `emp_id` = '".$query1->row['emp_id']."' AND `close_status` = '0' ";
				// 			$this->db->query($upd_bal_sql);
				// 			$this->log->write($upd_bal_sql);
				// 		} 
				// 	}
				// }
				$from_date = date('d-m-Y', strtotime($leav_data[0]['date']));
				end($leav_data);
				$lkey = key($leav_data);
				$to_date = date('d-m-Y', strtotime($leav_data[$lkey]['date']));

				
	            require_once(DIR_SYSTEM . 'library/PHPMailer/PHPMailerAutoload.php');
				require_once(DIR_SYSTEM . 'library/PHPMailer/class.phpmailer.php');
				require_once(DIR_SYSTEM . 'library/PHPMailer/class.smtp.php');

				$dept_heads = $this->db->query("SELECT `reporting_to`, `department`, emp_code, `title`, `name`, `email` FROM `oc_employee` WHERE 1=1 AND `emp_code` = '".$leav_data[0]['emp_id']."' ")->row;
				$mail = new PHPMailer();
				//$message = 'You have a ' . $data['leave_type'] . ' Leave From '. date('d-m-Y', strtotime($data['from'])) . ' to '. date('d-m-Y', strtotime($data['to'])) .' Pending For Approval by Employee ' . $date['e_name'] . "\n\n";
				$message = 'Hello, ' . "\n\n";
				$message .= 'Your '.$leav_data[0]['leave_type'].' Leave From '.$from_date.' to '.$to_date.' is Rejected'."\n\n";
				$message .= '-- Regards'."\n";
				$message .= 'Admin.';
				$subject = 'Leave Rejected';
				$from_email = 'alm@indiafactoring.in';
				$to_email = $dept_heads['email'];
				if($to_email != ''){
					$to_emails_array = explode(',', $to_email);
				}
				$to_name = $dept_heads['title'].' '.$dept_heads['name'];
				//$mail->SMTPDebug = 3;
				$mail->IsSMTP();
				//$mail->SMTPAuth = false;
				$mail->Host = '10.64.100.203';//$this->config->get('config_smtp_host');
				$mail->Port = '25';//$this->config->get('config_smtp_port');
				$mail->Username = 'alm@indiafactoring.in';//$this->config->get('config_smtp_username');
				//$mail->Password = 'India@123';//$this->config->get('config_smtp_password');
				//$mail->SMTPSecure = 'ssl';
				$mail->SetFrom($from_email, 'India Factoring & Finance Solutions Pvt.Ltd.');
				$mail->Subject = $subject;
				$mail->Body = html_entity_decode($message);
				foreach($to_emails_array as $ekey => $evalue){
					$mail->AddAddress($evalue);
				}
				if($mail->Send()) {
					// echo 'Mail Sent';
					// echo '<br />';
					$this->log->write('Department Rejected Mail Sent');
				} else {
					// echo 'Mail Sent';
					// echo '<br />';
					// echo '<pre>';
					// print_r($mail->ErrorInfo);
					// echo '<br />';
					$this->log->write('Department Rejected Mail Not Sent');
					$this->log->write(print_r($mail->ErrorInfo, true));
				}
				
				/*
				$dept_heads = $this->db->query("SELECT `reporting_to`, `department`, emp_code, `title`, `name`, `email` FROM `oc_employee` WHERE 1=1 AND `emp_code` = '".$leav_data[0]['emp_id']."' ")->row;
				//$message = 'You have a ' . $data['leave_type'] . ' Leave From '. date('d-m-Y', strtotime($data['from'])) . ' to '. date('d-m-Y', strtotime($data['to'])) .' Pending For Approval by Employee ' . $date['e_name'] . "\n\n";
				$message = 'Hello, ' . "<br>";
				$message .= 'Your '.$leav_data[0]['leave_type'].' Leave From '.$from_date.' to '.$to_date.' is Rejected'."<br>";
				$message .= '-- Regards'."<br>";
				$message .= 'Admin.';
				//$message = 'Your '.$leav_data[0]['leave_type'].' Leave From '.$from_date.' to '.$to_date.' is Rejected'."<br>";
				$subject = 'Leave Rejected';
				$from_email = 'alm@indiafactoring.in';
				$to_email = $dept_heads['email'];
				//$to_email = 'eric.fargose@gmail.com';
				$to_name = $dept_heads['title'].' '.$dept_heads['name'];

				require(DIR_SYSTEM . 'library/Mailin.php');
	            $mailin = new Mailin("https://api.sendinblue.com/v2.0","N12OPU6qLfTsxnK7");
	            $mail_data = array( "to" => array($to_email=>$to_name),
	                            "from" => array($from_email, "India Factoring & Finance Solutions Pvt.Ltd."),
	                            "subject" => $subject,
	                            "html" => html_entity_decode($message)
	                         );
	            $mailin->send_email($mail_data);
	            */
	            $approve_sql = "DELETE FROM `oc_leave_transaction` WHERE `linked_batch_id` = '".$batch_id."' ";
				$this->db->query($approve_sql);	
			}
			$this->session->data['success'] = 'Leave Cancelled Successfully';

			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}

			if (isset($this->request->get['filter_name_id'])) {
				$url .= '&filter_name_id=' . $this->request->get['filter_name_id'];
			}

			if (isset($this->request->get['filter_name_id_1'])) {
				$url .= '&filter_name_id_1=' . $this->request->get['filter_name_id_1'];
			}

			if (isset($this->request->get['filter_dept'])) {
				$url .= '&filter_dept=' . $this->request->get['filter_dept'];
			}

			if (isset($this->request->get['filter_group'])) {
				$url .= '&filter_group=' . $this->request->get['filter_group'];
			}

			if (isset($this->request->get['filter_unit'])) {
				$url .= '&filter_unit=' . $this->request->get['filter_unit'];
			}

			if (isset($this->request->get['filter_approval_1'])) {
				$url .= '&filter_approval_1=' . $this->request->get['filter_approval_1'];
			}

			if (isset($this->request->get['filter_approval_1_by'])) {
				$url .= '&filter_approval_1_by=' . $this->request->get['filter_approval_1_by'];
			}

			if (isset($this->request->get['filter_approval_2'])) {
				$url .= '&filter_approval_2=' . $this->request->get['filter_approval_2'];
			}

			if (isset($this->request->get['filter_proc'])) {
				$url .= '&filter_proc=' . $this->request->get['filter_proc'];
			}

			if (isset($this->request->get['filter_leavetype'])) {
				$url .= '&filter_leavetype=' . $this->request->get['filter_leavetype'];
			}

			$this->redirect($this->url->link('transaction/leave_ess_dept', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		} elseif(isset($this->request->get['batch_id']) && $this->validateDelete()){
			$batch_id = $this->request->get['batch_id'];
			//if(isset($this->session->data['is_super']) || isset($this->session->data['is_super1'])){
				$approve_sql_1 = "UPDATE `oc_leave_transaction_temp` SET `a_status` = '0', `approval_2` = '0', `approval_date_2` = '0000-00-00 00:00:00', `reject_date_2` = '".date('Y-m-d h:i:s')."' WHERE `batch_id` = '".$batch_id."' ";
			//} elseif(isset($this->session->data['is_dept'])){
				$approve_sql_2 = "UPDATE `oc_leave_transaction_temp` SET `a_status` = '0', `approval_1` = '2', `approval_date_1` = '0000-00-00 00:00:00', `approved_1_by` = '', `reject_date_1` = '".date('Y-m-d h:i:s')."' WHERE `batch_id` = '".$batch_id."' ";
			//}
			$this->db->query($approve_sql_1);
			$this->db->query($approve_sql_2);

			$leav_data_sql = "SELECT * FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$batch_id."' ";
			$leav_data = $this->db->query($leav_data_sql)->rows;
			if($leav_data[0]['approval_1'] == '2' && $leav_data[0]['approval_2'] == '0'){
				
				// if(isset($leav_data[0]['encash']) && $leav_data[0]['encash'] != ''){
				// 	$encah_leave = $leav_data[0]['encash'];
				// 	$sql = "SELECT * FROM `oc_leave` WHERE `emp_id` = '".$leav_data[0]['emp_id']."' AND `close_status` = '0' ";
				// 	$query1 = $this->db->query($sql);
				// 	if($query1->num_rows > 0){
				// 		if($leav_data[0]['leave_type'] == 'PL'){
				// 			//$balance = $query1->row['pl_bal'];
				// 			$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($leav_data[0]['emp_id']);
				// 			$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($leav_data[0]['emp_id'], 'PL');
				// 			$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($leav_data[0]['emp_id'], 'PL');
				// 			$total_bal_pl = 0;
				// 			if(isset($total_bal['pl_acc'])){
				// 				if(isset($total_bal_pro['bal_p'])){
				// 					$total_bal_pl = $total_bal['pl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
				// 				} else {
				// 					$total_bal_pl = $total_bal['pl_acc'];
				// 				}
				// 			}
				// 			$balance = $total_bal_pl + $leav_data[0]['encash'];
				// 			$upd_bal_sql = "UPDATE `oc_leave` SET `pl_bal` = '".$balance."' WHERE `emp_id` = '".$query1->row['emp_id']."' AND `close_status` = '0' ";
				// 			$this->db->query($upd_bal_sql);
				// 			$this->log->write($upd_bal_sql);
				// 		} 
				// 	}
				// }
				$from_date = date('d-m-Y', strtotime($leav_data[0]['date']));
				end($leav_data);
				$lkey = key($leav_data);
				$to_date = date('d-m-Y', strtotime($leav_data[$lkey]['date']));

				
	            require_once(DIR_SYSTEM . 'library/PHPMailer/PHPMailerAutoload.php');
				require_once(DIR_SYSTEM . 'library/PHPMailer/class.phpmailer.php');
				require_once(DIR_SYSTEM . 'library/PHPMailer/class.smtp.php');

				$dept_heads = $this->db->query("SELECT `reporting_to`, `department`, emp_code, `title`, `name`, `email` FROM `oc_employee` WHERE 1=1 AND `emp_code` = '".$leav_data[0]['emp_id']."' ")->row;
				$mail = new PHPMailer();
				//$message = 'You have a ' . $data['leave_type'] . ' Leave From '. date('d-m-Y', strtotime($data['from'])) . ' to '. date('d-m-Y', strtotime($data['to'])) .' Pending For Approval by Employee ' . $date['e_name'] . "\n\n";
				$message = 'Hello, ' . "\n\n";
				$message .= 'Your '.$leav_data[0]['leave_type'].' Leave From '.$from_date.' to '.$to_date.' is Rejected'."\n\n";
				$message .= '-- Regards'."\n";
				$message .= 'Admin.';
				$subject = 'Leave Rejected';
				$from_email = 'alm@indiafactoring.in';
				$to_email = $dept_heads['email'];
				if($to_email != ''){
					$to_emails_array = explode(',', $to_email);
				}
				$to_name = $dept_heads['title'].' '.$dept_heads['name'];
				//$mail->SMTPDebug = 3;
				$mail->IsSMTP();
				//$mail->SMTPAuth = false;
				$mail->Host = '10.64.100.203';//$this->config->get('config_smtp_host');
				$mail->Port = '25';//$this->config->get('config_smtp_port');
				$mail->Username = 'alm@indiafactoring.in';//$this->config->get('config_smtp_username');
				//$mail->Password = 'India@123';//$this->config->get('config_smtp_password');
				//$mail->SMTPSecure = 'ssl';
				$mail->SetFrom($from_email, 'India Factoring & Finance Solutions Pvt.Ltd.');
				$mail->Subject = $subject;
				$mail->Body = html_entity_decode($message);
				foreach($to_emails_array as $ekey => $evalue){
					$mail->AddAddress($evalue);
				}
				if($mail->Send()) {
					// echo 'Mail Sent';
					// echo '<br />';
					$this->log->write('Department Rejected Mail Sent');
				} else {
					// echo 'Mail Sent';
					// echo '<br />';
					// echo '<pre>';
					// print_r($mail->ErrorInfo);
					// echo '<br />';
					$this->log->write('Department Rejected Mail Not Sent');
					$this->log->write(print_r($mail->ErrorInfo, true));
				}
				
				/*
				$dept_heads = $this->db->query("SELECT `reporting_to`, `department`, emp_code, `title`, `name`, `email` FROM `oc_employee` WHERE 1=1 AND `emp_code` = '".$leav_data[0]['emp_id']."' ")->row;
				//$message = 'You have a ' . $data['leave_type'] . ' Leave From '. date('d-m-Y', strtotime($data['from'])) . ' to '. date('d-m-Y', strtotime($data['to'])) .' Pending For Approval by Employee ' . $date['e_name'] . "\n\n";
				$message = 'Hello, ' . "<br>";
				$message .= 'Your '.$leav_data[0]['leave_type'].' Leave From '.$from_date.' to '.$to_date.' is Rejected'."<br>";
				$message .= '-- Regards'."<br>";
				$message .= 'Admin.';
				//$message = 'Your '.$leav_data[0]['leave_type'].' Leave From '.$from_date.' to '.$to_date.' is Rejected'."<br>";
				$subject = 'Leave Rejected';
				$from_email = 'alm@indiafactoring.in';
				$to_email = $dept_heads['email'];
				//$to_email = 'eric.fargose@gmail.com';
				$to_name = $dept_heads['title'].' '.$dept_heads['name'];

				require(DIR_SYSTEM . 'library/Mailin.php');
	            $mailin = new Mailin("https://api.sendinblue.com/v2.0","N12OPU6qLfTsxnK7");
	            $mail_data = array( "to" => array($to_email=>$to_name),
	                            "from" => array($from_email, "India Factoring & Finance Solutions Pvt.Ltd."),
	                            "subject" => $subject,
	                            "html" => html_entity_decode($message)
	                         );
	            $mailin->send_email($mail_data);
				*/
				$approve_sql = "DELETE FROM `oc_leave_transaction` WHERE `linked_batch_id` = '".$batch_id."' ";
				$this->db->query($approve_sql);	
			}
			$this->session->data['success'] = 'Leave Cancelled Successfully';

			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}

			if (isset($this->request->get['filter_name_id'])) {
				$url .= '&filter_name_id=' . $this->request->get['filter_name_id'];
			}

			if (isset($this->request->get['filter_name_id_1'])) {
				$url .= '&filter_name_id_1=' . $this->request->get['filter_name_id_1'];
			}

			if (isset($this->request->get['filter_dept'])) {
				$url .= '&filter_dept=' . $this->request->get['filter_dept'];
			}

			if (isset($this->request->get['filter_group'])) {
				$url .= '&filter_group=' . $this->request->get['filter_group'];
			}

			if (isset($this->request->get['filter_unit'])) {
				$url .= '&filter_unit=' . $this->request->get['filter_unit'];
			}

			if (isset($this->request->get['filter_approval_1'])) {
				$url .= '&filter_approval_1=' . $this->request->get['filter_approval_1'];
			}

			if (isset($this->request->get['filter_approval_1_by'])) {
				$url .= '&filter_approval_1_by=' . $this->request->get['filter_approval_1_by'];
			}

			if (isset($this->request->get['filter_approval_2'])) {
				$url .= '&filter_approval_2=' . $this->request->get['filter_approval_2'];
			}

			if (isset($this->request->get['filter_proc'])) {
				$url .= '&filter_proc=' . $this->request->get['filter_proc'];
			}

			if (isset($this->request->get['filter_leavetype'])) {
				$url .= '&filter_leavetype=' . $this->request->get['filter_leavetype'];
			}

			$this->redirect($this->url->link('transaction/leave_ess_dept', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}

		if (isset($this->request->get['filter_name_id'])) {
			$filter_name_id = $this->request->get['filter_name_id'];
		} else {
			$filter_name_id = '';
		}

		if (isset($this->request->get['filter_name_id_1'])) {
			$filter_name_id_1 = $this->request->get['filter_name_id_1'];
		} else {
			$filter_name_id_1 = '';
		}

		if (isset($this->request->get['filter_date'])) {
			$filter_date = $this->request->get['filter_date'];
		} else {
			$filter_date = '';
		}

		if (isset($this->request->get['filter_dept'])) {
			$filter_dept = html_entity_decode($this->request->get['filter_dept']);
		} else {
			$filter_dept = '0';
		}

		if($filter_dept == '0'){
			if(isset($this->session->data['dept_names'])){
				$filter_depts = html_entity_decode($this->session->data['dept_names']);
				$filter_depts = "'" . str_replace(",", "','", html_entity_decode($filter_depts)) . "'";
			} else {
				$filter_depts = '';
			}
		} else {
			$filter_depts = '';
		}

		if (isset($this->request->get['filter_unit'])) {
			$filter_unit = $this->request->get['filter_unit'];
		} else {
			if(isset($this->session->data['unit']) && $this->session->data['d_emp_id'] != '29078'){
				$filter_unit = $this->session->data['unit'];
			} else {
				$filter_unit = '0';
			}
		}

		if (isset($this->request->get['filter_group'])) {
			$filter_group = $this->request->get['filter_group'];
		} else {
			if(isset($this->session->data['is_super']) || isset($this->session->data['is_super1'])){
				$filter_group = 'OFFICIALS';
			} else {
				$filter_group = '0';
			}
		}

		if (isset($this->request->get['filter_approval_1'])) {
			$filter_approval_1 = $this->request->get['filter_approval_1'];
		} else {
			$filter_approval_1 = '1';
		}

		if (isset($this->request->get['filter_approval_1_by'])) {
			$filter_approval_1_by = $this->request->get['filter_approval_1_by'];
		} else {
			$filter_approval_1_by = '0';
		}

		if (isset($this->request->get['filter_approval_2'])) {
			$filter_approval_2 = $this->request->get['filter_approval_2'];
		} else {
			$filter_approval_2 = '0';
		}

		if (isset($this->request->get['filter_proc'])) {
			$filter_proc = $this->request->get['filter_proc'];
		} else {
			$filter_proc = '0';
		}

		if (isset($this->request->get['filter_leavetype'])) {
			$filter_leavetype = $this->request->get['filter_leavetype'];
		} else {
			$filter_leavetype = '0';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . $this->request->get['filter_name'];
		}

		if (isset($this->request->get['filter_name_id'])) {
			$url .= '&filter_name_id=' . $this->request->get['filter_name_id'];
		}

		if (isset($this->request->get['filter_name_id_1'])) {
			$url .= '&filter_name_id_1=' . $this->request->get['filter_name_id_1'];
		}

		if (isset($this->request->get['filter_date'])) {
			$url .= '&filter_date=' . $this->request->get['filter_date'];
		}

		if (isset($this->request->get['filter_dept'])) {
			$url .= '&filter_dept=' . $this->request->get['filter_dept'];
		}

		if (isset($this->request->get['filter_unit'])) {
			$url .= '&filter_unit=' . $this->request->get['filter_unit'];
		}

		if (isset($this->request->get['filter_group'])) {
			$url .= '&filter_group=' . $this->request->get['filter_group'];
		}

		if (isset($this->request->get['filter_approval_1'])) {
			$url .= '&filter_approval_1=' . $this->request->get['filter_approval_1'];
		}

		if (isset($this->request->get['filter_approval_1_by'])) {
			$url .= '&filter_approval_1_by=' . $this->request->get['filter_approval_1_by'];
		}

		if (isset($this->request->get['filter_approval_2'])) {
			$url .= '&filter_approval_2=' . $this->request->get['filter_approval_2'];
		}

		if (isset($this->request->get['filter_proc'])) {
			$url .= '&filter_proc=' . $this->request->get['filter_proc'];
		}

		if (isset($this->request->get['filter_leavetype'])) {
			$url .= '&filter_leavetype=' . $this->request->get['filter_leavetype'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$this->data['breadcrumbs'] = array();

		$this->data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
			'separator' => false
		);

		$this->data['breadcrumbs'][] = array(
			'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('transaction/leave_ess_dept', 'token=' . $this->session->data['token'] . $url, 'SSL'),
			'separator' => ' :: '
		);

		$url_insert = '&filter_name_id='.$filter_name_id.'&filter_name_id_1='.$filter_name_id.'&filter_name='.$filter_name;

		$this->data['insert'] = $this->url->link('transaction/leave_ess_dept/insert', 'token=' . $this->session->data['token'] . $url . $url_insert, 'SSL');
		$this->data['delete'] = $this->url->link('transaction/leave_ess_dept/delete', 'token=' . $this->session->data['token'] . $url . $url_insert, 'SSL');
		$this->data['export'] = $this->url->link('transaction/leave_ess_dept/export', 'token=' . $this->session->data['token'] . $url . $url_insert, 'SSL');
		$this->data['approve'] = $this->url->link('transaction/leave_ess_dept/approve', 'token=' . $this->session->data['token'] . $url . $url_insert, 'SSL');
		
		$this->data['leaves'] = array();
		$employee_total = 0;

		$data = array(
			'filter_name' => $filter_name,
			'filter_name_id' => $filter_name_id,
			'filter_name_id_1' => $filter_name_id_1,
			'filter_date' => $filter_date,
			'filter_dept' => $filter_dept,
			'filter_depts' => $filter_depts,
			'filter_unit' => $filter_unit,
			'filter_group' => $filter_group,
			'filter_approval_1' => $filter_approval_1,
			'filter_approval_1_by' => $filter_approval_1_by,
			'filter_approval_2' => $filter_approval_2,
			'filter_proc' => $filter_proc,
			'filter_leavetype' => $filter_leavetype,
			'start' => ($page - 1) * $this->config->get('config_admin_limit'),
			'limit' => $this->config->get('config_admin_limit')
		);
		$emp_code = $this->session->data['emp_code'];
		
		$employee_total = $this->model_transaction_transaction->getTotalleaveetransaction_ess($data);
		$results = $this->model_transaction_transaction->getleavetransaction_ess_new($data, $emp_code);
		// echo "<pre>";
		// print_r($results);
		// exit;
		foreach ($results as $result) {
			$action = array();
			$emp_group = $this->db->query("SELECT `group` FROM `oc_employee` WHERE `emp_code` = '".$result['emp_id']."' ")->row['group'];
			if($result['reject_date'] == '0000-00-00'){
				if(isset($this->session->data['is_super']) || isset($this->session->data['is_super1'])){
					$leave_sql = "SELECT `id` FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$result['batch_id']."' AND (`approval_2` = '1') ";
					$date_res = $this->db->query($leave_sql);
					if ($date_res->num_rows == 0) {
						$leave_sql = "SELECT `id` FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$result['batch_id']."' AND `p_status` = '1' ";
						$date_res = $this->db->query($leave_sql);
						if($date_res->num_rows == 0){
							//if($result['encash'] == ''){
								$action[] = array(
									'text' => 'Approve',
									'href' => $this->url->link('transaction/leave_ess_dept/approve', 'token=' . $this->session->data['token'] . '&batch_id=' . $result['batch_id'] . $url, 'SSL')
								);
								$leave_sql = "SELECT `id` FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$result['batch_id']."' AND (`approval_1` = '1') ";
								$date_res = $this->db->query($leave_sql);
								if ($date_res->num_rows == 0) {
									$action[] = array(
										'text' => 'Delete',
										'href' => $this->url->link('transaction/leave_ess_dept/delete', 'token=' . $this->session->data['token'] . '&batch_id=' . $result['batch_id'] . $url, 'SSL')
									);
								}
								$action[] = array(
									'text' => 'View',
									'href' => $this->url->link('transaction/leave/getForm', 'token=' . $this->session->data['token'] . '&batch_id=' . $result['batch_id'] . '&filter_name_id=' . $result['emp_id'] . '&unit=' . $result['unit'] . '&leaveprocess=2', 'SSL')
								);
							//}
						} else {
							$action[] = array(
								'text' => '---',
								'href' => ''
							);	
						}
					} else {
						$leave_sql = "SELECT `id` FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$result['batch_id']."' AND `p_status` = '1' ";
						$date_res = $this->db->query($leave_sql);
						if($date_res->num_rows == 0){
							$action[] = array(
								'text' => 'Reject',
								'href' => $this->url->link('transaction/leave_ess_dept/cancel', 'token=' . $this->session->data['token'] . '&batch_id=' . $result['batch_id'] . $url, 'SSL')
							);
							$action[] = array(
								'text' => 'View',
								'href' => $this->url->link('transaction/leave/getForm', 'token=' . $this->session->data['token'] . '&batch_id=' . $result['batch_id'] . '&filter_name_id=' . $result['emp_id'] . '&unit=' . $result['unit'] . '&leaveprocess=2', 'SSL')
							);
						} else {
							$action[] = array(
								'text' => '---',
								'href' => ''
							);	
						}
					}
				//} elseif(isset($this->session->data['is_dept'])) {
				} else {

					$leave_sql = "SELECT `id` FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$result['batch_id']."' AND (`approval_1` = '1') ";
					$date_res = $this->db->query($leave_sql);

					if ($date_res->num_rows == 0) {
						
						$leave_sql = "SELECT `id` FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$result['batch_id']."' AND `p_status` = '1' ";
						$date_res = $this->db->query($leave_sql);
						if($date_res->num_rows == 0){
							//if($result['encash'] == ''){
								//if(isset($this->session->data['d_emp_id']) && $result['emp_id'] != $this->session->data['d_emp_id']){
									$action[] = array(
										'text' => 'Approve',
										'href' => $this->url->link('transaction/leave_ess_dept/approve', 'token=' . $this->session->data['token'] . '&batch_id=' . $result['batch_id'] . $url, 'SSL')
									);
									if($result['approval_1'] != '2') {
										$action[] = array(
										'text' => 'Reject',
										'href' => $this->url->link('transaction/leave_ess_dept/cancel', 'token=' . $this->session->data['token'] . '&batch_id=' . $result['batch_id'] . $url, 'SSL')
										);
									}
								//}
								
								// $leave_sql = "SELECT `id` FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$result['batch_id']."' AND (`approval_2` = '1') ";
								// $date_res = $this->db->query($leave_sql);
								// if ($date_res->num_rows == 0) {
								// 	$action[] = array(
								// 		'text' => 'Delete',
								// 		'href' => $this->url->link('transaction/leave_ess_dept/delete', 'token=' . $this->session->data['token'] . '&batch_id=' . $result['batch_id'] . $url, 'SSL')
								// 	);
								// }
								
								// $action[] = array(
								// 	'text' => 'View',
								// 	'href' => $this->url->link('transaction/leave/getForm', 'token=' . $this->session->data['token'] . '&batch_id=' . $result['batch_id'] . '&filter_name_id=' . $result['emp_id'] . '&unit=' . $result['unit'] . '&leaveprocess=2', 'SSL')
								// );
							//}
						} else {
							$action[] = array(
								'text' => '---',
								'href' => ''
							);	
						}
					} else {
						
						$leave_sql = "SELECT `id` FROM `oc_leave_transaction_temp` WHERE `batch_id` = '".$result['batch_id']."' AND `p_status` = '1' ";
						$date_res = $this->db->query($leave_sql);
						if($date_res->num_rows == 0){
							//if(isset($this->session->data['d_emp_id']) && $result['emp_id'] != $this->session->data['d_emp_id']){
								$action[] = array(
									'text' => 'Reject',
									'href' => $this->url->link('transaction/leave_ess_dept/cancel', 'token=' . $this->session->data['token'] . '&batch_id=' . $result['batch_id'] . $url, 'SSL')
								);

								// $action[] = array(
								// 	'text' => 'View',
								// 	'href' => $this->url->link('transaction/leave/getForm', 'token=' . $this->session->data['token'] . '&batch_id=' . $result['batch_id'] . '&filter_name_id=' . $result['emp_id'] . '&unit=' . $result['unit'] . '&leaveprocess=2', 'SSL')
								// );
							//}
						} else {
							$action[] = array(
								'text' => '---',
								'href' => ''
							);	
						}
					}
				}
			} else {
				if(isset($this->session->data['d_emp_id']) && $result['emp_id'] != $this->session->data['d_emp_id']){
					$action[] = array(
						'text' => 'Delete',
						'href' => $this->url->link('transaction/leave_ess_dept/delete', 'token=' . $this->session->data['token'] . '&batch_id=' . $result['batch_id'] . $url, 'SSL')
					);
					$action[] = array(
						'text' => 'View',
						'href' => $this->url->link('transaction/leave/getForm', 'token=' . $this->session->data['token'] . '&batch_id=' . $result['batch_id'] . '&filter_name_id=' . $result['emp_id'] . '&unit=' . $result['unit'] . '&leaveprocess=2', 'SSL')
					);
				}
			}

			$total_leave_dayss = $this->model_transaction_transaction->gettotal_leave_days_ess($result['batch_id']);
			if($total_leave_dayss['days'] == ''){
				$total_leave_days = $total_leave_dayss['leave_amount'];
			} else {
				$total_leave_days = $total_leave_dayss['days'];
			}
			$leave_from = $this->model_transaction_transaction->getleave_from_ess($result['batch_id']);
			$leave_to = $this->model_transaction_transaction->getleave_to_ess($result['batch_id']);

			$emp_data = $this->model_transaction_transaction->getempdata($result['emp_id']);

			if($result['a_status'] == '1'){
				$proc_stat = 'Processed';
			} else {
				$proc_stat = 'UnProcessed';
			}

			if($result['approval_1'] == '1'){
				if($result['approval_date_1'] != '0000-00-00 00:00:00'){
					$approval_1 = 'Approved on ' . date('d-m-y h:i:s', strtotime($result['approval_date_1']));
				} else {
					$approval_1 = 'Approved';
				}
			} elseif($result['approval_1'] == '2') {
				$approval_1 = 'Rejected';
			} else {
				$approval_1 = 'Pending';
			}

			if($result['approval_2'] == '1'){
				if($result['approval_date_2'] != '0000-00-00 00:00:00'){
					$approval_2 = 'Approved on ' . date('d-m-y h:i:s', strtotime($result['approval_date_2']));
				} else {
					$approval_2 = 'Approved';
				}
			} else {
				$approval_2 = 'Pending';
			}

			if($result['leave_type'] == 'COF'){
				$leave_type = $result['leave_type'].' / '.$result['date_cof'];
			} else {
				$leave_type = $result['leave_type'];
			}

			if($result['reject_date'] != '0000-00-00'){
				if($result['reject_reason'] != ''){
					$reject_reason = $result['reject_reason'].' - as on '.date('d-m-y', strtotime($result['reject_date']));
				} else {
					$reject_reason = 'as on '.date('d-m-y', strtotime($result['reject_date']));
				}
			} elseif($result['reject_date_1'] != '0000-00-00'){
				if($result['reject_reason_1'] != ''){
					$reject_reason = $result['reject_reason_1'].' - as on '.date('d-m-y', strtotime($result['reject_date_1']));
				} else {
					$reject_reason = 'as on '.date('d-m-y', strtotime($result['reject_date_1']));
				}
			} elseif($result['reject_date_2'] != '0000-00-00'){
				if($result['reject_reason_2'] != ''){
					$reject_reason = $result['reject_reason_2'].' - as on '.date('d-m-y', strtotime($result['reject_date_2']));
				} else {
					$reject_reason = 'as on '.date('d-m-y', strtotime($result['reject_date_2']));
				}
			} else {
				$reject_reason = '';
			}

			$this->data['leaves'][] = array(
				'batch_id' => $result['batch_id'],
				'dot' => date('d-m-y', strtotime($result['dot'])),
				'leave_reason' => $result['leave_reason'],
				'reject_reason' => $reject_reason,
				'encash' => $result['encash'],
				'id' => $result['id'],
				'emp_id' => $result['emp_id'],
				'name' => $emp_data['name'],
				'unit' => $emp_data['unit'],
				'group' => $emp_group,
				'dept' => $emp_data['department'],
				'leave_type'        => $leave_type,
				'total_leave_days' 	      => $total_leave_days,
				'leave_from' => date('d-m-y', strtotime($leave_from)),
				'leave_to' => date('d-m-y', strtotime($leave_to)),
				'approval_1' => $approval_1,
				'approval_2' => $approval_2,
				'approval_1_by' => $result['approved_1_by'],
				'proc_stat' => $proc_stat,
				'selected'        => isset($this->request->post['selected']) && in_array($result['id'], $this->request->post['selected']),
				'action'          => $action
			);
		}

		// echo '<pre>';
		// print_r($this->data['leaves']);
		// exit;

		$unit_data = array(
			'0' => 'All',
			'Mumbai' => 'Mumbai',
			'Pune' => 'Pune',
			'Delhi' => 'Delhi',
			'Chennai' => 'Chennai',
			'Bangalore' => 'Bangalore',
			'Ahmedabad' => 'Ahmedabad',
			'SaiSiddhiServices' => 'Sai Siddhi Services',
			'MonitronSecurity' => 'Monitron Security',
			'AdeccoofficeboysMumbai' => 'Adecco office boys - Mumbai',
			'AdeccoofficeboysDelhi' => 'Adecco office boys - Delhi',
			'AdeccoofficeboysPune' => 'Adecco office boys - Pune',
			'AdeccoofficeboysChennai' => 'Adecco office boys - Chennai',
			'AdeccoofficeboysBangalore' => 'Adecco office boys - Bangalore',
			'AdeccoofficeboysAhmedabad' => 'Adecco office boys - Ahmedabad',
			'Coimbatore' => 'Coimbatore',
		);

		$this->data['unit_data'] = $unit_data;

		$approves = array(
			'0' => 'All',
			'1' => 'Pending',
			'2' => 'Approved',
			'3' => 'Rejected'
		);

		$this->data['approves'] = $approves;

		$process = array(
			'0' => 'All',
			'1' => 'UnProcessed',
			'2' => 'Processed',
		);

		$this->data['process'] = $process;

		$sql = "SELECT `emp_code`, `name`, `title` FROM `oc_employee` WHERE `is_dept` = '1' AND `is_super` = '0' ";
		if(isset($this->session->data['dept_name'])){
			$sql .= " AND `department` = '".$this->session->data['dept_name']."' ";
		}
		$dept_headsss = $this->db->query($sql);
		$dept_heads['0'] = 'All';
		if($dept_headsss->num_rows > 0){
			$dept_headss = $dept_headsss->rows;
			foreach($dept_headss as $dkey => $dvalue){
				$dept_heads[$dvalue['emp_code']] = $dvalue['name'];
			}
		}
		// $dept_heads = array(
		// 	'0' => 'All',
		// 	'21463' => 'Everest Fargose',
		// 	'29124' => 'Dinesh Bachav',
		// );

		$this->data['dept_heads'] = $dept_heads;


		$wfhs = array(
			'0' => 'All',
			'PL' => 'PL',
			'CL' => 'CL',
			'BL' => 'BL',
			'SL' => 'SL',
			'LWP' => 'LWP',
			'ML' => 'ML',
			'MAL' => 'MAL',
			'PAL' => 'PAL',
			'OD' => 'OD',
			'Covid19' => 'Covid19',
			/****Start - WFH 20240110*********/
			'WFH'=>'WFH'
			/****End - WFH 20240110*********/
		);
		$this->data['leavess'] = $wfhs;

		$dept_head_count = 1;
		$dept_head_list = array();
		if(isset($this->session->data['is_dept'])){
			$dept_head_lists = explode(',', $this->session->data['dept_names']);
			$dept_head_count = count($dept_head_lists);
			foreach($dept_head_lists as $dkey => $dvalue){
				$dept_head_list[html_entity_decode(strtolower(trim($dvalue)))] = html_entity_decode(strtolower(trim($dvalue)));
			}
		}
		$this->data['dept_head_count'] = $dept_head_count;	

		$department_datas = $this->model_report_attendance->getdepartment_list();
		$department_data = array();
		if($dept_head_list){
			$department_data['0'] = 'All';
			foreach ($department_datas as $dkey => $dvalue) {
				$dvalue['department'] = (strtolower(trim($dvalue['department'])));
				if(in_array($dvalue['department'], $dept_head_list) ){
					$department_data[$dvalue['department']] = $dvalue['department'];
				}
			}
		} else {
			$department_data['0'] = 'All';
			foreach ($department_datas as $dkey => $dvalue) {
				$department_data[$dvalue['department']] = $dvalue['department'];
			}
		}
		$this->data['dept_data'] = $department_data;

		$group_datas = $this->model_report_attendance->getgroup_list();
		$group_data = array();
		$group_data['0'] = 'All';
		foreach ($group_datas as $gkey => $gvalue) {
			$group_data[$gvalue['group']] = $gvalue['group'];
		}
		$this->data['group_data'] = $group_data;

		$this->data['token'] = $this->session->data['token'];	

		$this->data['heading_title'] = $this->language->get('heading_title');

		$this->data['text_no_results'] = $this->language->get('text_no_results');
		$this->data['text_delete'] = $this->language->get('text_delete');

		$this->data['button_insert'] = $this->language->get('button_insert');

		$this->data['button_filter'] = $this->language->get('button_filter');

		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {
			$this->data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$this->data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$this->data['success'] = '';
		}

		$url = '';

		// if (isset($this->request->get['page'])) {
		// 	$url .= '&page=' . $this->request->get['page'];
		// }

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . $this->request->get['filter_name'];
		}

		if (isset($this->request->get['filter_name_id'])) {
			$url .= '&filter_name_id=' . $this->request->get['filter_name_id'];
		}

		if (isset($this->request->get['filter_name_id_1'])) {
			$url .= '&filter_name_id_1=' . $this->request->get['filter_name_id_1'];
		}

		if (isset($this->request->get['filter_date'])) {
			$url .= '&filter_date=' . $this->request->get['filter_date'];
		}

		if (isset($this->request->get['filter_dept'])) {
			$url .= '&filter_dept=' . $this->request->get['filter_dept'];
		}

		if (isset($this->request->get['filter_unit'])) {
			$url .= '&filter_unit=' . $this->request->get['filter_unit'];
		}

		if (isset($this->request->get['filter_group'])) {
			$url .= '&filter_group=' . $this->request->get['filter_group'];
		}

		if (isset($this->request->get['filter_approval_1'])) {
			$url .= '&filter_approval_1=' . $this->request->get['filter_approval_1'];
		}

		if (isset($this->request->get['filter_approval_1_by'])) {
			$url .= '&filter_approval_1_by=' . $this->request->get['filter_approval_1_by'];
		}

		if (isset($this->request->get['filter_approval_2'])) {
			$url .= '&filter_approval_2=' . $this->request->get['filter_approval_2'];
		}

		if (isset($this->request->get['filter_proc'])) {
			$url .= '&filter_proc=' . $this->request->get['filter_proc'];
		}

		if (isset($this->request->get['filter_leavetype'])) {
			$url .= '&filter_leavetype=' . $this->request->get['filter_leavetype'];
		}

		$pagination = new Pagination();
		$pagination->total = $employee_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_admin_limit');
		$pagination->text = $this->language->get('text_pagination');
		$pagination->url = $this->url->link('transaction/leave_ess_dept', 'token=' . $this->session->data['token'] . $url . '&page={page}', 'SSL');

		$this->data['pagination'] = $pagination->render();

		
		$this->data['filter_name'] = $filter_name;
		$this->data['filter_name_id'] = $filter_name_id;
		$this->data['filter_name_id_1'] = $filter_name_id_1;
		$this->data['filter_date'] = $filter_date;
		$this->data['filter_dept'] = $filter_dept;
		$this->data['filter_unit'] = $filter_unit;
		$this->data['filter_group'] = $filter_group;
		$this->data['filter_approval_1'] = $filter_approval_1;
		$this->data['filter_approval_1_by'] = $filter_approval_1_by;
		$this->data['filter_approval_2'] = $filter_approval_2;
		$this->data['filter_proc'] = $filter_proc;
		$this->data['filter_leavetype'] = $filter_leavetype;
		
		$this->template = 'transaction/leave_ess_dept_list.tpl';
		$this->children = array(
			'common/header',
			'common/footer'
		);

		$this->response->setOutput($this->render());
	}

	protected function getForm() {
		$this->data['heading_title'] = $this->language->get('heading_title');

		
		$this->data['button_save'] = $this->language->get('button_save');
		$this->data['button_cancel'] = $this->language->get('button_cancel');

		$this->data['text_no_results'] = $this->language->get('text_no_results');

		$this->data['tab_general'] = $this->language->get('tab_general');

		if (isset($this->session->data['success'])) {
			$this->data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$this->data['success'] = '';
		}

		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {	
			$this->data['error_warning'] = '';
		}

		if (isset($this->error['encash'])) {
			$this->data['error_encash'] = $this->error['encash'];
		} else {
			$this->data['error_encash'] = '';
		}

		if (isset($this->error['days'])) {
			$this->data['error_days'] = $this->error['days'];
		} else {
			$this->data['error_days'] = '';
		}

		if (isset($this->error['leave_type'])) {
			$this->data['error_leave_type'] = $this->error['leave_type'];
		} else {
			$this->data['error_leave_type'] = '';
		}

		$this->data['breadcrumbs'] = array();

		$this->data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
			'separator' => false
		);

		$this->data['breadcrumbs'][] = array(
			'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('transaction/leave_ess_dept', 'token=' . $this->session->data['token'], 'SSL'),
			'separator' => ' :: '
		);

		
		$url = '';
		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . $this->request->get['filter_name'];
		}

		if (isset($this->request->get['filter_name_id'])) {
			$url .= '&filter_name_id=' . $this->request->get['filter_name_id'];
		}

		if (isset($this->request->get['filter_name_id_1'])) {
			$url .= '&filter_name_id_1=' . $this->request->get['filter_name_id_1'];
		}

		if (isset($this->request->get['filter_dept'])) {
			$url .= '&filter_dept=' . $this->request->get['filter_dept'];
		}

		if (isset($this->request->get['filter_group'])) {
			$url .= '&filter_group=' . $this->request->get['filter_group'];
		}

		if (isset($this->request->get['filter_unit'])) {
			$url .= '&filter_unit=' . $this->request->get['filter_unit'];
		}

		if (isset($this->request->get['filter_approval_1'])) {
			$url .= '&filter_approval_1=' . $this->request->get['filter_approval_1'];
		}

		if (isset($this->request->get['filter_approval_1_by'])) {
			$url .= '&filter_approval_1_by=' . $this->request->get['filter_approval_1_by'];
		}

		if (isset($this->request->get['filter_approval_2'])) {
			$url .= '&filter_approval_2=' . $this->request->get['filter_approval_2'];
		}

		if (isset($this->request->get['filter_proc'])) {
			$url .= '&filter_proc=' . $this->request->get['filter_proc'];
		}

		if (isset($this->request->get['filter_leavetype'])) {
			$url .= '&filter_leavetype=' . $this->request->get['filter_leavetype'];
		}

		$this->data['cancel'] = $this->url->link('transaction/leave_ess_dept', 'token=' . $this->session->data['token'].$url, 'SSL');
		$this->data['action'] = $this->url->link('transaction/leave_ess_dept/insert', 'token=' . $this->session->data['token'].$url, 'SSL');

		
		$transaction_data = array();
		$emp_data = array();
		if (isset($this->request->get['batch_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$transaction_data = $this->model_transaction_transaction->getleave_transaction_data_ess($this->request->get['batch_id']);
			$emp_data = $this->model_transaction_transaction->getEmployees_dat($this->request->get['filter_name_id']);
		} elseif(isset($this->request->get['filter_name_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')){
			$emp_data = $this->model_transaction_transaction->getEmployees_dat($this->request->get['filter_name_id']);
		} elseif(isset($this->request->get['filter_name_id_1']) && ($this->request->server['REQUEST_METHOD'] != 'POST')){
			$emp_data = $this->model_transaction_transaction->getEmployees_dat($this->request->get['filter_name_id_1']);
		}

		$this->data['token'] = $this->session->data['token'];

		$wfh = array(
			'0' => array(
				'leave_id' => 'PL',
				'leave_name' => 'PL'
			),
			'9' => array(
				'leave_id' => 'CL',
				'leave_name' => 'CL'
			),
			'1' => array(
				'leave_id' => 'BL',
				'leave_name' => 'BL'
			),
			'2' => array(
				'leave_id' => 'SL',
				'leave_name' => 'SL'
			),
			'3' => array(
				'leave_id' => 'ML',
				'leave_name' => 'ML'
			),
			//'4' => array(
				//'leave_id' => 'PLE',
				//'leave_name' => 'PLE'
			//),
			'5' => array(
				'leave_id' => 'MAL',
				'leave_name' => 'MAL'
			),
			'6' => array(
				'leave_id' => 'PAL',
				'leave_name' => 'PAL'
			),
			'7' => array(
				'leave_id' => 'OD',
				'leave_name' => 'OD'
			),
			'8' => array(
				'leave_id' => 'LWP',
				'leave_name' => 'LWP'
			),
			'10' => array(
				'leave_id' => 'Covid19',
				'leave_name' => 'Covid19'
			),
		);
		
		$this->data['leaves'] = $wfh;

		if (isset($this->request->post['insert'])) {
			$this->data['insert'] = $this->request->post['insert'];
		} elseif(isset($transaction_data[0]['transaction_id'])) {
			$this->data['insert'] = 0;
		} else {
			$this->data['insert'] = '';
		}

		if (isset($this->request->post['batch_id'])) {
			$this->data['batch_id'] = $this->request->post['batch_id'];
		} elseif(isset($transaction_data[0]['batch_id'])) {
			$this->data['batch_id'] = $transaction_data[0]['batch_id'];
		} else {	
			$this->data['batch_id'] = 0;
		}

		if (isset($this->request->post['leave_type'])) {
			$this->data['leave_type'] = $this->request->post['leave_type'];
		} elseif(isset($transaction_data[0]['leave_type'])) {
			$this->data['leave_type'] = $transaction_data[0]['leave_type'];
		} else {	
			$this->data['leave_type'] = 'PL';
		}

		if (isset($this->request->post['from'])) {
			$this->data['from'] = $this->request->post['from'];
		} elseif(isset($transaction_data[0]['from'])) {
			$this->data['from'] = $transaction_data[0]['from'];
		} else {	
			$this->data['from'] = date('Y-m-d');
		}

		if (isset($this->request->post['to'])) {
			$this->data['to'] = $this->request->post['to'];
		} elseif(isset($transaction_data[0]['to'])) {
			$this->data['to'] = $transaction_data[0]['to'];
		} else {	
			$this->data['to'] = date('Y-m-d');
		}

		if (isset($this->request->post['leave_amount'])) {
			$this->data['leave_amount'] = $this->request->post['leave_amount'];
		} elseif (isset($transaction_data[0]['leave_amount'])) {
			$this->data['leave_amount'] = $transaction_data[0]['leave_amount'];
		} else {	
			$this->data['leave_amount'] = '';//date('d-m-Y');
		}

		if (isset($this->request->post['type'])) {
			$this->data['type'] = $this->request->post['type'];
		} elseif (isset($transaction_data[0]['type'])) {
			$this->data['type'] = $transaction_data[0]['type'];
		} else {	
			$this->data['type'] = 'F';//date('d-m-Y');
		}

		if (isset($this->request->post['days'])) {
			$this->data['days'] = $this->request->post['days'];
		} elseif (isset($transaction_data[0]['days'])) {
			$this->data['days'] = $transaction_data[0]['days'];
		} else {	
			$this->data['days'] = '';//date('d-m-Y');
		}

		if (isset($this->request->post['encash'])) {
			$this->data['encash'] = $this->request->post['encash'];
		} elseif (isset($transaction_data[0]['encash'])) {
			$this->data['encash'] = $transaction_data[0]['encash'];
		} else {	
			$this->data['encash'] = '';//date('d-m-Y');
		}

		if (isset($this->request->post['e_name'])) {
			$this->data['e_name'] = $this->request->post['e_name'];
			$this->data['e_name_id'] = $this->request->post['e_name_id'];
			$this->data['emp_code'] = $this->request->post['e_name_id'];
			$this->data['group'] = $this->request->post['group'];
		} 
		// elseif (isset($transaction_data[0]['emp_id'])) {
		// 	$this->data['e_name'] = $transaction_data[0]['emp_name'];
		// 	$this->data['e_name_id'] = $transaction_data[0]['emp_id'];
		// 	$this->data['emp_code'] = $transaction_data[0]['emp_id'];
		// } 
		elseif (isset($emp_data['emp_code'])) {
			$this->data['e_name'] = $emp_data['name'];
			$this->data['e_name_id'] = $emp_data['emp_code'];
			$this->data['emp_code'] = $emp_data['emp_code'];
			$this->data['group'] = $emp_data['group'];
		} else {	
			$this->data['e_name'] = '';
			$this->data['e_name_id'] = '';
			$this->data['emp_code'] = '';
			$this->data['group'] = '';
		}

		if (isset($this->request->post['a_status'])) {
			$this->data['a_status'] = $this->request->post['a_status'];
		} elseif (isset($transaction_data[0]['a_status'])) {
			$this->data['a_status'] = $transaction_data[0]['a_status'];
		} else {	
			$this->data['a_status'] = 1;//date('d-m-Y');
		}

		if (isset($this->request->post['date_cof'])) {
			$this->data['date_cof'] = $this->request->post['date_cof'];
		} elseif (isset($transaction_data[0]['a_status'])) {
			$this->data['date_cof'] = $transaction_data[0]['date_cof'];
		} else {	
			$this->data['date_cof'] = '';//date('d-m-Y');
		}

		if (isset($this->request->post['dot'])) {
			$this->data['dot'] = $this->request->post['dot'];
		} elseif (isset($transaction_data[0]['dot'])) {
			$this->data['dot'] = $transaction_data[0]['dot'];
		} else {	
			$this->data['dot'] = '';//date('d-m-Y');
		}

		if (isset($this->request->post['leave_reason'])) {
			$this->data['leave_reason'] = $this->request->post['leave_reason'];
		} elseif (isset($transaction_data[0]['leave_reason'])) {
			$this->data['leave_reason'] = $transaction_data[0]['leave_reason'];
		} else {	
			$this->data['leave_reason'] = '';//date('d-m-Y');
		}

		if (isset($this->request->post['diffDays'])) {
			$this->data['diffDays'] = $this->request->post['diffDays'];
		} else {	
			$this->data['diffDays'] = 1;
		}

		if (isset($this->request->post['encash_done_year'])) {
			$this->data['encash_done_year'] = $this->request->post['encash_done_year'];
		} elseif(isset($emp_data['emp_code'])) {
			$emp_code = $emp_data['emp_code'];
			$is_exist = $this->model_transaction_transaction->getpltakenyear_ess($emp_code);
			if(isset($is_exist['id'])){
				$this->data['encash_done_year'] = 1;
			} else {
				$this->data['encash_done_year'] = 0;
			}
		} else {	
			$this->data['encash_done_year'] = 0;
		}

		$statuses = array(
			'0' => 'InActive',
			'1' => 'Active'
		);
		$this->data['statuses'] = $statuses;

		if(isset($this->request->post['multi_day'])){
			$this->data['multi_day'] = $this->request->post['multi_day'];
		} else { 
			$total_leave_dayss = $this->model_transaction_transaction->gettotal_leave_days_ess($this->data['batch_id']);
			if(isset($total_leave_dayss['days'])){
				if($total_leave_dayss['days'] == ''){
					$total_leave_days = $total_leave_dayss['leave_amount'];
				} else {
					$total_leave_days = $total_leave_dayss['days'];
				}
			} else {
				$total_leave_days = 0;
			}
			if($total_leave_days > 0){
				$this->data['multi_day'] = 1;
			} else {
				$this->data['multi_day'] = 0;
			}
		}

		if(isset($this->request->post['enable_encash'])){
			$this->data['enable_encash'] = $this->request->post['enable_encash'];
		} else { 
			$this->data['enable_encash'] = 0;
		}

		$this->data['total_bal_pl'] = 0;
		if($this->data['emp_code']){
			$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($this->data['emp_code']);
			
			$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->data['emp_code'], 'PL');
			$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->data['emp_code'], 'PL');
			$this->data['total_bal_pl'] = 0;
			if(isset($total_bal['pl_acc'])){
				if(isset($total_bal_pro['bal_p'])){
					$this->data['total_bal_pl'] = $total_bal['pl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro['encash'] + $total_bal_pro1['leave_amount']);
				} else {
					$this->data['total_bal_pl'] = $total_bal['pl_acc'];
				}
			}

			//$total_bal_cl = $this->model_transaction_transaction->gettotal_bal($this->data['emp_code']);
			$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->data['emp_code'], 'CL');
			$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->data['emp_code'], 'CL');
			$this->data['total_bal_cl'] = 0;
			if(isset($total_bal['cl_acc'])){
				if(isset($total_bal_pro['bal_p'])){
					$this->data['total_bal_cl'] = $total_bal['cl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
				} else {
					$this->data['total_bal_cl'] = $total_bal['cl_acc'];
				}
			}

			$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->data['emp_code'], 'BL');
			$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->data['emp_code'], 'BL');
			$this->data['total_bal_bl'] = 0;
			if(isset($total_bal['bl_acc'])){
				if(isset($total_bal_pro['bal_p'])){
					$this->data['total_bal_bl'] = $total_bal['bl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
				} else {
					$this->data['total_bal_bl'] = $total_bal['bl_acc'];
				}
			}

			//$total_bal_sl = $this->model_transaction_transaction->gettotal_bal($this->data['emp_code']);
			$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->data['emp_code'], 'SL');
			$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->data['emp_code'], 'SL');
			$this->data['total_bal_sl'] = 0;
			if(isset($total_bal['sl_acc'])){
				if(isset($total_bal_pro['bal_p'])){
					$this->data['total_bal_sl'] = $total_bal['sl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
				} else {
					$this->data['total_bal_sl'] = $total_bal['sl_acc'];
				}
			}

			$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->data['emp_code'], 'LWP');
			$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->data['emp_code'], 'LWP');
			$this->data['total_bal_lwp'] = 0;
			if(isset($total_bal['lwp_acc'])){
				if(isset($total_bal_pro['bal_p'])){
					$this->data['total_bal_lwp'] = $total_bal['lwp_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
				} else {
					$this->data['total_bal_lwp'] = $total_bal['lwp_acc'];
				}
			}

			$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->data['emp_code'], 'ML');
			$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->data['emp_code'], 'ML');
			$this->data['total_bal_ml'] = 0;
			if(isset($total_bal['ml_acc'])){
				if(isset($total_bal_pro['bal_p'])){
					$this->data['total_bal_ml'] = $total_bal['ml_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
				} else {
					$this->data['total_bal_ml'] = $total_bal['ml_acc'];
				}
			}

			$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->data['emp_code'], 'MAL');
			$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->data['emp_code'], 'MAL');
			$this->data['total_bal_mal'] = 0;
			if(isset($total_bal['mal_acc'])){
				if(isset($total_bal_pro['bal_p'])){
					$this->data['total_bal_mal'] = $total_bal['mal_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
				} else {
					$this->data['total_bal_mal'] = $total_bal['mal_acc'];
				}
			}

			$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->data['emp_code'], 'PAL');
			$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->data['emp_code'], 'PAL');
			$this->data['total_bal_pal'] = 0;
			if(isset($total_bal['pal_acc'])){
				if(isset($total_bal_pro['bal_p'])){
					$this->data['total_bal_pal'] = $total_bal['pal_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
				} else {
					$this->data['total_bal_pal'] = $total_bal['pal_acc'];
				}
			}

			$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->data['emp_code'], 'Covid19');
			$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->data['emp_code'], 'Covid19');
			$this->data['total_bal_covid'] = 0;
			if(isset($total_bal['covid_acc'])){
				if(isset($total_bal_pro['bal_p'])){
					$this->data['total_bal_covid'] = $total_bal['covid_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
				} else {
					$this->data['total_bal_covid'] = $total_bal['covid_acc'];
				}
			}

			$total_bal_p = $this->model_transaction_transaction->gettotal_bal_p_ess($this->data['emp_code'], 'PL');
			$total_bal_p1 = $this->model_transaction_transaction->gettotal_bal_p1_ess($this->data['emp_code'], 'PL');
			$this->data['total_bal_pl_p'] = 0;
			if(isset($total_bal_p['bal_p'])){
				if(isset($total_bal['pl_acc'])){
					//$this->data['total_bal_pl_p'] = $total_bal['pl_acc'] - $total_bal_p['bal_p'];
					$this->data['total_bal_pl_p'] = $total_bal_p['bal_p'] + $total_bal_p['encash'] + $total_bal_p1['leave_amount'];
				}
			}

			$total_bal_p = $this->model_transaction_transaction->gettotal_bal_p_ess($this->data['emp_code'], 'CL');
			$total_bal_p1 = $this->model_transaction_transaction->gettotal_bal_p1_ess($this->data['emp_code'], 'CL');
			$this->data['total_bal_cl_p'] = 0;
			if(isset($total_bal_p['bal_p'])){
				if(isset($total_bal['cl_acc'])){
					//$this->data['total_bal_cl_p'] = $total_bal['cl_acc'] - $total_bal_p['bal_p'];
					$this->data['total_bal_cl_p'] = $total_bal_p['bal_p'] + $total_bal_p1['leave_amount'];
				}
			}

			$total_bal_p = $this->model_transaction_transaction->gettotal_bal_p_ess($this->data['emp_code'], 'BL');
			$total_bal_p1 = $this->model_transaction_transaction->gettotal_bal_p1_ess($this->data['emp_code'], 'BL');
			$this->data['total_bal_bl_p'] = 0;
			if(isset($total_bal_p['bal_p'])){
				if(isset($total_bal['bl_acc'])){
					//$this->data['total_bal_bl_p'] = $total_bal['bl_acc'] - $total_bal_p['bal_p'];
					$this->data['total_bal_bl_p'] = $total_bal_p['bal_p'] + $total_bal_p1['leave_amount'];
				}
			}

			$total_bal_p = $this->model_transaction_transaction->gettotal_bal_p_ess($this->data['emp_code'], 'SL');
			$total_bal_p1 = $this->model_transaction_transaction->gettotal_bal_p1_ess($this->data['emp_code'], 'SL');
			$this->data['total_bal_sl_p'] = 0;
			if(isset($total_bal_p['bal_p'])){
				if(isset($total_bal['sl_acc'])){
					//$this->data['total_bal_sl_p'] = $total_bal['sl_acc'] - $total_bal_p['bal_p'];
					$this->data['total_bal_sl_p'] = $total_bal_p['bal_p'] + $total_bal_p1['leave_amount'];
				}
			}

			$total_bal_p = $this->model_transaction_transaction->gettotal_bal_p_ess($this->data['emp_code'], 'LWP');
			$total_bal_p1 = $this->model_transaction_transaction->gettotal_bal_p1_ess($this->data['emp_code'], 'LWP');
			$this->data['total_bal_lwp_p'] = 0;
			if(isset($total_bal_p['bal_p'])){
				if(isset($total_bal['lwp_acc'])){
					//$this->data['total_bal_sl_p'] = $total_bal['sl_acc'] - $total_bal_p['bal_p'];
					$this->data['total_bal_lwp_p'] = $total_bal_p['bal_p'] + $total_bal_p1['leave_amount'];
				}
			}

			$total_bal_p = $this->model_transaction_transaction->gettotal_bal_p_ess($this->data['emp_code'], 'ML');
			$total_bal_p1 = $this->model_transaction_transaction->gettotal_bal_p1_ess($this->data['emp_code'], 'ML');
			$this->data['total_bal_ml_p'] = 0;
			if(isset($total_bal_p['bal_p'])){
				if(isset($total_bal['ml_acc'])){
					//$this->data['total_bal_sl_p'] = $total_bal['sl_acc'] - $total_bal_p['bal_p'];
					$this->data['total_bal_ml_p'] = $total_bal_p['bal_p'] + $total_bal_p1['leave_amount'];
				}
			}

			$total_bal_p = $this->model_transaction_transaction->gettotal_bal_p_ess($this->data['emp_code'], 'MAL');
			$total_bal_p1 = $this->model_transaction_transaction->gettotal_bal_p1_ess($this->data['emp_code'], 'MAL');
			$this->data['total_bal_mal_p'] = 0;
			if(isset($total_bal_p['bal_p'])){
				if(isset($total_bal['mal_acc'])){
					//$this->data['total_bal_sl_p'] = $total_bal['sl_acc'] - $total_bal_p['bal_p'];
					$this->data['total_bal_mal_p'] = $total_bal_p['bal_p'] + $total_bal_p1['leave_amount'];
				}
			}

			$total_bal_p = $this->model_transaction_transaction->gettotal_bal_p_ess($this->data['emp_code'], 'PAL');
			$total_bal_p1 = $this->model_transaction_transaction->gettotal_bal_p1_ess($this->data['emp_code'], 'PAL');
			$this->data['total_bal_pal_p'] = 0;
			if(isset($total_bal_p['bal_p'])){
				if(isset($total_bal['pal_acc'])){
					//$this->data['total_bal_sl_p'] = $total_bal['sl_acc'] - $total_bal_p['bal_p'];
					$this->data['total_bal_pal_p'] = $total_bal_p['bal_p'] + $total_bal_p1['leave_amount'];
				}
			}

			$total_bal_p = $this->model_transaction_transaction->gettotal_bal_p_ess($this->data['emp_code'], 'Covid19');
			$total_bal_p1 = $this->model_transaction_transaction->gettotal_bal_p1_ess($this->data['emp_code'], 'Covid19');
			$this->data['total_bal_covid_p'] = 0;
			if(isset($total_bal_p['bal_p'])){
				if(isset($total_bal['covid_acc'])){
					//$this->data['total_bal_sl_p'] = $total_bal['sl_acc'] - $total_bal_p['bal_p'];
					$this->data['total_bal_covid_p'] = $total_bal_p['bal_p'] + $total_bal_p1['leave_amount'];
				}
			}
			// echo '<pre>';
			// print_r($this->data['total_bal_sl']);
			// echo '<pre>';
			// print_r($this->data['total_bal_sl_p']);
			// exit;
		}

		if($this->request->server['REQUEST_METHOD'] == 'POST') {
			$this->data['post_status'] = 1;
		} else {
			$this->data['post_status'] = 0;
		}

		$types = array(
			'F' => 'Full Day',
			'1' => 'First Half',
			'2' => 'Second Half'
		);
		$this->data['types'] = $types;
		
		// echo '<pre>';
		// print_r($this->data);
		// exit;

		$this->template = 'transaction/leave_ess_dept.tpl';
		$this->children = array(
			'common/header',
			'common/footer'
		);

		$this->response->setOutput($this->render());
	} 

	public function GetDays($sStartDate, $sEndDate){  
		// Firstly, format the provided dates.  
		// This function works best with YYYY-MM-DD  
		// but other date formats will work thanks  
		// to strtotime().  
		$sStartDate = date("Y-m-d", strtotime($sStartDate));  
		$sEndDate = date("Y-m-d", strtotime($sEndDate));  
		// Start the variable off with the start date  
		$aDays[] = $sStartDate;  
		// Set a 'temp' variable, sCurrentDate, with  
		// the start date - before beginning the loop  
		$sCurrentDate = $sStartDate;  
		// While the current date is less than the end date  
		while($sCurrentDate < $sEndDate){  
		// Add a day to the current date  
		$sCurrentDate = date("Y-m-d", strtotime("+1 day", strtotime($sCurrentDate)));  
			// Add this new day to the aDays array  
		$aDays[] = $sCurrentDate;  
		}
		// Once the loop has finished, return the  
		// array of days.  
		return $aDays;  
	} 

	protected function validateForm() {
		$this->load->model('transaction/transaction');

		// if (!$this->user->hasPermission('modify', 'transaction/horse_wise')) {
		// 	$this->error['warning'] = $this->language->get('error_permission');
		// }
		$from = $this->request->post['from'];
		$to = $this->request->post['to'];
		$close_sql = "SELECT * FROM `oc_transaction` WHERE `date` = '".$from."' ";
		$close_res = $this->db->query($close_sql);
		if($close_res->num_rows > 0){
			$close_sql = "SELECT * FROM `oc_transaction` WHERE `date` = '".$from."' AND `month_close_status` = '0' ";
			$close_res = $this->db->query($close_sql);
			if($close_res->num_rows == 0){
				$this->error['warning'] = 'Month Already Closed';
			}
		}
		//echo '<pre>';
		//print_r($this->error);
		//exit;
		//if($this->request->post['diffDays'] > 1){
			/****Start - WFH 20240110*********/
			// if($this->request->post['leave_type'] == 'PL'){
			// 	$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($this->request->post['e_name_id']);
			// 	$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->request->post['e_name_id'], 'PL');
			// 	$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->request->post['e_name_id'], 'PL');
			// 	$total_bal_pl = 0;
			// 	if(isset($total_bal['pl_acc'])){
			// 		if(isset($total_bal_pro['bal_p'])){
			// 			$total_bal_pl = $total_bal['pl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro['encash'] + $total_bal_pro1['leave_amount']);
			// 		} else {
			// 			$total_bal_pl = $total_bal['pl_acc'];
			// 		}
			// 	}
			// 	$pl_bal_tran_sql = "SELECT count(*) as cnt FROM `oc_leave_transaction_temp` WHERE emp_id = '".$this->request->post['e_name_id']."' AND `leave_type` = 'PL' AND `p_status` = '0' AND `a_status` = '1' ";
			// 	$pl_bal_tran_res = $this->db->query($pl_bal_tran_sql);
			// 	$pl_bal_f = $total_bal_pl - $pl_bal_tran_res->row['cnt'];
			// 	if($total_bal_pl > 0){
			// 		if($this->request->post['enable_encash'] == 1){ 
			// 			if($pl_bal_f >= 30){
			// 				$pl_balance = $pl_bal_f;
			// 				if($this->request->post['leave_amount'] != '0'){
			// 					$total_added = $this->request->post['leave_amount'];
			// 				} else {
			// 					$total_added = $this->request->post['days'] + $this->request->post['encash'];	
			// 				}
			// 				//$total_pl_added = $this->request->post['days'] + $this->request->post['encash'];
			// 				if($total_added > $pl_balance){
			// 					$this->error['days'] = 'Insufficient Leave balance';//'Only ' . $pl_balance . ' days PL leave available For Employee';	
			// 				} else {
			// 					if($this->request->post['enable_encash'] == 1){
			// 						$days = $this->request->post['days'];
			// 						$act_encash = $this->request->post['encash'];
			// 						$exp_encash = $days * 3.29;
			// 						$exp_encash = round($exp_encash);
			// 						if($days < 7 && $this->request->post['group'] != 'OFFICIALS'){
			// 							//if($days < 7){
			// 							//$this->error['encash'] = 'Minimum PL Leave Days Should be 7 days'; 
			// 						} else {
			// 							if($act_encash > $exp_encash){
			// 								$this->error['encash'] = 'Encash Should be less than or equal to ' . $exp_encash . ' days'; 
			// 							} elseif($act_encash < 15){
			// 								$this->error['encash'] = 'Minimum Encash Should be 15 days'; 
			// 							}
			// 						}
			// 					}
			// 				}
			// 			} else {
			// 				$this->error['leave_type'] = 'PL Balance Leave For Employee Less than 30';	
			// 			}
			// 		} else {
			// 			$pl_balance = $pl_bal_f;
			// 			if($this->request->post['leave_amount'] != '0'){
			// 				$total_added = $this->request->post['leave_amount'];
			// 			} else {
			// 				$total_added = $this->request->post['days'];	
			// 			}
			// 			if($total_added > $pl_balance){
			// 				$this->error['days'] = 'Insufficient Leave balance';//'Only ' . $pl_balance . ' days PL leave available For Employee';	
			// 			} else {
			// 				$days = $this->request->post['days'];
			// 				if($days < 7 && $this->request->post['group'] != 'OFFICIALS'){
			// 					//$this->error['days'] = 'Minimum PL Leave Days Should be 7 days'; 
			// 				}
			// 			}
			// 		}
			// 	} else {
			// 		//if($this->request->post['enable_encash'] == 1){
			// 			$this->error['leave_type'] = 'PL Balance Leave For Employee Does Not Exist';
			// 		//}
			// 	}
			// } elseif($this->request->post['leave_type'] == 'CL'){
			// 	//$bal_sql = "SELECT `cl_bal` FROM `oc_leave` WHERE emp_id = '".$this->request->post['e_name_id']."' ";
			// 	//$bal_res = $this->db->query($bal_sql);
			// 	$from = $this->request->post['from'];
			// 	$to = $this->request->post['to'];
			// 	// $date1 = new DateTime($from);
			// 	// $date2 = new DateTime($to);

			// 	// $diff = $date2->diff($date1)->format("%a");
			// 	// $diff_days = $diff + 1;
			// 	// if($diff_days > 4){
			// 	// 	$this->error['leave_type'] = 'Max CL Leave Period is 4 days';
			// 	// }
			// 	$start_date_check = new DateTime($from);
			// 	$diff_check = $start_date_check->diff(new DateTime($from));
				
			// 	if($diff_check->invert == 1 || $this->request->post['days'] > 2){
			// 		$this->error['leave_type'] = 'Max CL Leave Period is 2 days';
			// 	}
			// 	$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($this->request->post['e_name_id']);
			// 	$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->request->post['e_name_id'], 'CL');
			// 	$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->request->post['e_name_id'], 'CL');
			// 	$total_bal_cl = 0;
			// 	if(isset($total_bal['cl_acc'])){
			// 		if(isset($total_bal_pro['bal_p'])){
			// 			$total_bal_cl = $total_bal['cl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
			// 		} else {
			// 			$total_bal_cl = $total_bal['cl_acc'];
			// 		}
			// 	}

			// 	// $bal_tran_sql = "SELECT count(*) as cnt FROM `oc_leave_transaction_temp` WHERE emp_id = '".$this->request->post['e_name_id']."' AND `leave_type` = '".$this->request->post['leave_type']."' AND `p_status` = '0' AND `a_status` = '1' ";
			// 	// $bal_tran_res = $this->db->query($bal_tran_sql);
			// 	// $bal_f = $total_bal_cl - $bal_tran_res->row['cnt'];
				
			// 	$balance = $total_bal_cl;
			// 	if($this->request->post['leave_amount'] != '0'){
			// 		$total_added = $this->request->post['leave_amount'];
			// 	} else {
			// 		$total_added = $this->request->post['days'];	
			// 	}
			// 	if($total_added > $balance){
			// 		if($balance < 0){
			// 			$balance = 0;
			// 		}
			// 		$this->error['days'] = 'Insufficient Leave balance';//'Only ' . $balance . ' days '. $this->request->post['leave_type'] .' leave available For Employee';	
			// 	} 
			// } 
			if($this->request->post['leave_type'] == 'PL'){
				$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($this->request->post['e_name_id']);
				$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->request->post['e_name_id'], 'PL');
				$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->request->post['e_name_id'], 'PL');
				$total_bal_pl = 0;
				$taken_leave = 0;
				$days = $this->request->post['days'];
				if(isset($total_bal['pl_acc'])){
					if(isset($total_bal_pro['bal_p'])){
						$taken_leave = $total_bal_pro['bal_p'] + $total_bal_pro['encash'] + $total_bal_pro1['leave_amount'];
					}
				}
				$pl_bal_tran_sql = "SELECT count(*) as cnt FROM `oc_leave_transaction_temp` WHERE emp_id = '".$this->request->post['e_name_id']."' AND `leave_type` = 'PL' AND `p_status` = '0' AND `a_status` = '1' ";
				$pl_bal_tran_res = $this->db->query($pl_bal_tran_sql);
				$pl_bal_f = $total_bal_pl - $pl_bal_tran_res->row['cnt'];
				if($total_bal_pl > 0){
					if($this->request->post['enable_encash'] == 1){ 
						if($pl_bal_f >= 30){
							$pl_balance = $pl_bal_f;
							if($this->request->post['leave_amount'] != '0'){
								$total_added = $this->request->post['leave_amount'];
							} else {
								$total_added = $this->request->post['days'] + $this->request->post['encash'];	
							}
						
							if($total_added > $pl_balance){
								$this->error['days'] = 'Insufficient Leave balance';//'Only ' . $pl_balance . ' days PL leave available For Employee';	
							} else {
								if($this->request->post['enable_encash'] == 1){
									$days = $this->request->post['days'];
									$act_encash = $this->request->post['encash'];
									$exp_encash = $days * 3.29;
									$exp_encash = round($exp_encash);
									if($days < 7 && $this->request->post['group'] != 'OFFICIALS'){
										//if($days < 7){
										//$this->error['encash'] = 'Minimum PL Leave Days Should be 7 days'; 
									} else {
										if($act_encash > $exp_encash){
											$this->error['encash'] = 'Encash Should be less than or equal to ' . $exp_encash . ' days'; 
										} elseif($act_encash < 15){
											$this->error['encash'] = 'Minimum Encash Should be 15 days'; 
										}
									}
								}
							}
						} else {
							$this->error['leave_type'] = 'PL Balance Leave For Employee Less than 30';	
						}
					} else {
						$pl_balance = $pl_bal_f;
						if($this->request->post['leave_amount'] != '0'){
							$total_added = $this->request->post['leave_amount'];
						} else {
							$total_added = $this->request->post['days'];	
						}
						$pass_data= array('total_leave'=>$total_bal['pl_acc'],'applied_leave'=> $total_added,'taken_leave'=>$taken_leave ,'from_date'=>$this->request->post['from'],'to_date'=>$this->request->post['to'],'prev_year_pl_leave'=>$total_bal['prev_year_pl_leave']);
						$this->load->model('user/user');
						$user_info = $this->model_user_user->getemployee($this->request->post['e_name_id']);
						$pass_data['user_info'] = $user_info;
						$leave_availability = checkAvailability($pass_data);
						
						if($leave_availability['allow']==0)
						{
							$this->error['days'] = 'Insufficient Leave balance of PL. your available leave is '.$leave_availability['available_leave']. ' but you have applied for '.$leave_availability['applied_leave'];
						}
					}
				} else {
					//if($this->request->post['enable_encash'] == 1){
						$this->error['leave_type'] = 'PL Balance Leave For Employee Does Not Exist';
					//}
				}
			} 
			 
			/****End - WFH 20240110*********/
			elseif($this->request->post['leave_type'] == 'CL'){
				//$bal_sql = "SELECT `cl_bal` FROM `oc_leave` WHERE emp_id = '".$this->request->post['e_name_id']."' ";
				//$bal_res = $this->db->query($bal_sql);
				$from = $this->request->post['from'];
				$to = $this->request->post['to'];
				// $date1 = new DateTime($from);
				// $date2 = new DateTime($to);

				// $diff = $date2->diff($date1)->format("%a");
				// $diff_days = $diff + 1;
				// if($diff_days > 4){
				// 	$this->error['leave_type'] = 'Max CL Leave Period is 4 days';
				// }
				$start_date_check = new DateTime($from);
				$diff_check = $start_date_check->diff(new DateTime($from));
				
				if($diff_check->invert == 1 || $this->request->post['days'] > 2){
					$this->error['leave_type'] = 'Max CL Leave Period is 2 days';
				}
				$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($this->request->post['e_name_id']);
				$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->request->post['e_name_id'], 'CL');
				$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->request->post['e_name_id'], 'CL');
				$total_bal_cl = 0;
				if(isset($total_bal['cl_acc'])){
					if(isset($total_bal_pro['bal_p'])){
						$total_bal_cl = $total_bal['cl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
					} else {
						$total_bal_cl = $total_bal['cl_acc'];
					}
				}

				// $bal_tran_sql = "SELECT count(*) as cnt FROM `oc_leave_transaction_temp` WHERE emp_id = '".$this->request->post['e_name_id']."' AND `leave_type` = '".$this->request->post['leave_type']."' AND `p_status` = '0' AND `a_status` = '1' ";
				// $bal_tran_res = $this->db->query($bal_tran_sql);
				// $bal_f = $total_bal_cl - $bal_tran_res->row['cnt'];
				
				$balance = $total_bal_cl;
				if($this->request->post['leave_amount'] != '0'){
					$total_added = $this->request->post['leave_amount'];
				} else {
					$total_added = $this->request->post['days'];	
				}
				if($total_added > $balance){
					if($balance < 0){
						$balance = 0;
					}
					$this->error['days'] = 'Insufficient Leave balance';//'Only ' . $balance . ' days '. $this->request->post['leave_type'] .' leave available For Employee';	
				} 
			}
			elseif($this->request->post['leave_type'] == 'BL'){
				//$bal_sql = "SELECT `cl_bal` FROM `oc_leave` WHERE emp_id = '".$this->request->post['e_name_id']."' ";
				//$bal_res = $this->db->query($bal_sql);
				$from = $this->request->post['from'];
				$to = $this->request->post['to'];
				// $date1 = new DateTime($from);
				// $date2 = new DateTime($to);

				// $diff = $date2->diff($date1)->format("%a");
				// $diff_days = $diff + 1;
				// if($diff_days > 4){
				// 	$this->error['leave_type'] = 'Max CL Leave Period is 4 days';
				// }
				$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($this->request->post['e_name_id']);
				$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->request->post['e_name_id'], 'BL');
				$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->request->post['e_name_id'], 'BL');
				$total_bal_cl = 0;
				if(isset($total_bal['bl_acc'])){
					if(isset($total_bal_pro['bal_p'])){
						$total_bal_cl = $total_bal['bl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
					} else {
						$total_bal_cl = $total_bal['bl_acc'];
					}
				}

				$bal_tran_sql = "SELECT count(*) as cnt FROM `oc_leave_transaction_temp` WHERE emp_id = '".$this->request->post['e_name_id']."' AND `leave_type` = '".$this->request->post['leave_type']."' AND `p_status` = '0' AND `a_status` = '1' ";
				$bal_tran_res = $this->db->query($bal_tran_sql);
				$bal_f = $total_bal_cl - $bal_tran_res->row['cnt'];
				
				$balance = $bal_f;
				if($this->request->post['leave_amount'] != '0'){
					$total_added = $this->request->post['leave_amount'];
				} else {
					$total_added = $this->request->post['days'];	
				}
				if($total_added > $balance){
					if($balance < 0){
						$balance = 0;
					}
					$this->error['days'] = 'Insufficient Leave balance';//'Only ' . $balance . ' days '. $this->request->post['leave_type'] .' leave available For Employee';	
				} 
			} elseif($this->request->post['leave_type'] == 'SL'){
				//$bal_sql = "SELECT `sl_bal` FROM `oc_leave` WHERE emp_id = '".$this->request->post['e_name_id']."' ";
				//$bal_res = $this->db->query($bal_sql);

				$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($this->request->post['e_name_id']);
				$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->request->post['e_name_id'], 'SL');
				$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->request->post['e_name_id'], 'SL');
				$total_bal_sl = 0;
				if(isset($total_bal['sl_acc'])){
					if(isset($total_bal_pro['bal_p'])){
						$total_bal_sl = $total_bal['sl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
					} else {
						$total_bal_sl = $total_bal['sl_acc'];
					}
				}

				$bal_tran_sql = "SELECT count(*) as cnt FROM `oc_leave_transaction_temp` WHERE emp_id = '".$this->request->post['e_name_id']."' AND `leave_type` = '".$this->request->post['leave_type']."' AND `p_status` = '0' AND `a_status` = '1' ";
				$bal_tran_res = $this->db->query($bal_tran_sql);
				$bal_f = $total_bal_sl - $bal_tran_res->row['cnt'];
				$balance = $bal_f;
				if($this->request->post['leave_amount'] != '0'){
					$total_added = $this->request->post['leave_amount'];
				} else {
					$total_added = $this->request->post['days'];	
				}
				if($total_added > $balance){
					if($balance < 0){
						$balance = 0;
					}
					$this->error['days'] = 'Insufficient Leave balance';//'Only ' . $balance . ' days '. $this->request->post['leave_type'] .' leave available For Employee';	
				} 
			} elseif($this->request->post['leave_type'] == 'SL'){
				//$bal_sql = "SELECT `sl_bal` FROM `oc_leave` WHERE emp_id = '".$this->request->post['e_name_id']."' ";
				//$bal_res = $this->db->query($bal_sql);

				$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($this->request->post['e_name_id']);
				$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->request->post['e_name_id'], 'SL');
				$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->request->post['e_name_id'], 'SL');
				$total_bal_sl = 0;
				if(isset($total_bal['sl_acc'])){
					if(isset($total_bal_pro['bal_p'])){
						$total_bal_sl = $total_bal['sl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
					} else {
						$total_bal_sl = $total_bal['sl_acc'];
					}
				}

				$bal_tran_sql = "SELECT count(*) as cnt FROM `oc_leave_transaction_temp` WHERE emp_id = '".$this->request->post['e_name_id']."' AND `leave_type` = '".$this->request->post['leave_type']."' AND `p_status` = '0' AND `a_status` = '1' ";
				$bal_tran_res = $this->db->query($bal_tran_sql);
				$bal_f = $total_bal_sl - $bal_tran_res->row['cnt'];
				$balance = $bal_f;
				if($this->request->post['leave_amount'] != '0'){
					$total_added = $this->request->post['leave_amount'];
				} else {
					$total_added = $this->request->post['days'];	
				}
				if($total_added > $balance){
					if($balance < 0){
						$balance = 0;
					}
					$this->error['days'] = 'Insufficient Leave balance';//'Only ' . $balance . ' days '. $this->request->post['leave_type'] .' leave available For Employee';	
				} 
			} elseif($this->request->post['leave_type'] == 'ML'){
				//$bal_sql = "SELECT `sl_bal` FROM `oc_leave` WHERE emp_id = '".$this->request->post['e_name_id']."' ";
				//$bal_res = $this->db->query($bal_sql);

				$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($this->request->post['e_name_id']);
				$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->request->post['e_name_id'], 'ML');
				$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->request->post['e_name_id'], 'ML');
				$total_bal_sl = 0;
				if(isset($total_bal['ml_acc'])){
					if(isset($total_bal_pro['bal_p'])){
						$total_bal_sl = $total_bal['ml_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
					} else {
						$total_bal_sl = $total_bal['ml_acc'];
					}
				}

				$bal_tran_sql = "SELECT count(*) as cnt FROM `oc_leave_transaction_temp` WHERE emp_id = '".$this->request->post['e_name_id']."' AND `leave_type` = '".$this->request->post['leave_type']."' AND `p_status` = '0' AND `a_status` = '1' ";
				$bal_tran_res = $this->db->query($bal_tran_sql);
				$bal_f = $total_bal_sl - $bal_tran_res->row['cnt'];
				$balance = $bal_f;
				if($this->request->post['leave_amount'] != '0'){
					$total_added = $this->request->post['leave_amount'];
				} else {
					$total_added = $this->request->post['days'];	
				}
				if($total_added > $balance){
					if($balance < 0){
						$balance = 0;
					}
					$this->error['days'] = 'Insufficient Leave balance';//'Only ' . $balance . ' days '. $this->request->post['leave_type'] .' leave available For Employee';	
				} 
			} elseif($this->request->post['leave_type'] == 'MAL'){
				//$bal_sql = "SELECT `sl_bal` FROM `oc_leave` WHERE emp_id = '".$this->request->post['e_name_id']."' ";
				//$bal_res = $this->db->query($bal_sql);

				$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($this->request->post['e_name_id']);
				$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->request->post['e_name_id'], 'MAL');
				$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->request->post['e_name_id'], 'MAL');
				$total_bal_sl = 0;
				if(isset($total_bal['mal_acc'])){
					if(isset($total_bal_pro['bal_p'])){
						$total_bal_sl = $total_bal['mal_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
					} else {
						$total_bal_sl = $total_bal['mal_acc'];
					}
				}

				$bal_tran_sql = "SELECT count(*) as cnt FROM `oc_leave_transaction_temp` WHERE emp_id = '".$this->request->post['e_name_id']."' AND `leave_type` = '".$this->request->post['leave_type']."' AND `p_status` = '0' AND `a_status` = '1' ";
				$bal_tran_res = $this->db->query($bal_tran_sql);
				$bal_f = $total_bal_sl - $bal_tran_res->row['cnt'];
				$balance = $bal_f;
				if($this->request->post['leave_amount'] != '0'){
					$total_added = $this->request->post['leave_amount'];
				} else {
					$total_added = $this->request->post['days'];	
				}
				if($total_added > $balance){
					if($balance < 0){
						$balance = 0;
					}
					$this->error['days'] = 'Insufficient Leave balance';//'Only ' . $balance . ' days '. $this->request->post['leave_type'] .' leave available For Employee';	
				} 
			} elseif($this->request->post['leave_type'] == 'PAL'){
				//$bal_sql = "SELECT `sl_bal` FROM `oc_leave` WHERE emp_id = '".$this->request->post['e_name_id']."' ";
				//$bal_res = $this->db->query($bal_sql);

				$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($this->request->post['e_name_id']);
				$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->request->post['e_name_id'], 'PAL');
				$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->request->post['e_name_id'], 'PAL');
				$total_bal_sl = 0;
				if(isset($total_bal['pal_acc'])){
					if(isset($total_bal_pro['pal_p'])){
						$total_bal_sl = $total_bal['pal_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
					} else {
						$total_bal_sl = $total_bal['pal_acc'];
					}
				}

				$bal_tran_sql = "SELECT count(*) as cnt FROM `oc_leave_transaction_temp` WHERE emp_id = '".$this->request->post['e_name_id']."' AND `leave_type` = '".$this->request->post['leave_type']."' AND `p_status` = '0' AND `a_status` = '1' ";
				$bal_tran_res = $this->db->query($bal_tran_sql);
				$bal_f = $total_bal_sl - $bal_tran_res->row['cnt'];
				$balance = $bal_f;
				if($this->request->post['leave_amount'] != '0'){
					$total_added = $this->request->post['leave_amount'];
				} else {
					$total_added = $this->request->post['days'];	
				}
				if($total_added > $balance){
					if($balance < 0){
						$balance = 0;
					}
					$this->error['days'] = 'Insufficient Leave balance';//'Only ' . $balance . ' days '. $this->request->post['leave_type'] .' leave available For Employee';	
				} 
			} elseif($this->request->post['leave_type'] == 'LWP'){
				//$bal_sql = "SELECT `sl_bal` FROM `oc_leave` WHERE emp_id = '".$this->request->post['e_name_id']."' ";
				//$bal_res = $this->db->query($bal_sql);

				$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($this->request->post['e_name_id']);
				$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->request->post['e_name_id'], 'LWP');
				$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->request->post['e_name_id'], 'LWP');
				$total_bal_sl = 0;
				if(isset($total_bal['lwp_acc'])){
					if(isset($total_bal_pro['lwp_p'])){
						$total_bal_sl = $total_bal['lwp_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
					} else {
						$total_bal_sl = $total_bal['lwp_acc'];
					}
				}

				$bal_tran_sql = "SELECT count(*) as cnt FROM `oc_leave_transaction_temp` WHERE emp_id = '".$this->request->post['e_name_id']."' AND `leave_type` = '".$this->request->post['leave_type']."' AND `p_status` = '0' AND `a_status` = '1' ";
				$bal_tran_res = $this->db->query($bal_tran_sql);
				$bal_f = $total_bal_sl - $bal_tran_res->row['cnt'];
				$balance = $bal_f;
				if($this->request->post['leave_amount'] != '0'){
					$total_added = $this->request->post['leave_amount'];
				} else {
					$total_added = $this->request->post['days'];	
				}
				if($total_added > $balance){
					if($balance < 0){
						$balance = 0;
					}
					$this->error['days'] = 'Insufficient Leave balance';//'Only ' . $balance . ' days '. $this->request->post['leave_type'] .' leave available For Employee';	
				} 
			} elseif ($this->request->post['leave_type'] == 'Covid19') {
				$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($this->request->post['e_name_id']);
				$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess($this->request->post['e_name_id'], 'Covid19');
				$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess($this->request->post['e_name_id'], 'Covid19');
				$total_bal_covid = 0;
				if(isset($total_bal['covid_acc'])){
					if(isset($total_bal_pro['bal_p'])){
						$total_bal_covid = $total_bal['covid_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
					} else {
						$total_bal_covid = $total_bal['covid_acc'];
					}
				}
				$balance = $total_bal_covid;
				if($this->request->post['leave_amount'] != '0'){
					$total_added = $this->request->post['leave_amount'];
				} else {
					$total_added = $this->request->post['days'];	
				}
				if($total_added > $balance){
					if($balance < 0){
						$balance = 0;
					}
					$this->error['days'] = 'Insufficient Leave balance';//'Only ' . $balance . ' days '. $this->request->post['leave_type'] .' leave available For Employee';	
				}
			}
			/****Start - WFH 20240110*********/
			elseif ($this->request->post['leave_type'] == 'WFH') {

				if($from!=$to)
				{
					if($balance < 0){
						$balance = 0;
					}
					$this->error['days'] = 'Sorry, you cannot apply WFH for two consecutive days';
				}
				$total_bal = $this->model_transaction_transaction->gettotal_bal_ess($this->request->post['e_name_id']);
				$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro_ess_wfh($this->request->post['e_name_id'], 'WFH',array('from'=>$from,'to'=>$to));
				$total_bal_pro1 = $this->model_transaction_transaction->gettotal_bal_pro1_ess_wfh($this->request->post['e_name_id'], 'WFH',array('from'=>$from,'to'=>$to));
				$total_bal_wfh = 0;

				if(isset($total_bal['wfh_acc'])){
					if(isset($total_bal_pro['bal_p'])){
						$total_bal_wfh = $total_bal['wfh_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
					} else {
						$total_bal_wfh = $total_bal['wfh_acc'];
					}
				}
				$balance = $total_bal_wfh;
				
				if($this->request->post['leave_amount'] != '0'){
					$total_added = $this->request->post['leave_amount'];
				} else {
					$total_added = $this->request->post['days'];	
				}
				
				if($total_added > $balance){
					if($balance < 0){
						$balance = 0;
					}
					$this->error['days'] = 'Insufficient WFH balance';
				}
			}
			/****End - WFH 20240110*********/

			// elseif($this->request->post['leave_type'] == 'COF'){
			// 	//echo 'aaaa';
			// 	//$bal_sql = "SELECT `cof_bal` FROM `oc_leave` WHERE emp_id = '".$this->request->post['e_name_id']."' ";
			// 	//$bal_res = $this->db->query($bal_sql);

			// 	$total_bal = $this->model_transaction_transaction->gettotal_bal($this->request->post['e_name_id']);
			// 	$total_bal_pro = $this->model_transaction_transaction->gettotal_bal_pro($this->request->post['e_name_id'], 'COF');
			// 	$total_bal_cof = 0;
			// 	if(isset($total_bal['cof_acc'])){
			// 		if(isset($total_bal_pro['bal_p'])){
			// 			$total_bal_cof = $total_bal['cof_acc'] - $total_bal_pro['bal_p'];
			// 		} else {
			// 			$total_bal_cof = $total_bal['cof_acc'];
			// 		}
			// 	}
				
			// 	$bal_tran_sql = "SELECT count(*) as cnt FROM `oc_leave_transaction` WHERE emp_id = '".$this->request->post['e_name_id']."' AND `leave_type` = '".$this->request->post['leave_type']."' AND `p_status` = '0' AND `a_status` = '1' ";
			// 	$bal_tran_res = $this->db->query($bal_tran_sql);
			// 	$bal_f = $total_bal_cof - $bal_tran_res->row['cnt'];
				
			// 	$balance = $bal_f;
			// 	$total_added = $this->request->post['days'];
			// 	if($total_added > $balance){
			// 		if($balance < 0){
			// 			$balance = 0;
			// 		}
			// 		$this->error['days'] = 'Only ' . $balance . ' days '. $this->request->post['leave_type'] .' leave available For Employee';	
			// 	} 
			// }

			// echo '<pre>';
			// print_r($this->error);
			// exit;

			$from = $this->request->post['from'];
			$to = $this->request->post['to'];

			$date_sql = "SELECT `date`, `leave_amount`, `type` FROM `oc_leave_transaction_temp` WHERE `date` BETWEEN '".$from."' AND '".$to."' AND `a_status` = '1' AND `emp_id`= '".$this->request->post['e_name_id']."' ";
			$date_res = $this->db->query($date_sql);
			if($date_res->num_rows > 0){
				if($date_res->row['type'] != ''){
					if($date_res->row['leave_amount'] == 0.5 && $this->request->post['leave_amount'] == 0.5){
						if($date_res->row['type'] == $this->request->post['type']){
							$this->error['warning'] = 'Leave For Dates Exist';
						}
					} else {
						$this->error['warning'] = 'Leave For Dates Exist';
					}
				} else {
					$this->error['warning'] = 'Leave For Dates Exist';	
				}
			}
		//}

		$day = array();
		$days = $this->GetDays($from, $to);
        foreach ($days as $dkey => $dvalue) {
        	$dates = explode('-', $dvalue);
        	$day[$dkey]['day'] = $dates[2];
        	$day[$dkey]['date'] = $dvalue;
        }

        /****Start - WFH 20240110*********/
        $this->load->helper('wfh');
        $holidays_array = $this->db->query("SELECT `date` FROM `oc_holiday` WHERE `date` >= '".date('Y')."-01-01' ")->rows;
        $wfh = $this->db->query("SELECT `date` FROM `oc_leave_transaction_temp` WHERE  `a_status` = '1' AND `emp_id`= '".$this->request->post['e_name_id']."' AND leave_type= 'WFH' AND  `date` >= '".date('Y')."-01-01' ")->rows;
        if(!empty($wfh))
    	{
    		$wfh_array = array_column($wfh, 'date');
    		array_unshift($wfh_array, "1");//if date found on first position then it will return 0 it will cause issue thats why added 1 on first position
    	}
    	else
    	{
    		$wfh_array = array();
    	}

    	$leave = $this->db->query("SELECT `date` FROM `oc_leave_transaction_temp` WHERE  `a_status` = '1' AND `emp_id`= '".$this->request->post['e_name_id']."' AND leave_type != 'WFH' AND  `date` >= '".date('Y')."-01-01' ")->rows;

        if(!empty($leave))
    	{
    		$leave_array = array_column($leave, 'date');
    		array_unshift($leave_array, "1");//if date found on first position then it will return 0 it will cause issue thats why added 1 on first position
    	}
    	else
    	{
    		$leave_array = array();
    	}
        /****End - WFH 20240110*********/

        foreach($day as $dkey => $dvalue){

        	/****Start - WFH 20240110*********/
        	if($this->request->post['leave_type'] == 'WFH'){

        		if(strtotime($dvalue['date']) < strtotime(date('Y-m-01')))
        		{
        			$this->error['warning'] = 'You can not apply WFH for past month';
		        	break;
        		}

	        	if(!empty($holidays_array))
	        	{
	        		$holidays_array = array_column($holidays_array, 'date');
	        		array_unshift($holidays_array, "1");//if date found on first position then it will return 0 it will cause issue thats why added 1 on first position
	        	}
	        	else
	        	{
	        		$holidays_array = array();
	        	}
	        	$is_holiday = isHoliday($dvalue['date'],$holidays_array);
	        	if(!empty($is_holiday))
	        	{
	        		$this->error['warning'] = 'Holiday Exist in Selected Date Period';
		        	break;
	        	}
	        	if (!empty(isWeekend($dvalue['date']))) {
	        		$this->error['warning'] = 'You can not take WFH for monday or friday';
		        	break;
	        	}
	        	if(!empty(isBeforeOrAfterHoliday($dvalue['date'],$holidays_array)))
	        	{
	        		$this->error['warning'] = 'You can not take WFH after or before holidays';
		        	break;
	        	}

				
				if(!empty($wfh_array))
				{
					$is_leave = isLeave($dvalue['date'],$wfh_array);
		        	if(!empty($is_leave))
		        	{
		        		$this->error['warning'] = 'Leave Exist in Selected Date Period';
			        	break;
		        	}
		        	
		        	if(!empty(isBeforeOrAfterLeave($dvalue['date'],$wfh_array)))
		        	{
		        		$this->error['warning'] = 'You can not take WFH after or before WFH';
			        	break;
		        	}
				}
				if(!empty(isBeforeOrAfterLeave($dvalue['date'],$wfh_array)))
	        	{
	        		$this->error['warning'] = 'You can not take leave after or before WFH';
		        	break;
	        	}
	        	if(!empty(isBeforeOrAfterLeave($dvalue['date'],$leave_array)))
	        	{
	        		$this->error['warning'] = 'You can not take WFH after or before leave';
		        	break;
	        	}
	        }
	        
        	/****End - WFH 20240110*********/

        	$is_holidays = $this->db->query("SELECT `holiday_id` FROM `oc_holiday` WHERE `date` = '".$dvalue['date']."' ");
	        	if($this->request->post['leave_type'] != 'ML'){
				if($is_holidays->num_rows > 0){
	        			$this->error['warning'] = 'Holiday Exist in Selected Date Period';
	        			break;
	        	}
	        	
			}


			if($this->request->post['leave_type'] != 'ML'){
	        		if(date('N', strtotime($dvalue['date'])) >= 6){
	        			$this->error['warning'] = 'Weekend Exist in Selected Date Period';
	        			break;	
	        		}
			}
        }

		$from_date = $this->request->post['from'];
		$to_date = $this->request->post['to'];
		$from_year = date('Y', strtotime($from_date));
		$to_year = date('Y', strtotime($to_date));
		if($from_year != $to_year){
			$this->error['warning'] = 'From And To Year should be same';
		}
		
		// echo '<pre>';
		// print_r($this->error);
		// exit;

		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}

	protected function validateDelete(){
		// $this->load->model('transaction/transaction');
		// if(isset($this->request->post['selected'])){
		// 	foreach ($this->request->post['selected'] as $batch_id) {
		// 		$leave_sql = "SELECT `id` FROM `oc_leave_transaction` WHERE `batch_id` = '".$batch_id."' AND `p_status` = '1' ";
		// 		$date_res = $this->db->query($leave_sql);
		// 		if ($date_res->num_rows > 0) {
		// 			$this->error['warning'] = 'Leave With batch ' . $batch_id . ' already processed';
		// 		}
		// 	}	
		// } elseif(isset($this->request->get['batch_id'])){
		// 	$batch_id = $this->request->get['batch_id'];
		// 	$leave_sql = "SELECT `id` FROM `oc_leave_transaction` WHERE `batch_id` = '".$batch_id."' AND `p_status` = '1' ";
		// 	$date_res = $this->db->query($leave_sql);
		// 	if ($date_res->num_rows > 0) {
		// 		$this->error['warning'] = 'Leave With batch ' . $batch_id . ' already processed';
		// 	}
		// }

		if (!$this->error) {
			return true;
		} else {
			return false;
		}		
	}

	public function getshift_details() {
		$jsondata = array();
		$jsondata['status'] = 0;
		//$this->log->write(print_r($this->request->get,true));
		$shift_data = array();
		if(isset($this->request->get['emp_code'])){
			$jsondata['status'] = 1;
			$emp_code = $this->request->get['emp_code'];
			$from = $this->request->get['from'];
			$to = $this->request->get['to'];
			if(!isset($this->request->get['cof_stat'])){
				$from = date('Y-m-d', strtotime($from . ' -1 day'));
				$to = date('Y-m-d', strtotime($to . ' +1 day'));
			}
			$data = array(
				'filter_date_start' => $from,
				'filter_date_end' => $to
			);
	        $this->load->model('transaction/transaction');
			$trans_datas = $this->model_transaction_transaction->gettransaction_data_leave($emp_code, $data);
			$html = '';
			$html .= "<table border='1' style='margin:0px auto;'>";
				$html .= "<tr>";
					$tot = count($trans_datas) + 1;
					$html .= "<td style='padding:10px;text-align:center;font-weight:bold;' colspan = '".$tot."'>";
						$html .= "Attendance Status";
					$html .= "</td>";
				$html .= "</tr>";
				$html .= "<tr>";
					$html .= "<td style='padding:2px;'>";
						$html .= " ";
					$html .= "</td>";
					foreach($trans_datas as $tkey => $tvalue){
						$html .= "<td style='padding:2px;font-weight:bold;font-size:9px;'>";
							$html .= $tvalue['day'];
						$html .= "</td>";
					}
				$html .= "</tr>";
				$html .= "<tr>";
					$html .= "<td style='font-weight:bold;padding:2px;'>";
						$html .= "Act In Time";
					$html .= "</td>";
					foreach($trans_datas as $tkey => $tvalue){
						$html .= "<td style='padding:2px;font-size:9px;'>";
							if($tvalue['act_intime'] != '00:00:00' && $tvalue['act_intime'] != ''){
								$html .= $tvalue['act_intime'];
							} else {
								$html .= '00:00';
							}
						$html .= "</td>";
					}
				$html .= "</tr>";
				$html .= "<tr>";
					$html .= "<td style='font-weight:bold;padding:2px;'>";
						$html .= "Act Out Time";
					$html .= "</td>";
					foreach($trans_datas as $tkey => $tvalue){
						$html .= "<td style='padding:2px;font-size:9px;'>";
							if($tvalue['act_outtime'] != '00:00:00' && $tvalue['act_outtime'] != ''){
								$html .= $tvalue['act_outtime'];
							} else {
								$html .= '00:00';
							}
						$html .= "</td>";
					}
				$html .= "</tr>";
				$html .= "<tr>";
					$html .= "<td style='font-weight:bold;padding:2px;'>";
						$html .= "FH";
					$html .= "</td>";
					foreach($trans_datas as $tkey => $tvalue){
						$html .= "<td style='padding:2px;font-size:9px;'>";
							if($tvalue['firsthalf_status'] == '1'){
								$html .= 'P';	
							} elseif($tvalue['firsthalf_status'] == '0'){
								$html .= 'A';
							} else {
								$html .= $tvalue['firsthalf_status'];	
							}
						$html .= "</td>";
					}
				$html .= "</tr>";
				$html .= "<tr>";
					$html .= "<td style='font-weight:bold;padding:2px;'>";
						$html .= "SH";
					$html .= "</td>";
					foreach($trans_datas as $tkey => $tvalue){
						$html .= "<td style='padding:2px;font-size:9px;'>";
							if($tvalue['secondhalf_status'] == '1'){
								$html .= 'P';	
							} elseif($tvalue['secondhalf_status'] == '0'){
								$html .= 'A';
							} else {
								$html .= $tvalue['secondhalf_status'];	
							}
						$html .= "</td>";
					}
				$html .= "</tr>";
			$html .= "</table>";
			if(!isset($this->request->get['cof_stat'])){
				$close_sql = "SELECT * FROM `oc_transaction` WHERE `date` = '".$this->request->get['from']."' ";
				//$this->log->write(print_r($close_sql,true));				
				$close_res = $this->db->query($close_sql);
				//$this->log->write(print_r($close_res,true));
				if($close_res->num_rows > 0){
					$close_sql = "SELECT * FROM `oc_transaction` WHERE `date` = '".$this->request->get['from']."' AND `month_close_status` = '0' ";					
					//$this->log->write(print_r($close_sql,true));
					$close_res = $this->db->query($close_sql);
					//$this->log->write(print_r($close_res->num_rows,true));					
					if($close_res->num_rows == 0){
						$jsondata['status'] = 2;
						$jsondata['message'] = 'Month Already Closed';
					}
				}
			}
		}
		$jsondata['html'] = $html;
		//$this->log->write($html);
	    $this->response->setOutput(Json_encode($jsondata));
	}

	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_name'])) {
			$this->load->model('catalog/employee');

			if(isset($this->session->data['dept_names'])){
				$filter_departments = html_entity_decode($this->session->data['dept_names']);
				$filter_departments = "'" . str_replace(",", "','", $filter_departments) . "'";
			} else {
				$filter_departments = '';
			}

			if($filter_departments == ''){
				if(isset($this->session->data['dept_name'])){
					$filter_department = $this->session->data['dept_name'];
				} else {
					$filter_department = '';
				}
			} else {
				$filter_department = '';
			}

			if(isset($this->session->data['unit']) && $this->session->data['d_emp_id'] != '29078'){
				$filter_unit = $this->session->data['unit'];
			} else {
				$filter_unit = '0';
			}
		
			$data = array(
				'filter_name' => $this->request->get['filter_name'],
				'filter_department' => $filter_department,
				'filter_unit' => $filter_unit,
				'filter_departments' => $filter_departments,
				'start'       => 0,
				'limit'       => 20
			);

			$results = $this->model_catalog_employee->getemployees($data);

			$this->log->write(print_r($results,true));
			
			foreach ($results as $result) {
				$json[] = array(
					'employee_id' => $result['employee_id'],
					'emp_code' => $result['emp_code'], 
					'name'            => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8'))
				);
			}		
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->setOutput(json_encode($json));
	}

	public function export(){
		$this->load->model('transaction/transaction');
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}

		if (isset($this->request->get['filter_name_id'])) {
			$filter_name_id = $this->request->get['filter_name_id'];
		} else {
			$filter_name_id = '';
		}

		if (isset($this->request->get['filter_name_id_1'])) {
			$filter_name_id_1 = $this->request->get['filter_name_id_1'];
		} else {
			$filter_name_id_1 = '';
		}

		if (isset($this->request->get['filter_date'])) {
			$filter_date = $this->request->get['filter_date'];
		} else {
			$filter_date = '';
		}

		if (isset($this->request->get['filter_dept'])) {
			$filter_dept = html_entity_decode($this->request->get['filter_dept']);
		} else {
			$filter_dept = '0';
		}

		if($filter_dept == '0'){
			if(isset($this->session->data['dept_names'])){
				$filter_depts = $this->session->data['dept_names'];
				$filter_depts = "'" . str_replace(",", "','", html_entity_decode($filter_depts)) . "'";
			} else {
				$filter_depts = '';
			}
		} else {
			$filter_depts = '';
		}

		if (isset($this->request->get['filter_unit'])) {
			$filter_unit = $this->request->get['filter_unit'];
		} else {
			if(isset($this->session->data['unit']) && $this->session->data['d_emp_id'] != '29078'){
				$filter_unit = $this->session->data['unit'];
			} else {
				$filter_unit = '0';
			}
		}

		if (isset($this->request->get['filter_group'])) {
			$filter_group = $this->request->get['filter_group'];
		} else {
			if(isset($this->session->data['is_super']) || isset($this->session->data['is_super1'])){
				$filter_group = 'OFFICIALS';
			} else {
				$filter_group = '0';
			}
		}

		if (isset($this->request->get['filter_approval_1'])) {
			$filter_approval_1 = $this->request->get['filter_approval_1'];
		} else {
			$filter_approval_1 = '1';
		}

		if (isset($this->request->get['filter_approval_1_by'])) {
			$filter_approval_1_by = $this->request->get['filter_approval_1_by'];
		} else {
			$filter_approval_1_by = '0';
		}

		if (isset($this->request->get['filter_approval_2'])) {
			$filter_approval_2 = $this->request->get['filter_approval_2'];
		} else {
			$filter_approval_2 = '1';
		}

		if (isset($this->request->get['filter_proc'])) {
			$filter_proc = $this->request->get['filter_proc'];
		} else {
			$filter_proc = '0';
		}

		if (isset($this->request->get['filter_leavetype'])) {
			$filter_leavetype = $this->request->get['filter_leavetype'];
		} else {
			$filter_leavetype = '0';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . $this->request->get['filter_name'];
		}

		if (isset($this->request->get['filter_name_id'])) {
			$url .= '&filter_name_id=' . $this->request->get['filter_name_id'];
		}

		if (isset($this->request->get['filter_name_id_1'])) {
			$url .= '&filter_name_id_1=' . $this->request->get['filter_name_id_1'];
		}

		if (isset($this->request->get['filter_date'])) {
			$url .= '&filter_date=' . $this->request->get['filter_date'];
		}

		if (isset($this->request->get['filter_dept'])) {
			$url .= '&filter_dept=' . $this->request->get['filter_dept'];
		}

		if (isset($this->request->get['filter_unit'])) {
			$url .= '&filter_unit=' . $this->request->get['filter_unit'];
		}

		if (isset($this->request->get['filter_group'])) {
			$url .= '&filter_group=' . $this->request->get['filter_group'];
		}

		if (isset($this->request->get['filter_approval_1'])) {
			$url .= '&filter_approval_1=' . $this->request->get['filter_approval_1'];
		}

		if (isset($this->request->get['filter_approval_1_by'])) {
			$url .= '&filter_approval_1_by=' . $this->request->get['filter_approval_1_by'];
		}

		if (isset($this->request->get['filter_approval_2'])) {
			$url .= '&filter_approval_2=' . $this->request->get['filter_approval_2'];
		}

		if (isset($this->request->get['filter_proc'])) {
			$url .= '&filter_proc=' . $this->request->get['filter_proc'];
		}

		if (isset($this->request->get['filter_leavetype'])) {
			$url .= '&filter_leavetype=' . $this->request->get['filter_leavetype'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data = array(
			'filter_name' => $filter_name,
			'filter_name_id' => $filter_name_id,
			'filter_name_id_1' => $filter_name_id_1,
			'filter_date' => $filter_date,
			'filter_dept' => $filter_dept,
			'filter_depts' => $filter_depts,
			'filter_unit' => $filter_unit,
			'filter_group' => $filter_group,
			'filter_approval_1' => $filter_approval_1,
			'filter_approval_1_by' => $filter_approval_1_by,
			'filter_approval_2' => $filter_approval_2,
			'filter_proc' => $filter_proc,
			'filter_leavetype' => $filter_leavetype,
			//'start' => ($page - 1) * $this->config->get('config_admin_limit'),
			//'limit' => $this->config->get('config_admin_limit')
		);

		$employee_total = $this->model_transaction_transaction->getTotalleaveetransaction_ess($data);
		$results = $this->model_transaction_transaction->getleavetransaction_ess($data);
		$wfh = array();
		foreach ($results as $result) {
			$action = array();
			$emp_group = $this->db->query("SELECT `group` FROM `oc_employee` WHERE `emp_code` = '".$result['emp_id']."' ")->row['group'];
			
			$total_leave_dayss = $this->model_transaction_transaction->gettotal_leave_days_ess($result['batch_id']);
			if($total_leave_dayss['days'] == ''){
				$total_leave_days = $total_leave_dayss['leave_amount'];
			} else {
				$total_leave_days = $total_leave_dayss['days'];
			}
			$leave_from = $this->model_transaction_transaction->getleave_from_ess($result['batch_id']);
			$leave_to = $this->model_transaction_transaction->getleave_to_ess($result['batch_id']);

			$emp_data = $this->model_transaction_transaction->getempdata($result['emp_id']);

			if($result['p_status'] == '1'){
				$proc_stat = 'Processed';
			} else {
				$proc_stat = 'UnProcessed';
			}

			if($result['approval_1'] == '1'){
				if($result['approval_date_1'] != '0000-00-00 00:00:00'){
					$approval_1 = 'Approved on ' . date('d-m-y h:i:s', strtotime($result['approval_date_1']));
				} else {
					$approval_1 = 'Approved';
				}
			} else {
				$approval_1 = 'Pending';
			}

			if($result['approval_2'] == '1'){
				if($result['approval_date_2'] != '0000-00-00 00:00:00'){
					$approval_2 = 'Approved on ' . date('d-m-y h:i:s', strtotime($result['approval_date_2']));
				} else {
					$approval_2 = 'Approved';
				}
			} else {
				$approval_2 = 'Pending';
			}

			if($result['leave_type'] == 'COF'){
				$leave_type = $result['leave_type'].' / '.$result['date_cof'];
			} else {
				$leave_type = $result['leave_type'];
			}

			if($result['reject_date'] != '0000-00-00'){
				$reject_reason = $result['reject_reason'].' - as on '.date('d-m-y', strtotime($result['reject_date']));
			} else {
				$reject_reason = '';
			}

			$wfh[] = array(
				'batch_id' => $result['batch_id'],
				'dot' => date('d-m-y', strtotime($result['dot'])),
				'leave_reason' => $result['leave_reason'],
				'reject_reason' => $reject_reason,
				'encash' => $result['encash'],
				'id' => $result['id'],
				'emp_id' => $result['emp_id'],
				'name' => $emp_data['name'],
				'unit' => $emp_data['unit'],
				'group' => $emp_group,
				'dept' => $emp_data['department'],
				'leave_type'        => $leave_type,
				'total_leave_days' 	      => $total_leave_days,
				'leave_from' => date('d-m-y', strtotime($leave_from)),
				'leave_to' => date('d-m-y', strtotime($leave_to)),
				'approval_1' => $approval_1,
				'approval_2' => $approval_2,
				'approval_1_by' => $result['approved_1_by'],
				'proc_stat' => $proc_stat,
			);
		}


		if($wfh){
			//$month = date("F", mktime(0, 0, 0, $filter_month, 10));
			if(isset($this->session->data['dept_names'])){
				$dept_name = $this->session->data['dept_names'];
			} else {
				$dept_name = '';
			}

			if(isset($this->session->data['is_dept'])){
				$is_dept = $this->session->data['is_dept'];
			} else {
				$is_dept = '0';
			}

			if(isset($this->session->data['is_super'])){
				$is_super = $this->session->data['is_super'];
			} else {
				$is_super = '0';
			}
			date_default_timezone_set("Asia/Kolkata");
			$template = new Template();		
			$template->data['leaves'] = $wfh;
			$template->data['dept_name'] = $dept_name;
			$template->data['is_dept'] = $is_dept;
			$template->data['is_super'] = $is_super;
			$template->data['title'] = 'Leave Ess List';
			if (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) {
				$template->data['base'] = HTTPS_SERVER;
			} else {
				$template->data['base'] = HTTP_SERVER;
			}
			$html = $template->fetch('transaction/leave_ess_html.tpl');
			//echo $html;exit;
			$filename = "Leave_Ess_List.html";
			header('Content-type: text/html');
			header('Content-Disposition: attachment; filename='.$filename);
			echo $html;
			exit;		
		} else {
			$this->session->data['warning'] = 'No Data Found';
			$this->redirect($this->url->link('transaction/leave_ess_dept', 'token=' . $this->session->data['token'].$url, 'SSL'));
		}
	}
}
?>