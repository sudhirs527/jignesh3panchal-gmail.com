<?php
/*
Plugin Name: WFH, Rota system for PL
Description: A custom plugin for interacting with a custom REST API.
Site url: https://wewant360.com/
Author: Wewant360
Author URI: https://wewant360.com/
*/
?>

<?php    
class ControllerCatalogLeave extends Controller { 
	private $error = array();

	public function index() {
		$this->language->load('catalog/leave');

		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('catalog/leave');
		$this->load->model('catalog/employee');

		$this->getList();
	}

	public function insert() {
		$this->language->load('catalog/leave');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/leave');
		$this->load->model('catalog/employee');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			//$emp_data = $this->model_transaction_transaction->getEmployees_dat($data['e_name_id']);
			$this->session->data['success'] = 'You have Inserted the Transaction';	
			//echo 'out';exit;
			$this->redirect($this->url->link('transaction/manualpunch', 'token=' . $this->session->data['token'].'&transaction_id='.$transaction_id, 'SSL'));
		}

		$this->getForm();
	}

	public function update() {
		$this->language->load('catalog/leave');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('catalog/leave');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

			//$this->request->post['ml_acc'] = 0; // as per client said on 20 feb 2024	

			$this->request->post['wfh_acc'] = 2; // as per client said on 20 feb 2024			

			$transaction_data = $this->model_catalog_leave->getleave($this->request->post['e_name_id']);
			if(!empty($transaction_data[0]['pl_acc'])){
				$this->request->post['pl_acc'] = $transaction_data[0]['pl_acc']; 
				// as per client said on 20 feb 2024
			}
			
			$this->model_catalog_leave->insert_leavedata($this->request->post);
			$this->session->data['success'] = 'You have Inserted the Transaction';	
		
			$this->redirect($this->url->link('catalog/leave', 'token=' . $this->session->data['token'], 'SSL'));
		}

		$this->getForm();
	}

	/****Start - WFH 20240110*********/
	public function import() {

		$this->language->load('catalog/leave');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/leave');

		$this->template = 'catalog/import.tpl';
		$this->children = array(
			'common/header',
			'common/footer'
		);

		$this->response->setOutput($this->render());
		$this->getImportForm();	
	}
	

	protected function getImportForm() {
		$this->data['heading_title'] = $this->language->get('heading_title');	

		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		}else {
			$this->data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$this->data['error_name'] = $this->error['name'];
		} else {
			$this->data['error_name'] = '';
		}	

		$this->data['button_save'] = $this->language->get('button_save');
		$this->data['button_cancel'] = $this->language->get('button_cancel');

		$url = '';

		$this->data['cancel'] = $this->url->link('catalog/leave', 'token=' . $this->session->data['token'], 'SSL');


		$this->data['action'] = $this->url->link('catalog/leave/importcsv', 'token=' . $this->session->data['token'] . $url, 'SSL');
		

		$this->data['breadcrumbs'] = array();

		$this->data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
			'separator' => false
		);

		$this->data['breadcrumbs'][] = array(
			'text'      => $this->language->get('Employee'),
			'href'      => $this->url->link('catalog/leave', 'token=' . $this->session->data['token'] . $url, 'SSL'),
			'separator' => ' :: '
		);

		$this->data['breadcrumbs'][] = array(
			'text'      => $this->language->get('Import Leave'),
			'href'      => $this->url->link('catalog/leave/import', 'token=' . $this->session->data['token'] . $url, 'SSL'),
			'separator' => ' :: '
		);

		if (isset($this->request->get['employee_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$employee_info = $this->model_catalog_employee->getemployee($this->request->get['employee_id']);
		}

		$this->data['token'] = $this->session->data['token'];

		$this->data['download_sample_csv'] = $this->url->link('catalog/leave/downloadSampleCSV', 'token=' . $this->session->data['token'], true);

		$this->data['text_download_csv_sample'] = 'Download CSV Sample';
		
		$this->template = 'catalog/import.tpl';
		$this->children = array(
			'common/header',
			'common/footer'
		);
		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} 
		else if(isset($this->session->data['warning']))
		{
			$this->data['error_warning'] = $this->session->data['warning'];
		}
		else {
			$this->data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$this->data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$this->data['success'] = '';
		}
		$this->response->setOutput($this->render());
	}   

	public function downloadSampleCSV() {
	    $csvContent = "EMP ID,Previous Year PL,PL,CL,SL,BL,LWP,ML,MAL,PAL,COVID,COF,WFH\n";
	    $csvContent .= "8411844,45,2,12,13,13,15,16,2,1,1,3,2\n";
	    $csvContent .= "8411843,41,8,8,8,8,4,3,2,2,2,3,2\n";
	    $csvContent .= "111111,0,8,8,8,8,4,3,2,2,2,3,2\n";
	   
	    header('Content-Type: text/csv');
	    header('Content-Disposition: attachment; filename="sample.csv"');
	    echo $csvContent;
	}

	public function importcsv() {
	    $this->language->load('catalog/leave');

	    $this->document->setTitle($this->language->get('heading_title'));

	    $this->load->model('catalog/leave');

		if ($this->request->server['REQUEST_METHOD'] == 'POST'){
		    $file = $this->request->files['upload_csv']['tmp_name'];

		    // Check if the file is a valid CSV file
		    if (($handle = fopen($file, 'r')) !== false) {
		        $this->load->model('catalog/leave');
		        $this->load->model('transaction/transaction'); // Make sure to load the correct model

		        $new_employee_leave = array();

		        $row = 0;

		        //query 
		        $exist_leaves = $this->db->query("SELECT `emp_id` FROM `oc_leave` WHERE `year` = '".date('Y')."' ")->rows;

		        if(!empty($exist_leaves))
		    	{
		    		$exist_leaves_array = array_column($exist_leaves, 'emp_id');
		    		array_unshift($exist_leaves_array, "-1");//if date found on first position then it will return 0 it will cause issue thats why added 1 on first position
		    	}
		    	else
		    	{
		    		$exist_leaves_array = array();
		    	}
		    	$this->load->model('catalog/employee');
		    	$existing_emp = $this->model_catalog_employee->getemployees_dash(array());
		    	if(!empty($existing_emp))
		    	{
		    		$existing_emp_array = array_column($existing_emp, 'username');
		    		array_unshift($existing_emp_array, "-1");//if date found on first position then it will return 0 it will cause issue thats why added 1 on first position
		    	}
		    	else
		    	{
		    		$existing_emp_array = array();
		    	}
		    	$existing_emp_str = $existing_leaves_str = $inserted_emp_str = "";
		    	
		        while (($data = fgetcsv($handle, 1000, ',')) !== false) {
		            $row++;
		           	$emp_id = $data[0];
		            if (empty($emp_id) || $row==1) {
		                // Log an error, skip the row, or handle the validation failure as needed
		                continue;
		            }
		            //if employee is not in our database then no need add leave
		            if(!in_array($emp_id, $existing_emp_array))
		            {
		            	$existing_emp_str .= $emp_id .", ";
		            	continue;
		            }

		            //if leave is already in database for current year then no need to import

		            if(in_array($emp_id, $exist_leaves_array))
		            {
		            	$existing_leaves_str .= $emp_id .", ";
		            	continue;
		            }  
		            
		            $employee_info = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "employee WHERE emp_code = '" . (int)$emp_id . "'")->row;

		            if(!empty($employee_info))
		            {
		            	$inserted_emp_str .= $emp_id .", ";
						$leave_data = array(
							'e_name_id' => $emp_id,
							'e_name'=>$employee_info['name'],
							'emp_doj'=>$employee_info['doj'],
							'emp_grade'=>$employee_info['grade'],
							'emp_designation'=>$employee_info['designation'],
						    'year' => date('Y'),
						    'prev_year_pl_leave' =>!empty($data[1])?$data[1]:0,
						    'pl_acc' =>!empty($data[2])?$data[2]:0,
						    'cl_acc' => !empty($data[3])?$data[3]:0,
						    'sl_acc' => !empty($data[4])?$data[4]:0,
						    'bl_acc' => !empty($data[5])?$data[5]:0,
						    'lwp_acc' => !empty($data[6])?$data[6]:0,
						    'ml_acc' => !empty($data[7])?$data[7]:0,
						    'mal_acc' => !empty($data[8])?$data[8]:0,
						    'pal_acc' => !empty($data[9])?$data[9]:0,
						    'covid_acc' => !empty($data[10])?$data[10]:0,
						    'cof_acc' => !empty($data[11])?$data[11]:0,
						    'wfh_acc' => !empty($data[12])?$data[12]:2,
						    'leave_id'=>'0'
						);

						
						$this->db->query("UPDATE `" . DB_PREFIX . "leave` SET `close_status` = '1' WHERE `emp_id` = '" . $emp_id . "' ");
						
			            $result = $this->model_catalog_leave->insert_leavedata($leave_data);
			            
			        }  			                       
		        }
		
		        fclose($handle);

		        
		        $success_msg = "";
		        $warning_msg = "";
		        if(!empty($inserted_emp_str))
		        {
		        	$success_msg .= $inserted_emp_str. " leaves are inserted succeessfully.     ";
		        }
		        if(!empty($existing_leaves_str))
		        {
		        	$warning_msg .= $existing_leaves_str. " leaves are already available for these employee.     ";
		        }
		        if(!empty($existing_emp_str))
		        {
		        	$warning_msg .= $existing_emp_str. " these employees are not available. ";
		        }
		        $this->session->data['success'] = $success_msg;
		        $this->session->data['warning'] = $warning_msg;
		        $this->redirect($this->url->link('catalog/leave/import', 'token=' . $this->session->data['token'] . $url . '&filter_name=' . $this->request->post['name'], 'SSL'));
		    } else {
		        $this->error['warning'] = 'Error reading the CSV file.';
		    }
		}

	    $this->index();
	}
		
	/****End - WFH 20240110*********/	

	protected function getList() {
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . $this->request->get['filter_name'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$this->data['breadcrumbs'] = array();

		$this->data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
			'separator' => false
		);

		$this->data['breadcrumbs'][] = array(
			'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('catalog/leave', 'token=' . $this->session->data['token'] . $url, 'SSL'),
			'separator' => ' :: '
		);

		$this->data['insert'] = $this->url->link('catalog/leave/insert', 'token=' . $this->session->data['token'] . $url, 'SSL');
		$this->data['delete'] = $this->url->link('catalog/leave/delete', 'token=' . $this->session->data['token'] . $url, 'SSL');	
		$this->data['change_year'] = $this->url->link('catalog/leavechangeyear', 'token=' . $this->session->data['token'] . $url, 'SSL');	

		$this->data['leaves'] = array();

		$data = array(
			'filter_name' => $filter_name,
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_admin_limit'),
			'limit' => $this->config->get('config_admin_limit')
		);

		$leave_total = $this->model_catalog_employee->getTotalemployees($data);

		$results = $this->model_catalog_employee->getemployees($data);

		foreach ($results as $result) {
			$action = array();

			$action[] = array(
				'text' => $this->language->get('text_edit'),
				'href' => $this->url->link('catalog/leave/update', 'token=' . $this->session->data['token'] . '&emp_code=' . $result['emp_code'] . $url, 'SSL')
			);

			$this->data['leaves'][] = array(
				'employee_id' => $result['employee_id'],
				'name'        => $result['name'],
				'selected'    => isset($this->request->post['selected']) && in_array($result['employee_id'], $this->request->post['selected']),
				'action'      => $action
			);
		}

		$this->data['token'] = $this->session->data['token'];	

		$this->data['heading_title'] = $this->language->get('heading_title');

		$this->data['text_no_results'] = $this->language->get('text_no_results');
		$this->data['text_delete'] = $this->language->get('text_delete');

		$this->data['button_insert'] = $this->language->get('button_insert');
		$this->data['button_delete'] = $this->language->get('button_delete');

		$this->data['button_filter'] = $this->language->get('button_filter');

		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {
			$this->data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$this->data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$this->data['success'] = '';
		}

		if (isset($this->session->data['warning'])) {
			$this->data['error_warning'] = $this->session->data['warning'];

			unset($this->session->data['warning']);
		} else {
			$this->data['error_warning'] = '';
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . $this->request->get['filter_name'];
		}

		$this->data['sort_name'] = $this->url->link('catalog/employee', 'token=' . $this->session->data['token'] . '&sort=name' . $url, 'SSL');

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . $this->request->get['filter_name'];
		}
		
		$pagination = new Pagination();
		$pagination->total = $leave_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_admin_limit');
		$pagination->text = $this->language->get('text_pagination');
		$pagination->url = $this->url->link('catalog/leave', 'token=' . $this->session->data['token'] . $url . '&page={page}', 'SSL');

		$this->data['pagination'] = $pagination->render();

		$this->data['sort'] = $sort;
		$this->data['order'] = $order;
		$this->data['filter_name'] = $filter_name;
		///$this->data['filter_trainer'] = $filter_trainer;
		//$this->data['filter_trainer_id'] = $filter_trainer_id;

		$this->template = 'catalog/leave_list.tpl';
		$this->children = array(
			'common/header',
			'common/footer'
		);

		$this->response->setOutput($this->render());
	}

	protected function getForm() {
		$this->data['heading_title'] = $this->language->get('heading_title');

		
		$this->data['button_save'] = $this->language->get('button_save');
		$this->data['button_cancel'] = $this->language->get('button_cancel');

		$this->data['text_no_results'] = $this->language->get('text_no_results');

		$this->data['tab_general'] = $this->language->get('tab_general');

		if (isset($this->session->data['success'])) {
			$this->data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$this->data['success'] = '';
		}

		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {	
			$this->data['error_warning'] = '';
		}

		if (isset($this->error['e_name'])) {
			$this->data['error_employee'] = $this->error['e_name'];
		} else {
			$this->data['error_employee'] = '';
		}

		if (isset($this->error['dot'])) {
			$this->data['error_dot'] = $this->error['dot'];
		} else {
			$this->data['error_dot'] = '';
		}

		$this->data['breadcrumbs'] = array();

		$this->data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
			'separator' => false
		);

		$this->data['breadcrumbs'][] = array(
			'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('catalog/leave', 'token=' . $this->session->data['token'], 'SSL'),
			'separator' => ' :: '
		);

		$this->data['cancel'] = $this->url->link('catalog/leave', 'token=' . $this->session->data['token'], 'SSL');
		
		if(isset($this->request->get['leave_id'])){
			$this->data['action'] = $this->url->link('catalog/leave/update', 'token=' . $this->session->data['token'].'&leave_id='.$this->request->get['leave_id'], 'SSL');
		} else {
			$this->data['action'] = $this->url->link('catalog/leave/update', 'token=' . $this->session->data['token'], 'SSL');
		}
		
		$transaction_data = array();
		if (isset($this->request->get['emp_code']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$transaction_data = $this->model_catalog_leave->getleave($this->request->get['emp_code']);
		}

		//echo "<pre>";print_r($transaction_data);exit;

		$emp_data = $this->model_catalog_leave->getEmployees_dat($this->request->get['emp_code']);


		$this->data['token'] = $this->session->data['token'];

		if (isset($this->request->post['leave_id'])) {
			$this->data['leave_id'] = $this->request->post['leave_id'];
		} elseif(isset($transaction_data[0]['leave_id'])) {
			$this->data['leave_id'] = $transaction_data[0]['leave_id'];
		} else {	
			$this->data['leave_id'] = 0;
		}

		if (isset($this->request->post['year'])) {
			$this->data['year'] = $this->request->post['year'];
		} elseif(isset($transaction_data[0]['year'])) {
			$this->data['year'] = $transaction_data[0]['year'];
		} else {	
			$this->data['year'] = date('Y');
		}

		if (isset($this->request->post['e_name'])) {
			$this->data['e_name'] = $this->request->post['e_name'];
			$this->data['e_name_id'] = $this->request->post['e_name_id'];
			$this->data['emp_code'] = $this->request->post['e_name_id'];
			$this->data['emp_doj'] = $this->request->post['emp_doj'];
			$this->data['emp_grade'] = $this->request->post['emp_grade'];
			$this->data['emp_designation'] = $this->request->post['emp_designation'];
		} elseif (isset($transaction_data[0]['emp_name'])) {
			$this->data['e_name'] = $transaction_data[0]['emp_name'];
			$this->data['e_name_id'] = $transaction_data[0]['emp_id'];
			$this->data['emp_code'] = $transaction_data[0]['emp_id'];
			$this->data['emp_doj'] = $transaction_data[0]['emp_doj'];
			$this->data['emp_grade'] = $transaction_data[0]['emp_grade'];
			$this->data['emp_designation'] = $transaction_data[0]['emp_designation'];
		} else {	
			$this->data['e_name'] = $emp_data['name'];
			$this->data['e_name_id'] = $emp_data['emp_code'];
			$this->data['emp_code'] = $emp_data['emp_code'];
			$this->data['emp_doj'] = $emp_data['doj'];
			$this->data['emp_grade'] = $emp_data['grade'];
			$this->data['emp_designation'] = $emp_data['designation'];
		}

		$current_date = date('Y-m-d');
		$doj = $this->data['emp_doj'];//date('Y-m-d');//

		$start_date2 = new DateTime($current_date);
		$since_start2 = $start_date2->diff(new DateTime($doj));

		$this->data['error_warning1'] = '';
		$this->data['editable'] = 1;
		/*
		if($since_start2->y >= 1){
			if($this->user->getId() == '1'){
				$this->data['editable'] = 1;
			}
		} elseif($since_start2->m >= 6){
			if($this->user->getId() == '1'){
				$this->data['editable'] = 1;
			}
		} else{
			if($this->data['emp_grade'] == 'CONSULTANT'){
				if($this->user->getId() == '1'){				
					$this->data['editable'] = 1;
				}
			} else {
				if($this->user->getId() == '1'){				
					$this->data['editable'] = 1;
				}
				//$this->data['error_warning1'] = 'Empolyee Not Eligible For Leaves';
				//$this->data['editable'] = 0;
			}
		}
		*/
		// echo '<pre>';
		// print_r($this->data['editable']);
		// exit;

		if (isset($this->request->post['prev_year_pl_leave'])) {
			$this->data['prev_year_pl_leave'] = $this->request->post['prev_year_pl_leave'];
		} elseif(isset($transaction_data[0]['prev_year_pl_leave'])) {
			$this->data['prev_year_pl_leave'] = $transaction_data[0]['prev_year_pl_leave'];
		} else {	
			$this->data['prev_year_pl_leave'] = 0;
		}

		if (isset($this->request->post['pl_acc'])) {
			$this->data['pl_acc'] = $this->request->post['pl_acc'];
		} elseif(isset($transaction_data[0]['pl_acc'])) {
			$this->data['pl_acc'] = $transaction_data[0]['pl_acc'];
		} else {	
			$this->data['pl_acc'] = 0;
		}

		if (isset($this->request->post['cl_acc'])) {
			$this->data['cl_acc'] = $this->request->post['cl_acc'];
		} elseif(isset($transaction_data[0]['cl_acc'])) {
			$this->data['cl_acc'] = $transaction_data[0]['cl_acc'];
		} else {	
			$this->data['cl_acc'] = 0;
		}

		if (isset($this->request->post['bl_acc'])) {
			$this->data['bl_acc'] = $this->request->post['bl_acc'];
		} elseif(isset($transaction_data[0]['bl_acc'])) {
			$this->data['bl_acc'] = $transaction_data[0]['bl_acc'];
		} else {	
			$this->data['bl_acc'] = 0;
		}

		if (isset($this->request->post['sl_acc'])) {
			$this->data['sl_acc'] = $this->request->post['sl_acc'];
		} elseif(isset($transaction_data[0]['sl_acc'])) {
			$this->data['sl_acc'] = $transaction_data[0]['sl_acc'];
		} else {	
			$this->data['sl_acc'] = 0;
		}

		if (isset($this->request->post['lwp_acc'])) {
			$this->data['lwp_acc'] = $this->request->post['lwp_acc'];
		} elseif(isset($transaction_data[0]['lwp_acc'])) {
			$this->data['lwp_acc'] = $transaction_data[0]['lwp_acc'];
		} else {	
			$this->data['lwp_acc'] = 0;
		}

		if (isset($this->request->post['ml_acc'])) {
			$this->data['ml_acc'] = $this->request->post['ml_acc'];
		} elseif(isset($transaction_data[0]['ml_acc'])) {
			$this->data['ml_acc'] = $transaction_data[0]['ml_acc'];
		} else {	
			$this->data['ml_acc'] = 0;
		}

		if (isset($this->request->post['mal_acc'])) {
			$this->data['mal_acc'] = $this->request->post['mal_acc'];
		} elseif(isset($transaction_data[0]['mal_acc'])) {
			$this->data['mal_acc'] = $transaction_data[0]['mal_acc'];
		} else {	
			$this->data['mal_acc'] = 0;
		}

		if (isset($this->request->post['pal_acc'])) {
			$this->data['pal_acc'] = $this->request->post['pal_acc'];
		} elseif(isset($transaction_data[0]['pal_acc'])) {
			$this->data['pal_acc'] = $transaction_data[0]['pal_acc'];
		} else {	
			$this->data['pal_acc'] = 0;
		}

		if (isset($this->request->post['cof_acc'])) {
			$this->data['cof_acc'] = $this->request->post['cof_acc'];
		} elseif(isset($transaction_data[0]['cof_acc'])) {
			$this->data['cof_acc'] = $transaction_data[0]['cof_acc'];
		} else {	
			$this->data['cof_acc'] = 0;
		}

		$this->template = 'catalog/leave_form.tpl';
		$this->children = array(
			'common/header',
			'common/footer'
		);


		if (isset($this->request->post['covid_acc'])) {
			$this->data['covid_acc'] = $this->request->post['covid_acc'];
		} elseif(isset($transaction_data[0]['covid_acc'])) {
			$this->data['covid_acc'] = $transaction_data[0]['covid_acc'];
		} else {	
			$this->data['covid_acc'] = 0;
		}

		/****Start - WFH 20240110*********/
		if (isset($this->request->post['wfh_acc'])) {
			$this->data['wfh_acc'] = $this->request->post['wfh_acc'];
		} elseif(isset($transaction_data[0]['covid_acc'])) {
			$this->data['wfh_acc'] = $transaction_data[0]['wfh_acc'];
		} else {	
			$this->data['wfh_acc'] = 0;
		}
		/****End - WFH 20240110*********/

		$this->response->setOutput($this->render());
	}  

	protected function validateForm() {
		$this->load->model('transaction/transaction');

		if (!$this->user->hasPermission('modify', 'transaction/horse_wise')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if(strlen(utf8_decode(trim($this->request->post['e_name']))) < 1 || strlen(utf8_decode(trim($this->request->post['e_name']))) > 255){
			$this->error['e_name'] = 'Please Select Employee Name';
		} else {
			if($this->request->post['e_name_id'] == ''){
				$emp_id = $this->model_transaction_transaction->getempexist($this->request->post['e_name_id']);				
				if($emp_id == 0){
					$this->error['e_name'] = 'Employee Does Not Exist';
				}
			}
		}

		// echo '<pre>';
		// print_r($this->error);
		// exit;

		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}


}
?>
