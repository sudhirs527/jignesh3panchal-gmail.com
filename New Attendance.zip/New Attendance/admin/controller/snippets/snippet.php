<?php    
class ControllerSnippetsSnippet extends Controller { 
	private $error = array();

	public function index() {
		$holiday_id = '12';//$this->request->get['holiday_id'];
		$holiday_dates = $this->db->query("SELECT `date` FROM `oc_holiday` WHERE `holiday_id` = '".$holiday_id."' ");
		$i = 0;
		if($holiday_dates->num_rows > 0){
			$date = $holiday_dates->row['date'];
			
			if($date < date('Y-m-d')){
				//echo 'aaaa';exit;
				$in = 1;
				$month = date('n', strtotime($date));
				$year = date('Y', strtotime($date));
				$day = date('j', strtotime($date));
				$sql = "SELECT `transaction_id`, `emp_id`, `emp_name`, `unit` FROM `oc_transaction` WHERE `date` = '".$date."' ORDER BY `emp_id` ";
				$resultss = $this->db->query($sql)->rows;
				// echo '<pre>';
				// print_r($resultss);
				// exit;
				foreach($resultss as $rkeys => $rvalues){
					$shift_sql = "SELECT `".$day."` FROM `oc_shift_schedule` WHERE `emp_code` = '".$rvalues['emp_id']."' AND `month` = '".$month."' AND `year` = '".$year."' ";
					$shift_datas = $this->db->query($shift_sql);
					if($shift_datas->num_rows > 0){
						$shift_data = $shift_datas->row[$day];
						$shift_exp = explode('_', $shift_data);
						if($shift_exp[0] == 'H'){
							$tran_datas = $this->db->query("SELECT `leave_status`, `firsthalf_status`, `secondhalf_status` FROM `oc_transaction` WHERE `transaction_id` = '".$rvalues['transaction_id']."' ");
							if($tran_datas->num_rows > 0){
								$tran_data = $tran_datas->row;
								//if($tran_data['leave_status'] != '1'){
									$update_sql = "UPDATE `oc_transaction` SET `holiday_id` = '".$holiday_id."', `firsthalf_status` = 'HLD', `secondhalf_status` = 'HLD', `absent_status` = '0' WHERE `transaction_id` = '".$rvalues['transaction_id']."' AND `emp_id` = '".$rvalues['emp_id']."' ";
									echo $update_sql;
									echo '<br />';
									$i ++;
									//exit;
									//$this->db->query($update_sql);
								//}
							}
						}
					}	
				}
			} else {
				$this->session->data['warning'] = 'Post Dated Holiday Cannot be Processed';
			}
		}
		echo $i;
		echo '<br />';
		echo 'out';exit;

		$t = DIR_DOWNLOAD."emp_list_for_software_updation.csv";
		//echo $t;exit;
		$file=fopen($t,"r");
		$i=1;
		//$department_data = array();
		//$designtion_data = array();
		// $this->db->query("TRUNCATE TABLE `oc_employee`");
		// $this->db->query("TRUNCATE TABLE `oc_department`");
		// $this->db->query("TRUNCATE TABLE `oc_designation`");
		// $this->db->query("TRUNCATE TABLE `oc_shift_schedule`");
		// $this->db->query("TRUNCATE TABLE `oc_leave`");
		// while(($var=fgetcsv($file,1000,","))!==FALSE){
		// 	if($i != 1) {
		// 		$var[4] = $var[4];
		// 		$var[8] = $var[8];
		// 		if($var[4] != ''){
		// 			if(!isset($department_data[$var[4]])){
		// 				$department_data[$var[4]] = html_entity_decode(strtolower(trim($var[4])));
		// 			}
		// 		}
		// 		if($var[8] != ''){
		// 			if(!isset($designtion_data[$var[8]])){
		// 				$designtion_data[$var[8]] = html_entity_decode(strtolower(trim($var[8])));
		// 			}	
		// 		}
		// 	}
		// 	$i ++;
		// }
		// fclose($file);
		// $department_data_linked = array();
		// foreach($department_data as $dkey => $dvalue){
		// 	$sql = "INSERT INTO `oc_department` SET `d_name` = '".$dkey."', `status` = '1' ";
		// 	$this->db->query($sql);
		// 	$department_id = $this->db->getLastId();
		// 	$department_data_linked[$dvalue] = $department_id;
		// }

		// $designation_data_linked = array();
		// foreach($designtion_data as $dkey => $dvalue){
		// 	$sql = "INSERT INTO `oc_designation` SET `d_name` = '".$dkey."', `status` = '1' ";
		// 	$this->db->query($sql);
		// 	$designation_id = $this->db->getLastId();
		// 	$designation_data_linked[$dvalue] = $designation_id;
		// }

		// // echo '<pre>';
		// // print_r($department_data_linked);
		// // echo '<pre>';
		// // print_r($designation_data_linked);
		// // exit;

		// $i=1;
		// $file=fopen($t,"r");
		while(($var=fgetcsv($file,1000,","))!==FALSE){
			if($i != 1) {
				$var0=addslashes($var[0]);//emp_code
				if($var0 != ''){
					$var1=addslashes($var[1]);//title
					$var2=addslashes($var[2]);//name
					//$var31=addslashes($var[4]);//department
					// $var3=html_entity_decode(strtolower(trim($var[4])));//department_id
					// if($var3 != ''){
					// 	$var3=$department_data_linked[$var3];
					// }
					$var4=addslashes($var[5]);//group
					$var5=addslashes($var[6]);//category
					$var6=addslashes($var[7]);//location
					// $var71=addslashes($var[8]);//designation
					// $var7=html_entity_decode(strtolower(trim($var[8])));//designation_id
					// if($var7 != ''){
					// 	$var7=$designation_data_linked[$var7];
					// }
					$var8=addslashes($var[10]);//doj
					if($var8 != ''){
						$var8 = Date('Y-m-d', strtotime($var8));//doj
					} else {
						$var8 = '0000-00-00';
					}
					$var9=addslashes($var[11]);//doc
					if($var9 != ''){
						$var9 = Date('Y-m-d', strtotime($var9));//doc
					} else {
						$var9 = '0000-00-00';
					}
					$var10=addslashes($var[17]);//email

					$emp_code = $var0;
					$user_name = $emp_code;
					$salt = substr(md5(uniqid(rand(), true)), 0, 9);
					$password = sha1($salt . sha1($salt . sha1($emp_code)));
					
					// $insert = "INSERT INTO `oc_employee` SET 
					// 			`emp_code` = '".$var0."', 
					// 			`title` = '".$var1."', 
					// 			`name` = '".$var2."', 
					// 			`department` = '".$var31."',
					// 			`department_id` = '".$var3."',
					// 			`group` = '".$var4."', 
					// 			`category` = '".$var5."', 
					// 			`unit` = '".$var6."', 
					// 			`designation` = '".$var71."', 
					// 			`designation_id` = '".$var7."', 
					// 			`doj` = '".$var8."', 
					// 			`doc` = '".$var9."', 
					// 			`email` = '".$var10."', 
					// 			`shift_type` = 'F',
					// 			`user_group_id` = '11',
					// 			`status` = '1',
					// 			`username` = '".$user_name."', 
					// 			`password` = '".$password."', 
					// 			`salt` = '".$salt."' "; 
					// $this->db->query($insert);
					
					// $insert1 = "INSERT INTO `oc_shift_schedule` SET 
					// 			`emp_code` = '".$var0."',
					// 			`1` = 'S_1',
					// 			`2` = 'S_1',
					// 			`3` = 'S_1',
					// 			`4` = 'S_1',
					// 			`5` = 'S_1',
					// 			`6` = 'S_1',
					// 			`7` = 'S_1',
					// 			`8` = 'S_1',
					// 			`9` = 'S_1',
					// 			`10` = 'S_1',
					// 			`11` = 'S_1',
					// 			`12` = 'S_1', 
					// 			`13` = 'S_1', 
					// 			`14` = 'S_1', 
					// 			`15` = 'S_1', 
					// 			`16` = 'S_1', 
					// 			`17` = 'S_1', 
					// 			`18` = 'S_1', 
					// 			`19` = 'S_1', 
					// 			`20` = 'S_1', 
					// 			`21` = 'S_1', 
					// 			`22` = 'S_1', 
					// 			`23` = 'S_1', 
					// 			`24` = 'S_1', 
					// 			`25` = 'S_1', 
					// 			`26` = 'S_1', 
					// 			`27` = 'S_1', 
					// 			`28` = 'S_1', 
					// 			`29` = 'S_1', 
					// 			`30` = 'S_1', 
					// 			`31` = 'S_1', 
					// 			`status` = '1' "; 
					// $this->db->query($insert1);

					$insert2 = "INSERT INTO `oc_leave` SET 
								`emp_id` = '".$var0."', 
								`emp_name` = '".$var2."', 
								`emp_doj` = '".$var8."', 
								`year` = '2016',
								`close_status` = '0' "; 
					$this->db->query($insert2);
					// echo $insert1;
					// echo '<br />';
					// exit;
				}
			}
			$i ++;	
		}
		fclose($file);
		echo 'out';exit;

		//echo 'In Progress';exit;
		$url_curl = "http://192.168.0.150:8014/attendance_api/get_data.php";
		//$fields_string = '';
		//url-ify the data for the POST
		// foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
		// $fields_string = rtrim($fields_string, '&');
		$final_datas = array(
			'get_data' => '1'
		);
		$data = json_encode($final_datas);
		//open connection
		$ch = curl_init($url_curl);
		//set the url, number of POST vars, POST data
		//curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		    'Content-Type: application/json',                                                                                
		    'Content-Length: ' . strlen($data))                                                                       
		); 
		curl_setopt($ch,CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		//execute post
		$result = curl_exec($ch);
		//close connection
		curl_close($ch);
		//decode the result
		$data = json_decode($result, true);
		//echo 'aaaaaa';
		//echo '<pre>';
		//print_r($data);
		//exit;
		// $data['21463']['emp_name'] = 'EVEREST M FARGOSE';
		// $data['21463']['NameTitle'] = 'Mr.';
		// $data['21463']['ticket_no'] = '21463';
		// $data['21463']['gr_code'] = 'E-OFFICIAL';
		// $data['21463']['br_code'] = '1';
		// $data['21463']['dept'] = 'P.L.D.';
		// $data['21463']['DivisionId'] = '13';
		// $data['21463']['group_name'] = 'OFFICIALS';
		// $data['21463']['category_name'] = 'PERMANENT';
		// $data['21463']['unit_name'] = 'MUMBAI';
		// $data['21463']['desig_name'] = 'OFFICER (EDP)';
		// $data['21463']['do_birth'] = '1959-10-26';
		// $data['21463']['do_join'] = '1982-07-02';
		// $data['21463']['date_cm'] = '1982-07-02';
		// $data['21463']['do_left'] = '2017-10-31';


		//$update = "UPDATE `oc_employee` SET `status` = '0' WHERE 1=1";
		//$this->db->query($update);
		foreach($data['final_datas'] as $dkey => $dvalue){
			$var1=$dvalue['ticket_no'];//emp_code
			$var2=$dvalue['NameTitle'];//title
			if($var2 == 'Mr.' || $var2 == 'Dr.'){
				$gender = 'Male';
			} else {
				$gender = 'Female';
			}
			$var3=$dvalue['emp_name'];//emp_name
			$var4=$dvalue['gr_code'];//grade
			$var5=$dvalue['br_code'];//branch
			$var6=$dvalue['dept'];//dept
			$var7=$dvalue['DivisionId'];//division
			$var8=$dvalue['group_name'];//group
			$var9=$dvalue['category_name'];//category
			$var10=$dvalue['unit_name'];//unit
			$var11=$dvalue['desig_name'];//designation
			
			$var12=$dvalue['do_birth'];//dob
			$var13=$dvalue['do_join'];//doj
			$var14=$dvalue['date_cm'];//doc
			$var15=$dvalue['do_left'];//dol
			
			// echo '-------start-------------';
			// echo '<br />';

			// echo 'dob unp: ' . $var1222;
			// echo '<br />';
			// echo 'dob: ' . $var12;
			// echo '<br />';

			// echo 'doj unp: ' . $var1333;
			// echo '<br />';
			// echo 'doj: ' . $var13;
			// echo '<br />';

			// echo 'doc unp: ' . $var1444;
			// echo '<br />';
			// echo 'doc: ' . $var14;
			// echo '<br />';

			// echo 'dol unp: ' . $var1555;
			// echo '<br />';
			// echo 'dol: ' . $var15;
			// echo '<br />';
			//if($var9 == 'CONSULTANT' && $var1 != '99989' && $var1 != '99990'){
				//$status = 0;
			//} else {
			$status = 1;
			//}

			if($var10 == 'CAS-MUMBAI'){
				$var10 = 'MUMBAI';
			}

			if($var10 == 'TCH'){
				$var10 = 'PUNE';
			}
			
			$emp_id_sql = "SELECT `employee_id` FROM `oc_employee` WHERE emp_code = '".$var1."' ";
			//echo $emp_id_sql;exit;			
			$emp_ids = $this->db->query($emp_id_sql);
			$emp_id = 0;
			if($emp_ids->num_rows > 0){
				//$emp_id = $emp_ids->row['id'];
				$update = "UPDATE `oc_employee` SET `title` = '".$var2."', `name` = '".$var3."', `grade` = '".$var4."', `branch` = '".$var5."', `department` = '".$var6."', `division` = '".$var7."', `group` = '".$var8."', `category` = '".$var9."', `unit` = '".$var10."', `designation` = '".$var11."', `dob` = '".$var12."', `doj` = '".$var13."', `doc` = '".$var14."', `dol` = '".$var15."', `status` = '".$status."' WHERE `emp_code` = '".$var1."'";
				$this->db->query($update);
				//echo $update;
				//echo '<br />';
				// exit;
			} else {
				$insert = "INSERT INTO `oc_employee` SET `emp_code` = '".$var1."', `title` = '".$var2."', `name` = '".$var3."', `grade` = '".$var4."', `branch` = '".$var5."', `department` = '".$var6."', `division` = '".$var7."', `group` = '".$var8."', `category` = '".$var9."', `unit` = '".$var10."', `designation` = '".$var11."', `dob` = '".$var12."', `doj` = '".$var13."', `doc` = '".$var14."', `dol` = '".$var15."', `status` = '".$status."', `gender` = '".$gender."', `daily_punch` = '1', `weekly_off` = '0', `shift` = '1' ";
				$this->db->query($insert);
				$insert1 = "INSERT INTO `oc_shift_schedule` SET `emp_code` = '".$var1."', `1` = 'S_1', `2` = 'S_1', `3` = 'S_1', `4` = 'S_1', `5` = 'S_1', `6` = 'S_1', `7` = 'S_1', `8` = 'S_1', `9` = 'S_1', `10` = 'S_1', `11` = 'S_1', `12` = 'S_1', `13` = 'S_1', `14` = 'S_1', `15` = 'S_1', `16` = 'S_1', `17` = 'S_1', `18` = 'S_1', `19` = 'S_1', `20` = 'S_1', `21` = 'S_1', `22` = 'S_1', `23` = 'S_1', `24` = 'S_1', `25` = 'S_1', `26` = 'S_1', `27` = 'S_1', `28` = 'S_1', `29` = 'S_1', `30` = 'S_1', `31` = 'S_1', `month` = '".date('n')."', `year` = '".date('Y')."' ";
				$this->db->query($insert1);
				//echo $insert;
				//echo '<br />';
				//echo $insert1;
				//echo '<br />';
			}
			//echo '<br />';
			//exit;
			// echo '-------End--------';
			// echo '<br />';
			// echo '<br />';
				
			//echo 'Done';
			//exit;
		}
		$this->session->data['success'] = 'Employess Updated Sucessfully';
		$this->redirect($this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'));


		// $t = DIR_DOWNLOAD."tktdtl.csv";
		// //echo $t;exit;
		// $file=fopen($t,"r");
		// $i=1;
		// $this->db->query("TRUNCATE TABLE `tot_ticket_details`");
		// while(($var=fgetcsv($file,1000,","))!==FALSE){
		// 	if($i != 1) {
		// 		$var0=addslashes($var[0]);//smo
		// 		$var1=addslashes($var[1]);//tds_no
		// 		$var2=addslashes($var[2]);//tkt_no
		// 		$var3=addslashes($var[3]);//race_date
		// 		$var3 = Date('Y-m-d', strtotime($var3));
		// 		$var4=addslashes($var[4]);//sold_machine_no
		// 		$var5=addslashes($var[5]);//sold_date
		// 		$var5 = Date('Y-m-d', strtotime($var5));
		// 		$var6=addslashes($var[6]);//venue
		// 		$var7=addslashes($var[7]);//paid_mcno
		// 		$var8=addslashes($var[8]);//paid_date
		// 		$var8 = Date('Y-m-d', strtotime($var8));
		// 		$var9=addslashes($var[9]);//tkt_val
		// 		$var10=addslashes($var[10]);//div_amt
		// 		$var11=addslashes($var[11]);//tds_amt
		// 		$var12=addslashes($var[12]);//sc_amt
		// 		$var13=addslashes($var[13]);//net_amt
		// 		$var14=addslashes($var[14]);//location_amt
		// 		$var15=addslashes($var[15]);//pay_mode
		// 		$var16=addslashes($var[16]);//pay_flag
				


		// 		$insert = "INSERT INTO `tot_ticket_details` SET 
		// 					`serial_number` = '".$var0."', 
		// 					`tds_number` = '".$var1."', 
		// 					`ticket_code` = '".$var2."', 
		// 					`race_date` = '".$var3."',
		// 					`sold_machine_no` = '".$var4."', 
		// 					`sold_date` = '".$var5."', 
		// 					`venue` = '".$var6."', 
		// 					`paid_machine_no` = '".$var7."', 
		// 					`paid_date` = '".$var8."', 
		// 					`ticket_amount` = '".$var9."', 
		// 					`gross_dividend_amount` = '".$var10."', 
		// 					`tds_amount` = '".$var11."', 
		// 					`sc_amount` = '".$var12."', 
		// 					`net_dividend_amount` = '".$var13."', 
		// 					`location` = '".$var14."', 
		// 					`payment_mode` = '".$var15."', 
		// 					`payment_flag` = '".$var16."' "; 
		// 		$this->db->query($insert);
		// 		// echo $insert;
		// 		// echo '<br />';
		// 		// exit;
		// 	}
		// 	$i ++;	
		// }
		// echo 'out';exit;		

		// $this->db->query("start transaction;"); // although reading a single row doesnt really require this
		// $cached=$this->db->query("SELECT * FROM `oc_employee` WHERE 1=1 ");
		// $this->db->query("commit;");
		
		// echo '<pre>';
		// print_r($cached);
		// exit;

		// $this->load->model('transaction/transaction');
		// $this->model_transaction_transaction->update_trans_master_values();
		// echo 'Process Done';exit;


		// $t = DIR_DOWNLOAD."SURITY_CSV.csv";
		// $file=fopen($t,"r");
		// $i=1;
		// while(($var=fgetcsv($file,1000,","))!==FALSE){
		// 	if($i != 1) {
		// 		$var1=addslashes($var[0]);//s_emp_id
		// 		$var2=addslashes($var[4]);//emp_id_1
		// 		$var3=addslashes($var[6]);//emp_date_start_1
		// 		$var4=addslashes($var[7]);//emp_date_end_1
				
		// 		$s_emp_id_sql = "SELECT `id` FROM `oc_employee` WHERE emp_id = '".$var1."' ";
		// 		$s_emp_ids = $this->db->query($s_emp_id_sql);
		// 		$s_emp_id = '0';
		// 		if($s_emp_ids->num_rows > 0){
		// 			$s_emp_id = $s_emp_ids->row['id'];
		// 		} else {
		// 			echo 'Not Found s_emp_id:'.$var1;
		// 			echo '<br />';
		// 		}

		// 		if($var2 != '0' && $s_emp_id != '0'){
		// 			$emp_id_sql_1 = "SELECT `id` FROM `oc_employee` WHERE emp_id = '".$var2."' ";
		// 			$emp_ids_1 = $this->db->query($emp_id_sql_1);
		// 			$emp_id_1 = 0;
		// 			if($emp_ids_1->num_rows > 0){
		// 				$emp_id_1 = $emp_ids_1->row['id'];
		// 				$insert = "INSERT INTO `oc_emp_sureity` SET `emp_id` = '".$emp_id_1."', `s_emp_id` = '".$s_emp_id."', `loan_date` = '".$var3."', `last_date` = '".$var4."' ";
		// 				$this->db->query($insert);
		// 				//echo $insert;
		// 				//echo '<br />';
		// 			} else {
		// 				echo 'Not Found emp_id_1:'.$var2;
		// 				echo '<br />';
		// 			}
		// 		}

		// 		$var5=addslashes($var[8]);//emp_id_2;
		// 		$var6=addslashes($var[10]);//emp_date_start_2;
		// 		$var7=addslashes($var[11]);//emp_date_end_2;
				
		// 		if($var5 != '0' && $s_emp_id != '0'){
		// 			$emp_id_sql_2 = "SELECT `id` FROM `oc_employee` WHERE emp_id = '".$var5."' ";
		// 			$emp_ids_2 = $this->db->query($emp_id_sql_2);
		// 			$emp_id_2 = 0;
		// 			if($emp_ids_2->num_rows > 0){
		// 				$emp_id_2 = $emp_ids_2->row['id'];
		// 				$insert = "INSERT INTO `oc_emp_sureity` SET `emp_id` = '".$emp_id_2."', `s_emp_id` = '".$s_emp_id."', `loan_date` = '".$var6."', `last_date` = '".$var7."' ";
		// 				$this->db->query($insert);
		// 				//echo $insert;
		// 				//echo '<br />';
		// 			} else {
		// 				echo 'Not Found emp_id_2:'.$var5;
		// 				echo '<br />';	
		// 			}
		// 		}

		// 		$var8=addslashes($var[12]);//emp_id_3;
		// 		$var9=addslashes($var[14]);//emp_date_start_3;
		// 		$var10=addslashes($var[15]);//emp_date_end_3;
				
		// 		if($var8 != '0' && $s_emp_id != '0'){
		// 			$emp_id_sql_3 = "SELECT `id` FROM `oc_employee` WHERE emp_id = '".$var8."' ";
		// 			$emp_ids_3 = $this->db->query($emp_id_sql_3);
		// 			$emp_id_3 = 0;
		// 			if($emp_ids_3->num_rows > 0){
		// 				$emp_id_3 = $emp_ids_3->row['id'];
		// 				$insert = "INSERT INTO `oc_emp_sureity` SET `emp_id` = '".$emp_id_3."', `s_emp_id` = '".$s_emp_id."', `loan_date` = '".$var9."', `last_date` = '".$var10."' ";
		// 				$this->db->query($insert);
		// 				//echo $insert;exit;
		// 				//echo '<br />';
		// 			} else {
		// 				echo 'Not Found emp_id_3:'.$var8;
		// 				echo '<br />';	
		// 			}
		// 		}
		// 	}
		// 	$i++;
		// }
		// echo 'Done';exit;

		// $emp_id_sql = "SELECT `emp_code` FROM `oc_employee` WHERE 1=1 ";
		// $emp_ids = $this->db->query($emp_id_sql);
		// // echo '<pre>';
		// // print_r($emp_ids);
		// // exit;
		// foreach ($emp_ids->rows as $ekey => $evalue) {
		// 	$insert = "INSERT INTO `oc_shift_schedule` SET `emp_code` = '".$evalue['emp_code']."', `1` = 'S_1', `2` = 'S_1', `3` = 'S_1', `4` = 'S_1', `5` = 'S_1', `6` = 'S_1', `7` = 'S_1', `8` = 'S_1', `9` = 'S_1', `10` = 'S_1', `11` = 'S_1', `12` = 'S_1', `13` = 'S_1', `14` = 'S_1', `15` = 'S_1', `16` = 'S_1', `17` = 'S_1', `18` = 'S_1', `19` = 'S_1', `20` = 'S_1', `21` = 'S_1', `22` = 'S_1', `23` = 'S_1', `24` = 'S_1', `25` = 'S_1', `26` = 'S_1', `27` = 'S_1', `28` = 'S_1', `29` = 'S_1', `30` = 'S_1', `31` = 'S_1', `month` = '10', `year` = '2015' ";
		// 	//$insert = "INSERT INTO `oc_shift_schedule` SET `emp_code` = '".$evalue['emp_code']."', `1` = '1', `2` = '1', `3` = '1', `4` = '1', `5` = '1', `6` = '1', `7` = '1', `8` = '1', `9` = '1', `10` = '1', `11` = '1', `12` = '1', `13` = '1', `14` = '1', `15` = '1', `16` = '1', `17` = '1', `18` = '1', `19` = '1', `20` = '1', `21` = '1', `22` = '1', `23` = '1', `24` = '1', `25` = '1', `26` = '1', `27` = '1', `28` = '1', `29` = '1', `30` = '1', `31` = '1', `month` = '10', `year` = '2015' ";
		// 	$this->db->query($insert);
		// }
		// echo 'Done';exit;
			
		
		$t = DIR_DOWNLOAD."timemas.csv";
		if(file_exists($t)){
			$file=fopen($t,"r");
			$i=1;
			//$emp_id_sql = "TRUNCATE TABLE `oc_employee` ";
			//$this->db->query($emp_id_sql);
			$update = "UPDATE `oc_employee` SET `status` = '0' WHERE 1=1";
			$this->db->query($update);
			while(($var=fgetcsv($file,1000,","))!==FALSE){
				if($i != 1) {
					$var1=addslashes($var[0]);//emp_code
					$var2=addslashes($var[1]);//title
					if($var2 == 'Mr.' || $var2 == 'Dr.'){
						$gender = 'Male';
					} else {
						$gender = 'Female';
					}
					$var3=addslashes($var[2]);//emp_name
					$var4=addslashes($var[3]);//grade
					$var5=addslashes($var[4]);//branch
					$var6=addslashes($var[5]);//dept
					$var7=addslashes($var[6]);//division
					$var8=addslashes($var[7]);//group
					$var9=addslashes($var[8]);//category
					$var10=addslashes($var[9]);//unit
					$var11=addslashes($var[10]);//designation
					
					$var1222=addslashes($var[11]);//dob
					$var122 = explode('/', $var1222);
					$var12 = $var122[2].'-'.$var122[1].'-'.$var122[0];
					//$var12 = date('Y-m-d', strtotime($var122));

					$var1333=addslashes($var[12]);//doj
					$var133 = explode('/', $var1333);
					$var13 = $var133[2].'-'.$var133[1].'-'.$var133[0];
					//$var13 = date('Y-m-d', strtotime($var133));

					$var1444=addslashes($var[13]);//doc
					$var144 = explode('/', $var1444);
					$var14 = $var144[2].'-'.$var144[1].'-'.$var144[0];
					//$var14 = date('Y-m-d', strtotime($var144));

					$var1555=addslashes($var[14]);//dol
					$var155 = explode('/', $var1555);
					$var15 = $var155[2].'-'.$var155[1].'-'.$var155[0];
					//$var15 = date('Y-m-d', strtotime($var155));

					// $var133=addslashes($var[12]);//doj
					// $var13 = date('Y-m-d', strtotime($var133));

					// $var144=addslashes($var[13]);//doc
					// $var14 = date('Y-m-d', strtotime($var144));

					// $var155=addslashes($var[14]);//dol
					// $var15 = date('Y-m-d', strtotime($var155));

					// echo '-------start-------------';
					// echo '<br />';

					// echo 'dob unp: ' . $var1222;
					// echo '<br />';
					// echo 'dob: ' . $var12;
					// echo '<br />';

					// echo 'doj unp: ' . $var1333;
					// echo '<br />';
					// echo 'doj: ' . $var13;
					// echo '<br />';

					// echo 'doc unp: ' . $var1444;
					// echo '<br />';
					// echo 'doc: ' . $var14;
					// echo '<br />';

					// echo 'dol unp: ' . $var1555;
					// echo '<br />';
					// echo 'dol: ' . $var15;
					// echo '<br />';
					if($var9 == 'CONSULTANT' && $var1 != '99989' && $var1 != '99990'){
						$status = 0;
					} else {
						$status = 1;
					}

					if($var10 == 'CAS-MUMBAI'){
						$var10 = 'MUMBAI';
					}

					if($var10 == 'TCH'){
						$var10 = 'PUNE';
					}

					$emp_id_sql = "SELECT `employee_id` FROM `oc_employee` WHERE emp_code = '".$var1."' ";
					$emp_ids = $this->db->query($emp_id_sql);
					$emp_id = 0;
					if($emp_ids->num_rows > 0){
						//$emp_id = $emp_ids->row['id'];
						$update = "UPDATE `oc_employee` SET `title` = '".$var2."', `name` = '".$var3."', `grade` = '".$var4."', `branch` = '".$var5."', `department` = '".$var6."', `division` = '".$var7."', `group` = '".$var8."', `category` = '".$var9."', `unit` = '".$var10."', `designation` = '".$var11."', `dob` = '".$var12."', `doj` = '".$var13."', `doc` = '".$var14."', `dol` = '".$var15."', `status` = '".$status."' WHERE `emp_code` = '".$var1."'";
						$this->db->query($update);
						//echo $update;
						//echo '<br />';
						// exit;
					} else {
						$insert = "INSERT INTO `oc_employee` SET `emp_code` = '".$var1."', `title` = '".$var2."', `name` = '".$var3."', `grade` = '".$var4."', `branch` = '".$var5."', `department` = '".$var6."', `division` = '".$var7."', `group` = '".$var8."', `category` = '".$var9."', `unit` = '".$var10."', `designation` = '".$var11."', `dob` = '".$var12."', `doj` = '".$var13."', `doc` = '".$var14."', `dol` = '".$var15."', `status` = '".$status."', `gender` = '".$gender."', `daily_punch` = '1', `weekly_off` = '0', `shift` = '1' ";
						$this->db->query($insert);
						$insert = "INSERT INTO `oc_shift_schedule` SET `emp_code` = '".$var1."', `1` = 'S_1', `2` = 'S_1', `3` = 'S_1', `4` = 'S_1', `5` = 'S_1', `6` = 'S_1', `7` = 'S_1', `8` = 'S_1', `9` = 'S_1', `10` = 'S_1', `11` = 'S_1', `12` = 'S_1', `13` = 'S_1', `14` = 'S_1', `15` = 'S_1', `16` = 'S_1', `17` = 'S_1', `18` = 'S_1', `19` = 'S_1', `20` = 'S_1', `21` = 'S_1', `22` = 'S_1', `23` = 'S_1', `24` = 'S_1', `25` = 'S_1', `26` = 'S_1', `27` = 'S_1', `28` = 'S_1', `29` = 'S_1', `30` = 'S_1', `31` = 'S_1', `month` = '".date('n')."', `year` = '".date('Y')."' ";
						$this->db->query($insert);
						//echo $insert;
						//echo '<br />';
					}
					//exit;
					// echo '-------End--------';
					// echo '<br />';
					// echo '<br />';
				}
				$i++;
			}
			//echo 'Done';
			//exit;
			$this->session->data['success'] = 'Employess Updated Sucessfully';
			$this->redirect($this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'));
		} else {
			$this->session->data['warning'] = 'Please Upload timemas.csv in Download Folder';
			$this->redirect($this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'));
		}
		

		// echo 'Done';exit;

		// $t = DIR_DOWNLOAD."ccs_report_csv.csv";
		// $file=fopen($t,"r");
		// $i=1;
		// while(($var=fgetcsv($file,1000,","))!==FALSE){
		// 	if($i != 1) {
		// 		$var1=addslashes($var[1]);//unit_name
		// 		$var2=addslashes($var[2]);//department
				
		// 		$var33=addslashes($var[9]);//dob
		// 		$var3 = date('Y-m-d', strtotime($var33));
				
		// 		//echo $var3;exit;

		// 		$var44=addslashes($var[10]);//doj
		// 		$var4 = date('Y-m-d', strtotime($var44));
				
		// 		$var5=addslashes($var[11]);//l_address_1
		// 		$var6=addslashes($var[12]);//l_address_2
		// 		$var7=addslashes($var[13]);//l_address_3
		// 		$var8=addslashes($var[14]);//l_address_4

		// 		$var9=addslashes($var[15]);//p_address_1
		// 		$var10=addslashes($var[16]);//p_address_2
		// 		$var11=addslashes($var[17]);//p_address_3
		// 		$var12=addslashes($var[18]);//p_address_4
				
		// 		$var13=addslashes($var[3]);//emp_id
				
		// 		$emp_id_sql = "SELECT `id`, address_1 FROM `oc_employee` WHERE emp_id = '".$var13."' ";
		// 		$emp_ids = $this->db->query($emp_id_sql);
		// 		$emp_id = 0;
		// 		if($emp_ids->num_rows > 0){
		// 			$insert = "UPDATE `oc_employee` SET `unit_name` = '".$var1."', `department` = '".$var2."', `dob` = '".$var3."', `doj` = '".$var4."', `dop` = '".$var4."', `don` = '".$var4."' WHERE `emp_id` = '".$var13."' ";
		// 			$this->db->query($insert);

		// 			if($emp_ids->row['address_1'] == ''){
		// 				if($var9 != ''){
		// 					$insert1 = "UPDATE `oc_employee` SET `address_1` = '".$var9."', `address_2` = '".$var10."', `address_3` = '".$var11."', `address_4` = '".$var12."' WHERE `emp_id` = '".$var13."' ";
		// 				} else {
		// 					$insert1 = "UPDATE `oc_employee` SET `address_1` = '".$var5."', `address_2` = '".$var6."', `address_3` = '".$var7."', `address_4` = '".$var8."' WHERE `emp_id` = '".$var13."' ";
		// 				}
		// 				$this->db->query($insert1);
		// 			}
		// 			// echo $insert;
		// 			// echo '<br />';
		// 			// echo $insert1;
		// 			// echo '<br />';
		// 		} else {
		// 			echo 'Not Found emp_id:'.$var1;
		// 			echo '<br />';
		// 		}
		// 	}
		// 	$i++;
		// }
		// echo 'Done';exit;

		// $emp_id_sql = "SELECT * FROM `oc_shift_schedule` WHERE `month` = '10' AND `year` = '2015' ";
		// $emp_ids = $this->db->query($emp_id_sql);
		// // echo '<pre>';
		// // print_r($emp_ids);
		// // exit;
		// foreach ($emp_ids->rows as $skey => $svalue) {
		// 	$insert = "INSERT INTO `oc_shift_schedule` SET `emp_code` = '".$svalue['emp_code']."', `1` = '".$svalue[1]."', `2` = '".$svalue[2]."', `3` = '".$svalue[3]."', `4` = '".$svalue[4]."', `5` = '".$svalue[5]."', `6` = '".$svalue[6]."', `7` = '".$svalue[7]."', `8` = '".$svalue[8]."', `9` = '".$svalue[9]."', `10` = '".$svalue[10]."', `11` = '".$svalue[11]."', `12` = '".$svalue[12]."', `13` = '".$svalue[13]."', `14` = '".$svalue[14]."', `15` = '".$svalue[15]."', `16` = '".$svalue[16]."', `17` = '".$svalue[17]."', `18` = '".$svalue[18]."', `19` = '".$svalue[19]."', `20` = '".$svalue[20]."', `21` = '".$svalue[21]."', `22` = '".$svalue[22]."', `23` = '".$svalue[23]."', `24` = '".$svalue[24]."', `25` = '".$svalue[25]."', `26` = '".$svalue[26]."', `27` = '".$svalue[27]."', `28` = '".$svalue[28]."', `29` = '".$svalue[29]."', `30` = '".$svalue[30]."', `31` = '".$svalue[31]."', `month` = '09', `year` = '2015' ";
		// 	//echo $insert;exit;
		// 	//$insert = "INSERT INTO `oc_shift_schedule` SET `emp_code` = '".$evalue['emp_code']."', `1` = '1', `2` = '1', `3` = '1', `4` = '1', `5` = '1', `6` = '1', `7` = '1', `8` = '1', `9` = '1', `10` = '1', `11` = '1', `12` = '1', `13` = '1', `14` = '1', `15` = '1', `16` = '1', `17` = '1', `18` = '1', `19` = '1', `20` = '1', `21` = '1', `22` = '1', `23` = '1', `24` = '1', `25` = '1', `26` = '1', `27` = '1', `28` = '1', `29` = '1', `30` = '1', `31` = '1', `month` = '10', `year` = '2015' ";
		// 	$this->db->query($insert);
		// }
		// echo 'Done';exit;

		// $t = DIR_DOWNLOAD."time09_csv.csv"; //
		// if(file_exists($t)){
		// 	$file=fopen($t,"r");
		// 	$i=1;
		// 	while(($var=fgetcsv($file,1000,","))!==FALSE){
		// 		if($i != 1) {

		// 			$var1=addslashes($var[1]);//emp_code
		// 			$var2=addslashes($var[9]);//date
		// 			$var3=addslashes($var[18]);//in_time
		// 			$var4=addslashes($var[20]);//out_time
		// 			$var5=addslashes($var[0]);//manual_stat
		// 			if($var5 == 'M'){
		// 				$var5 = '1';
		// 			} else {
		// 				$var5 = '0';
		// 			}
		// 			$var6=addslashes($var[13]);//pre
		// 			$var7=addslashes($var[14]);//abs
		// 			$var8=addslashes($var[15]);//leave
		// 			$var9=addslashes($var[16]);//hld
		// 			$var10=addslashes($var[17]);//wlk_off

		// 			$var11=addslashes($var[33]);//firsthalf
		// 			$var12=addslashes($var[34]);//secondhalf

		// 			//if($var6 == 0){
		// 				$var2 = date('Y-m-d', strtotime($var2));
		// 				$mystring = $var3;
		// 				$findme   = ':';
		// 				$pos = strpos($mystring, $findme);
		// 				if($pos !== false){
		// 					$in_times = substr($var3, 0, 2). ":" .substr($var3, 3, 2);
		// 	    		} else {
		// 	    			if($var3 != ''){
		// 	    				$in_exp = explode('.', $var3);
		// 	    				$in_times = $in_exp[0]. ":" .$in_exp[1];
		// 	    			} else {
		// 	    				$in_times = ':';
		// 	    			}
		// 	    			//$in_times = substr($var3, 0, 1). ":" .substr($var3, 2, 2);
		// 	    		}

		// 	    		if($in_times != ':'){
		// 	    			$in_time = date("H:i", strtotime($in_times));
		// 		    		$insert = "INSERT INTO `oc_attendance` SET `emp_id` = '".$var1."', `punch_date` = '".$var2."', `punch_time` = '".$in_time."', `status` = '0', `manual_status` = '".$var5."', `present` = '".$var6."', `absent` = '".$var7."', `leave` = '".$var8."', `holiday` = '".$var9."', `weekly_off` = '".$var10."', `firsthalf` = '".$var11."', `secondhalf` = '".$var12."' ";
		// 					//echo '<br />';
		// 					$this->db->query($insert);
		// 				}

		// 				$mystring = $var4;
		// 				$findme   = ':';
		// 				$pos = strpos($mystring, $findme);
		// 				if($pos !== false){
		// 					$in_times = substr($var4, 0, 2). ":" .substr($var4, 3, 2);
		// 	    		} else {
		// 	    			//$in_times = substr($var4, 0, 2). ":" .substr($var4, 3, 2);
		// 	    			if($var4 != ''){
		// 	    				$in_exp = explode('.', $var4);
		// 	    				$in_times = $in_exp[0]. ":" .$in_exp[1];
		// 	    			} else {
		// 	    				$in_times = ':';
		// 	    			}
		// 	    		}
		// 	    		if($in_times != ':'){
		// 	    			$in_time = date("H:i", strtotime($in_times));
		// 	    			$insert = "INSERT INTO `oc_attendance` SET `emp_id` = '".$var1."', `punch_date` = '".$var2."', `punch_time` = '".$in_time."', `status` = '0', `manual_status` = '".$var5."', `present` = '".$var6."', `absent` = '".$var7."', `leave` = '".$var8."', `holiday` = '".$var9."', `weekly_off` = '".$var10."', `firsthalf` = '".$var11."', `secondhalf` = '".$var12."' ";
		// 					//echo $insert;
		// 					//echo '<br />';
		// 					//echo '<br />';
		// 					$this->db->query($insert);
		// 				}
		// 				//echo '---done----';
		// 				//echo '<br />';
		// 			//}
		// 		}
		// 		$i++;
		// 	}
		// }
		// echo 'Done';exit;

		// $this->load->model('transaction/transaction');

		// $days = $this->GetDays('2015-01-01', '2015-01-31');
		// $day = array();
		// foreach ($days as $dkey => $dvalue) {
  //       	$dates = explode('-', $dvalue);
  //       	$day[$dkey]['day'] = $dates[2];
  //       	$day[$dkey]['date'] = $dvalue;
  //       }
  //       // echo '<pre>';
  //       // print_r($day);
  //       // exit;
  //       foreach($day as $dkey => $dvalue){
		// 	$raw_attendance_datass = $this->model_transaction_transaction->getrawattendance_group_date($dvalue['date']);
		// 	if($raw_attendance_datass) {
		// 		foreach ($raw_attendance_datass as $rkeyss => $rvaluess) {
		// 			$emp_data = $this->model_transaction_transaction->getempdata($rvaluess['emp_id']);
		// 			if(isset($emp_data['name']) && $emp_data['name'] != '' && $emp_data['shift_type'] == 'F'){
		// 				$emp_name = $emp_data['name'];
		// 				$department = $emp_data['department'];
		// 				$unit = $emp_data['unit'];
		// 				$group = $emp_data['group'];

		// 				$day_date = date('j', strtotime($dvalue['date']));
		// 				$month = date('n', strtotime($dvalue['date']));
		// 				$year = date('Y', strtotime($dvalue['date']));

		// 				$update3 = "SELECT  `".$day_date."` FROM `oc_shift_schedule` WHERE `month` ='".$month."' AND `year` = '".$year."' AND `emp_code` = '".$rvaluess['emp_id']."' ";
		// 				$shift_schedule = $this->db->query($update3)->row;
		// 				$schedule_raw = explode('_', $shift_schedule[$day_date]);
						
		// 				if($rvaluess['holiday'] != 0){
		// 					$act_intime = $this->model_transaction_transaction->getrawattendance_in_time($rvaluess['emp_id'], $rvaluess['punch_date']);
		// 					$act_outtime = $this->model_transaction_transaction->getrawattendance_out_time($rvaluess['emp_id'], $rvaluess['punch_date']);
		// 					if($act_intime == $act_outtime){
		// 						$act_outtime = '00:00:00';
		// 					}

		// 					$sql = "INSERT INTO `oc_transaction` SET `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `holiday_id` = '1', `day` = '".$day."', `month` = '".$month."', `year` = '".$year."', `date` = '".$rvaluess['punch_date']."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `manual_status` = '".$rvaluess['manual_status']."' ";
		// 					$this->db->query($sql);
		// 				} elseif($rvaluess['weekly_off'] != 0){

		// 					$act_intime = $this->model_transaction_transaction->getrawattendance_in_time($rvaluess['emp_id'], $rvaluess['punch_date']);
		// 					$act_outtime = $this->model_transaction_transaction->getrawattendance_out_time($rvaluess['emp_id'], $rvaluess['punch_date']);
		// 					if($act_intime == $act_outtime){
		// 						$act_outtime = '00:00:00';
		// 					}

		// 					$sql = "INSERT INTO `oc_transaction` SET `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `weekly_off` = '1', `day` = '".$day."', `month` = '".$month."', `year` = '".$year."', `date` = '".$rvaluess['punch_date']."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `manual_status` = '".$rvaluess['manual_status']."' ";
		// 					$this->db->query($sql);
		// 				} else {
		// 					//if($schedule_raw[0] == 'S'){
		// 					$update4 = "SELECT  `1` FROM `oc_shift_schedule` WHERE `month` ='".$month."' AND `year` = '".$year."' AND `emp_code` = '".$rvaluess['emp_id']."' ";
		// 					$shift_schedule = $this->db->query($update4)->row;
		// 					$schedule_raw = explode('_', $shift_schedule['1']);
		// 					$shift_id = $schedule_raw[1];
		// 					$shift_data = $this->model_transaction_transaction->getshiftdata($shift_id);
		// 					if(isset($shift_data['shift_id'])){
		// 						$shift_intime = $shift_data['in_time'];
		// 						$shift_outtime = $shift_data['out_time'];

		// 						$act_intime = $this->model_transaction_transaction->getrawattendance_in_time($rvaluess['emp_id'], $rvaluess['punch_date']);
		// 						$act_outtime = $this->model_transaction_transaction->getrawattendance_out_time($rvaluess['emp_id'], $rvaluess['punch_date']);
								
		// 						if($act_intime == $act_outtime){
		// 							$act_outtime = '00:00:00';
		// 						}
		// 						//$act_intime = "09:15:00";
		// 						//$act_outtime = "17:20:00";

		// 						$late_time = '00:00:00';
		// 						if($act_intime != '00:00:00'){
		// 							$first_half = 1;
		// 							$second_half = 1;
		// 							$start_date = new DateTime($rvaluess['punch_date'].' '.$shift_intime);
		// 							$since_start = $start_date->diff(new DateTime($rvaluess['punch_date'].' '.$act_intime));
		// 							$late_time = $since_start->h.':'.$since_start->i.':'.$since_start->s;
		// 							if($since_start->invert == 1){
		// 								$late_time = '00:00:00';
		// 							} else {
		// 								if($since_start->h >= 3){
		// 									$first_half = 0;
		// 								}
		// 							}
		// 						} else {
		// 							$first_half = 0;
		// 							$second_half = 0;
		// 						}

		// 						$early_time = '00:00:00';
		// 						if($act_outtime != '00:00:00'){
		// 							$start_date1 = new DateTime($rvaluess['punch_date'].' '.$shift_outtime);
		// 							$since_start1 = $start_date1->diff(new DateTime($rvaluess['punch_date'].' '.$act_outtime));
		// 							$early_time = $since_start1->h.':'.$since_start1->i.':'.$since_start1->s;					
		// 							if($since_start1->invert == 0){
		// 								$early_time = '00:00:00';
		// 							}
		// 						}					
								
		// 						$working_time = '00:00:00';
		// 						if($act_outtime != '00:00:00'){
		// 							$start_date2 = new DateTime($rvaluess['punch_date'].' '.$act_intime);
		// 							$since_start2 = $start_date2->diff(new DateTime($rvaluess['punch_date'].' '.$act_outtime));
		// 							$working_time = $since_start2->h.':'.$since_start2->i.':'.$since_start2->s;
		// 							if($since_start2->h >= 4){
		// 								$second_half = 1;
		// 							} else {
		// 								$second_half = 0;
		// 							}
		// 						} else {
		// 							$second_half = 0;
		// 						}


		// 						$day = date('j', strtotime($rvaluess['punch_date']));
		// 						$month = date('n', strtotime($rvaluess['punch_date']));
		// 						$year = date('Y', strtotime($rvaluess['punch_date']));

		// 						$sql = "INSERT INTO `oc_transaction` SET `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `day` = '".$day."', `month` = '".$month."', `year` = '".$year."', `date` = '".$rvaluess['punch_date']."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `manual_status` = '".$rvaluess['manual_status']."' ";
		// 						//echo $sql;exit;
		// 						$this->db->query($sql);
		// 					}
		// 				}
		// 			}
		// 		}
		// 		//echo 'out';exit;
		// 	}
		// }
		// echo 'Done';exit;
}

	public function GetDays($sStartDate, $sEndDate){  
		// Firstly, format the provided dates.  
		// This function works best with YYYY-MM-DD  
		// but other date formats will work thanks  
		// to strtotime().  
		$sStartDate = date("Y-m-d", strtotime($sStartDate));  
		$sEndDate = date("Y-m-d", strtotime($sEndDate));  
		// Start the variable off with the start date  
		$aDays[] = $sStartDate;  
		// Set a 'temp' variable, sCurrentDate, with  
		// the start date - before beginning the loop  
		$sCurrentDate = $sStartDate;  
		// While the current date is less than the end date  
		while($sCurrentDate < $sEndDate){  
		// Add a day to the current date  
		$sCurrentDate = date("Y-m-d", strtotime("+1 day", strtotime($sCurrentDate)));  
			// Add this new day to the aDays array  
		$aDays[] = $sCurrentDate;  
		}
		// Once the loop has finished, return the  
		// array of days.  
		return $aDays;  
	}

	public function array_sort($array, $on, $order=SORT_ASC){

	    $new_array = array();
	    $sortable_array = array();

	    if (count($array) > 0) {
	        foreach ($array as $k => $v) {
	            if (is_array($v)) {
	                foreach ($v as $k2 => $v2) {
	                    if ($k2 == $on) {
	                        $sortable_array[$k] = $v2;
	                    }
	                }
	            } else {
	                $sortable_array[$k] = $v;
	            }
	        }

	        switch ($order) {
	            case SORT_ASC:
	                asort($sortable_array);
	                break;
	            case SORT_DESC:
	                arsort($sortable_array);
	                break;
	        }

	        foreach ($sortable_array as $k => $v) {
	            $new_array[$k] = $array[$k];
	        }
	    }

	    return $new_array;
	}
}
?>
