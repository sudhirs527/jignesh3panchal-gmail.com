<?php    
class ControllerSnippetsYearprocess extends Controller { 
	private $error = array();

	public function index() {
		$filter_year = '2024';
		$filter_previous_year = '2023';
		$filter_date_start = '2023-01-01';
		$filter_date_end = '2023-12-31';
		$months_array = array(
			'1' => '1',
			'2' => '2',
			'3' => '3',
			'4' => '4',
			'5' => '5',
			'6' => '6',
			'7' => '7',
			'8' => '8',
			'9' => '9',
			'10' => '10',
			'11' => '11',
			'12' => '12',
		);
		$emp_datas = $this->db->query("SELECT `emp_code`, `unit`, `doj`, `department`, `name`, `shift` FROM `oc_employee` WHERE 1=1 ORDER BY `employee_id` ")->rows;
		//$emp_datas = $this->db->query("SELECT `emp_code`, `unit`, `doj`, `department`, `name`, `shift` FROM `oc_employee` WHERE 1=1 AND `emp_code` = '159' ORDER BY `employee_id` ")->rows;
		// echo '<pre>';
		// print_r($emp_datas);
		// exit;

		$current_year = $filter_year;
		$next_year = $filter_year + 1;
		$start = new DateTime($current_year.'-01-01');
		$end   = new DateTime($next_year.'-01-01');
		$interval = DateInterval::createFromDateString('1 day');
		$period = new DatePeriod($start, $interval, $end);
		$week_array = array();
		foreach ($period as $dt) {
		    if ($dt->format('N') == 6 || $dt->format('N') == 7) {
		    	$week_array[$dt->format('Y-m-d')]['date'] = $dt->format('Y-m-d');
		    	$week_array[$dt->format('Y-m-d')]['day'] = $dt->format('j');
		    	$week_array[$dt->format('Y-m-d')]['month'] = $dt->format('n');
		    	$week_array[$dt->format('Y-m-d')]['year'] = $dt->format('Y');
		    }
		}
		// echo '<pre>';
		// print_r($week_array);
		// exit;
		$year_start_date = $filter_year.'-01-01';
		foreach($emp_datas as $ekey => $evalue){
			
			// $shift_id = 'S_'.$evalue['shift'];
			// foreach ($months_array as $key => $value) {
			// 	$is_exist = $this->db->query("SELECT `emp_code`, `id` FROM `oc_shift_schedule` WHERE `emp_code` = '".$evalue['emp_code']."' AND `month` = '".$key."' AND `year` = '".$filter_year."' ");
			// 	if($is_exist->num_rows == 0){
			// 		$insert = "INSERT INTO `oc_shift_schedule` SET 
			// 			`emp_code` = '".$evalue['emp_code']."',
			// 			`1` = '".$shift_id."',
			// 			`2` = '".$shift_id."',
			// 			`3` = '".$shift_id."',
			// 			`4` = '".$shift_id."',
			// 			`5` = '".$shift_id."',
			// 			`6` = '".$shift_id."',
			// 			`7` = '".$shift_id."',
			// 			`8` = '".$shift_id."',
			// 			`9` = '".$shift_id."',
			// 			`10` = '".$shift_id."',
			// 			`11` = '".$shift_id."',
			// 			`12` = '".$shift_id."',
			// 			`13` = '".$shift_id."',
			// 			`14` = '".$shift_id."',
			// 			`15` = '".$shift_id."',
			// 			`16` = '".$shift_id."',
			// 			`17` = '".$shift_id."',
			// 			`18` = '".$shift_id."',
			// 			`19` = '".$shift_id."',
			// 			`20` = '".$shift_id."',
			// 			`21` = '".$shift_id."',
			// 			`22` = '".$shift_id."',
			// 			`23` = '".$shift_id."',
			// 			`24` = '".$shift_id."',
			// 			`25` = '".$shift_id."',
			// 			`26` = '".$shift_id."',
			// 			`27` = '".$shift_id."',
			// 			`28` = '".$shift_id."',
			// 			`29` = '".$shift_id."',
			// 			`30` = '".$shift_id."',
			// 			`31` = '".$shift_id."', 
			// 			`month` = '".$key."',
			// 			`year` = '".$filter_year."',
			// 			`status` = '1' ,
			// 			`unit` = '".$evalue['unit']."' "; 
			// 			// echo $insert1;
			// 			// echo '<br />';
			// 		$this->db->query($insert);				
			// 	} else {
			// 		$update = "UPDATE `oc_shift_schedule` SET 
			// 			`emp_code` = '".$evalue['emp_code']."',
			// 			`1` = '".$shift_id."',
			// 			`2` = '".$shift_id."',
			// 			`3` = '".$shift_id."',
			// 			`4` = '".$shift_id."',
			// 			`5` = '".$shift_id."',
			// 			`6` = '".$shift_id."',
			// 			`7` = '".$shift_id."',
			// 			`8` = '".$shift_id."',
			// 			`9` = '".$shift_id."',
			// 			`10` = '".$shift_id."',
			// 			`11` = '".$shift_id."',
			// 			`12` = '".$shift_id."',
			// 			`13` = '".$shift_id."',
			// 			`14` = '".$shift_id."',
			// 			`15` = '".$shift_id."',
			// 			`16` = '".$shift_id."',
			// 			`17` = '".$shift_id."',
			// 			`18` = '".$shift_id."',
			// 			`19` = '".$shift_id."',
			// 			`20` = '".$shift_id."',
			// 			`21` = '".$shift_id."',
			// 			`22` = '".$shift_id."',
			// 			`23` = '".$shift_id."',
			// 			`24` = '".$shift_id."',
			// 			`25` = '".$shift_id."',
			// 			`26` = '".$shift_id."',
			// 			`27` = '".$shift_id."',
			// 			`28` = '".$shift_id."',
			// 			`29` = '".$shift_id."',
			// 			`30` = '".$shift_id."',
			// 			`31` = '".$shift_id."', 
			// 			`month` = '".$key."',
			// 			`year` = '".$filter_year."',
			// 			`status` = '1' ,
			// 			`unit` = '".$evalue['unit']."' 
			// 			WHERE `id` = '".$is_exist->row['id']."' ";
			// 			// echo $insert1;
			// 			// echo '<br />';
			// 		$this->db->query($update);
			// 	}
			// }
			// $weekly_off = 'W_1_'.$evalue['shift'];
			// foreach ($week_array as $wkey => $wvalue) {
			// 	$sql = "UPDATE `oc_shift_schedule` SET `".$wvalue['day']."` = '".$weekly_off."' WHERE `month` = '".$wvalue['month']."' AND `year` = '".$wvalue['year']."' AND `emp_code` = '".$evalue['emp_code']."' ";	
	  //       	$this->db->query($sql);
			// }
			// if($evalue['doj'] == '0000-00-00'){
			// 	$doj_compare = $year_start_date;
			// } else {
			// 	$doj_compare = $evalue['doj'];
			// }	
			
			/*
			$holiday_sql = "SELECT * FROM `oc_holiday` WHERE `date` >= '".$doj_compare."' AND `date` >= '".$year_start_date."' ";
			$holiday_datas = $this->db->query($holiday_sql);
			if($holiday_datas->num_rows > 0){
				$holiday_data = $holiday_datas->row;
				$location_value = '';
				if($evalue['unit'] == 'AdeccoofficeboysAhmedabad'){
					$location_value = $holiday_data['department_adeccoofficeboysahmedabad'];
				} elseif($evalue['unit'] == 'AdeccoofficeboysBangalore'){
					$location_value = $holiday_data['department_adeccoofficeboysbangalore'];
				} elseif($evalue['unit'] == 'AdeccoofficeboysChennai'){
					$location_value = $holiday_data['department_adeccoofficeboyschennai'];
				} elseif($evalue['unit'] == 'AdeccoofficeboysDelhi'){
					$location_value = $holiday_data['department_adeccoofficeboysdelhi'];
				} elseif($evalue['unit'] == 'AdeccoofficeboysMumbai'){
					$location_value = $holiday_data['department_adeccoofficeboysmumbai'];
				} elseif($evalue['unit'] == 'AdeccoofficeboysPune'){
					$location_value = $holiday_data['department_adeccoofficeboyspune'];
				} elseif($evalue['unit'] == 'Ahmedabad'){
					$location_value = $holiday_data['department_ahmedabad'];
				} elseif($evalue['unit'] == 'Bangalore'){
					$location_value = $holiday_data['department_bangalore'];
				} elseif($evalue['unit'] == 'Chennai'){
					$location_value = $holiday_data['department_chennai'];
				} elseif($evalue['unit'] == 'Coimbatore'){
					$location_value = $holiday_data['department_coimbatore'];
				} elseif($evalue['unit'] == 'Delhi'){
					$location_value = $holiday_data['department_delhi'];
				} elseif($evalue['unit'] == 'MonitronSecurity'){
					$location_value = $holiday_data['department_monitronsecurity'];
				} elseif($evalue['unit'] == 'Mumbai'){
					$location_value = $holiday_data['department_mumbai'];
				} elseif($evalue['unit'] == 'Pune'){
					$location_value = $holiday_data['department_pune'];
				} elseif($evalue['unit'] == 'SaiSiddhiServices'){
					$location_value = $holiday_data['department_saisiddhiservices'];
				}
				$location_value_1 = unserialize($location_value);
				$department = html_entity_decode(strtolower(trim($evalue['department'])));
				if(in_array($department, $location_value_1)){
					$date = $holiday_data['date'];
					$month = date('n', strtotime($date));
					$year = date('Y', strtotime($date));
					$day = date('j', strtotime($date));
					$holiday_string = 'H_'.$hvalue['holiday_id'].'_1';
					$update_shift_schedule = "UPDATE `oc_shift_schedule` SET `".$day."` = '".$holiday_string."' WHERE `month` = '".$month."' AND `year` = '".$year."' AND `emp_code` = '".$evalue['emp_code']."' ";
					$this->db->query($update_shift_schedule);
				}
			}
			*/
			$is_exist = $this->db->query("SELECT `emp_id`, `leave_id` FROM `oc_leave` WHERE `emp_id` = '".$evalue['emp_code']."' AND `year` = '".$filter_year."' ");
			if($is_exist->num_rows == 0){
				$update_sql = "UPDATE `oc_leave` SET `close_status` = '1' WHERE `emp_id` = '".$evalue['emp_code']."' ";
				$this->db->query($update_sql);
				$previous_is_exists = $this->db->query("SELECT * FROM `oc_leave` WHERE `emp_id` = '".$evalue['emp_code']."' AND `year` = '".$filter_previous_year."' ");
				// if($previous_is_exists->num_rows > 0){
				// 	$previous_is_exist = $previous_is_exists->row;
				// 	$pl_acc = $previous_is_exist['pl_acc'];
				// 	$cl_acc = $previous_is_exist['cl_acc'];
				// 	$sl_acc = $previous_is_exist['sl_acc'];
				// 	$bl_acc = $previous_is_exist['bl_acc'];
				// 	$lwp_acc = $previous_is_exist['lwp_acc'];
				// 	$ml_acc = $previous_is_exist['ml_acc'];
				// 	$mal_acc = $previous_is_exist['mal_acc'];
				// 	$pal_acc = $previous_is_exist['pal_acc'];
				// 	$covid_acc = $previous_is_exist['covid_acc'];
				// } else {
					$pl_acc = 0;
					$cl_acc = 0;
					$sl_acc = 0;
					$bl_acc = 0;
					$lwp_acc = 0;
					$ml_acc = 0;
					$mal_acc = 0;
					$pal_acc = 0;
					$covid_acc = 0;
				// }
				$current_year = $filter_year;
				$start_date = $filter_date_start;
				$end_date = $filter_date_end;
				
				// $pl_used = $this->get_bal($evalue['emp_code'], $filter_date_start, $filter_date_end, 'PL');
				// $pl_bal = $pl_acc - $pl_used;

				// $cl_used = $this->get_bal($evalue['emp_code'], $filter_date_start, $filter_date_end, 'CL');
				// $cl_bal = $cl_acc - $cl_used;

				// $sl_used = $this->get_bal($evalue['emp_code'], $filter_date_start, $filter_date_end, 'SL');
				// $sl_bal = $sl_acc - $sl_used;

				// $bl_used = $this->get_bal($evalue['emp_code'], $filter_date_start, $filter_date_end, 'BL');
				// $bl_bal = $bl_acc - $bl_used;

				// $lwp_used = $this->get_bal($evalue['emp_code'], $filter_date_start, $filter_date_end, 'LWP');
				// $lwp_bal = $lwp_acc - $lwp_used;

				// $ml_used = $this->get_bal($evalue['emp_code'], $filter_date_start, $filter_date_end, 'ML');
				// $ml_bal = $ml_acc - $ml_used;

				// $mal_used = $this->get_bal($evalue['emp_code'], $filter_date_start, $filter_date_end, 'MAL');
				// $mal_bal = $mal_acc - $mal_used;

				// $pal_used = $this->get_bal($evalue['emp_code'], $filter_date_start, $filter_date_end, 'PAL');
				// $pal_bal = $pal_acc - $pal_used;

				// $covid_used = $this->get_bal($evalue['emp_code'], $filter_date_start, $filter_date_end, 'Covid19');
				// $covid_bal = $covid_acc - $covid_used;

				$pl_bal = '';
				$cl_bal = '';
				$sl_bal = '';
				$bl_bal = '';
				$lwp_bal = '';
				$ml_bal = '';
				$mal_bal = '';
				$pal_bal = '';
				$covid_bal = '';

				$insert2 = "INSERT INTO `oc_leave` SET 
							`emp_id` = '".$evalue['emp_code']."', 
							`emp_name` = '".$evalue['name']."', 
							`emp_doj` = '".$evalue['doj']."', 
							`year` = '".$filter_year."',
							`pl_acc` = '".$pl_bal."',
							`cl_acc` = '".$cl_bal."',
							`sl_acc` = '".$sl_bal."',
							`bl_acc` = '".$bl_bal."',
							`lwp_acc` = '".$lwp_bal."',
							`ml_acc` = '".$ml_bal."',
							`mal_acc` = '".$mal_bal."',
							`pal_acc` = '".$pal_bal."',
							`covid_acc` = '".$covid_bal."',
							`close_status` = '0' "; 
				//echo $insert2;exit;
				$this->db->query($insert2);
			}
			//echo 'out';exit;
		}
		echo 'Done';
		exit;
	}

	public function get_bal($emp_code, $start_date, $end_date, $type){
		$sql = "SELECT COUNT(*) as `bal_p`, `encash` FROM `oc_leave_transaction_temp` WHERE `emp_id` = '" . $emp_code . "' AND `leave_amount` = '' AND `leave_type`= '".$type."' AND `a_status` = '1' AND `p_status` = '1' AND date(`date`) >= '".$start_date."' AND date(`date`) <= '".$end_date."' ";
		$bal1_datass = $this->db->query($sql);
		$pl_bal1 = 0;
		if($bal1_datass->num_rows > 0){
			$bal1_datas = $bal1_datass->row['bal_p'];
			if($bal1_datas != ''){
				$pl_bal1 = $bal1_datas;
			} else {
				$pl_bal1 = 0;
			}
		}
		
		$sql2 = "SELECT SUM(`leave_amount`) as leave_amount FROM `oc_leave_transaction_temp` WHERE `emp_id` = '" . $emp_code . "' AND `days` = '' AND `leave_type`= '".$type."' AND `a_status` = '1' AND `p_status` = '1' AND date(`date`) >= '".$start_date."' AND date(`date`) <= '".$end_date."' ";
		$bal2_datass = $this->db->query($sql2);
		$pl_bal2 = 0;
		if($bal2_datass->num_rows > 0){
			$bal2_datas = $bal2_datass->row['leave_amount'];
			if($bal2_datas != ''){
				$pl_bal2 = $bal2_datas;
			} else {
				$pl_bal2 = 0;
			}
		}
		$pl_bal = $pl_bal1 + $pl_bal2;
		return $pl_bal;
	}

	public function GetDays($sStartDate, $sEndDate){  
		// Firstly, format the provided dates.  
		// This function works best with YYYY-MM-DD  
		// but other date formats will work thanks  
		// to strtotime().  
		$sStartDate = date("Y-m-d", strtotime($sStartDate));  
		$sEndDate = date("Y-m-d", strtotime($sEndDate));  
		// Start the variable off with the start date  
		$aDays[] = $sStartDate;  
		// Set a 'temp' variable, sCurrentDate, with  
		// the start date - before beginning the loop  
		$sCurrentDate = $sStartDate;  
		// While the current date is less than the end date  
		while($sCurrentDate < $sEndDate){  
		// Add a day to the current date  
		$sCurrentDate = date("Y-m-d", strtotime("+1 day", strtotime($sCurrentDate)));  
			// Add this new day to the aDays array  
		$aDays[] = $sCurrentDate;  
		}
		// Once the loop has finished, return the  
		// array of days.  
		return $aDays;  
	}

	public function array_sort($array, $on, $order=SORT_ASC){

	    $new_array = array();
	    $sortable_array = array();

	    if (count($array) > 0) {
	        foreach ($array as $k => $v) {
	            if (is_array($v)) {
	                foreach ($v as $k2 => $v2) {
	                    if ($k2 == $on) {
	                        $sortable_array[$k] = $v2;
	                    }
	                }
	            } else {
	                $sortable_array[$k] = $v;
	            }
	        }

	        switch ($order) {
	            case SORT_ASC:
	                asort($sortable_array);
	                break;
	            case SORT_DESC:
	                arsort($sortable_array);
	                break;
	        }

	        foreach ($sortable_array as $k => $v) {
	            $new_array[$k] = $array[$k];
	        }
	    }

	    return $new_array;
	}
}
?>