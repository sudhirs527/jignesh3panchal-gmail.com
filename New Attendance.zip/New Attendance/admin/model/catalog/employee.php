<?php
class ModelCatalogEmployee extends Model {
	public function addemployee($data) {
		$data['dept_head_list'] = array();
		$this->db->query("INSERT INTO " . DB_PREFIX . "employee SET 
							name = '" . $this->db->escape($data['name']) . "', 
							card_number = '" . $this->db->escape($data['emp_code']) . "', 
							emp_code = '" . $this->db->escape($data['emp_code']) . "', 
							gender = '" . $this->db->escape($data['gender']) . "', 
							designation = '" . $this->db->escape(html_entity_decode($data['designation'])) . "', 
							designation_id = '" . $this->db->escape($data['designation_id']) . "',
							department = '" . $this->db->escape(html_entity_decode($data['department'])) . "', 
							department_id = '" . $this->db->escape($data['department_id']) . "',
							grade = '" . $this->db->escape($data['grade']) . "', 
							grade_id = '" . $this->db->escape($data['grade_id']) . "',
							dob = '" . $this->db->escape($data['dob']) . "', 
							doj = '" . $this->db->escape($data['doj']) . "',  
							doc = '" . $this->db->escape($data['doc']) . "',  
							email = '" . $this->db->escape($data['email']) . "',
							dol = '" . $this->db->escape($data['dol']) . "',  
							unit = '" . $this->db->escape($data['unit']) . "',  
							shift_type = 'F',  
							is_dept = '" . $this->db->escape($data['is_dept']) . "',
							dept_head_list = '" . $this->db->escape(implode(',', $data['dept_head_list'])) . "',
							status = '" . $this->db->escape($data['status']) . "',
							reporting_to = '".$this->db->escape($data['reporting_to'])."',
							reporting_to_name = '".$this->db->escape($data['reporting_to_name'])."'
							 ");
		$employee_id = $this->db->getLastId();
		$emp_code = $data['emp_code'];
		$user_name = $emp_code;
		$salt = substr(md5(uniqid(rand(), true)), 0, 9);
		$password = sha1($salt . sha1($salt . sha1($emp_code)));
		$sql = "UPDATE `oc_employee` set `username` = '".$this->db->escape($emp_code)."', `password` = '".$this->db->escape($password)."', `salt` = '".$this->db->escape($salt)."', `is_set` = '0', `user_group_id` = '11' WHERE `employee_id` = '".$employee_id."' ";
		$this->db->query($sql);

		$months_array = array(
			'1' => '1',
			'2' => '2',
			'3' => '3',
			'4' => '4',
			'5' => '5',
			'6' => '6',
			'7' => '7',
			'8' => '8',
			'9' => '9',
			'10' => '10',
			'11' => '11',
			'12' => '12',
		);
		
		$emp_codes = $this->db->query("SELECT `emp_code` FROM `oc_employee` WHERE `unit` = '".$data['unit']."' AND `emp_code` <> '".$data['emp_code']."' LIMIT 1");
		if($emp_codes->num_rows > 0){
			$emp_codes = $emp_codes->row;
			$emp_code = $emp_codes['emp_code'];
		
			$exist_schedules = $this->db->query("SELECT * FROM `oc_shift_schedule` WHERE `emp_code` = '".$emp_code."' ");
			if($exist_schedules->num_rows > 0){
				$exist_schedule = $exist_schedules->rows;
				foreach($exist_schedule as $ekeys => $evalues){
					$sql = "INSERT INTO `oc_shift_schedule` SET `1` = '".$evalues['1']."', `2` = '".$evalues['2']."', `3` = '".$evalues['3']."', `4` = '".$evalues['4']."', `5` = '".$evalues['5']."', `6` = '".$evalues['6']."', `7` = '".$evalues['7']."', `8` = '".$evalues['8']."', `9` = '".$evalues['9']."', `10` = '".$evalues['10']."', `11` = '".$evalues['11']."', `12` = '".$evalues['12']."', `13` = '".$evalues['13']."', `14` = '".$evalues['14']."', `15` = '".$evalues['15']."', `16` = '".$evalues['16']."', `17` = '".$evalues['17']."', `18` = '".$evalues['18']."', `19` = '".$evalues['19']."', `20` = '".$evalues['20']."', `21` = '".$evalues['21']."', `22` = '".$evalues['22']."', `23` = '".$evalues['23']."', `24` = '".$evalues['24']."', `25` = '".$evalues['25']."', `26` = '".$evalues['26']."', `27` = '".$evalues['27']."', `28` = '".$evalues['28']."', `29` = '".$evalues['29']."', `30` = '".$evalues['30']."', `31` = '".$evalues['31']."', `emp_code` = '".$data['emp_code']."', `status` = '1', `month` = '".$evalues['month']."', `year` = '".$evalues['year']."', `unit` = '".$evalues['unit']."' "; 
					$this->db->query($sql);
					//echo $sql;exit;
				}
			}
		} else {
			foreach ($months_array as $key => $value) {
				$insert1 = "INSERT INTO `oc_shift_schedule` SET 
					`emp_code` = '".$data['emp_code']."',
					`1` = 'S_1',
					`2` = 'S_1',
					`3` = 'S_1',
					`4` = 'S_1',
					`5` = 'S_1',
					`6` = 'S_1',
					`7` = 'S_1',
					`8` = 'S_1',
					`9` = 'S_1',
					`10` = 'S_1',
					`11` = 'S_1',
					`12` = 'S_1', 
					`13` = 'S_1', 
					`14` = 'S_1', 
					`15` = 'S_1', 
					`16` = 'S_1', 
					`17` = 'S_1', 
					`18` = 'S_1', 
					`19` = 'S_1', 
					`20` = 'S_1', 
					`21` = 'S_1', 
					`22` = 'S_1', 
					`23` = 'S_1', 
					`24` = 'S_1', 
					`25` = 'S_1', 
					`26` = 'S_1', 
					`27` = 'S_1', 
					`28` = 'S_1', 
					`29` = 'S_1', 
					`30` = 'S_1', 
					`31` = 'S_1', 
					`month` = '".$key."',
					`year` = '".date('Y')."',
					`status` = '1' ,
					`unit` = '".$data['unit']."' "; 
					// echo "<pre>";
					// echo $insert1;
				$this->db->query($insert1);
			}
			/*
			$emp_codes = $this->db->query("SELECT `emp_code` FROM `oc_employee` WHERE `unit` = 'Mumbai' LIMIT 1");
			if($emp_codes->num_rows > 0){
				$emp_codes = $emp_codes->row;
				$emp_code = $emp_codes['emp_code'];
			
				$exist_schedules = $this->db->query("SELECT * FROM `oc_shift_schedule` WHERE `emp_code` = '".$emp_code."' ");
				if($exist_schedules->num_rows > 0){
					$exist_schedule = $exist_schedules->rows;
					foreach($exist_schedule as $ekeys => $evalues){
						$sql = "INSERT INTO `oc_shift_schedule` SET `1` = '".$evalues['1']."', `2` = '".$evalues['2']."', `3` = '".$evalues['3']."', `4` = '".$evalues['4']."', `5` = '".$evalues['5']."', `6` = '".$evalues['6']."', `7` = '".$evalues['7']."', `8` = '".$evalues['8']."', `9` = '".$evalues['9']."', `10` = '".$evalues['10']."', `11` = '".$evalues['11']."', `12` = '".$evalues['12']."', `13` = '".$evalues['13']."', `14` = '".$evalues['14']."', `15` = '".$evalues['15']."', `16` = '".$evalues['16']."', `17` = '".$evalues['17']."', `18` = '".$evalues['18']."', `19` = '".$evalues['19']."', `20` = '".$evalues['20']."', `21` = '".$evalues['21']."', `22` = '".$evalues['22']."', `23` = '".$evalues['23']."', `24` = '".$evalues['24']."', `25` = '".$evalues['25']."', `26` = '".$evalues['26']."', `27` = '".$evalues['27']."', `28` = '".$evalues['28']."', `29` = '".$evalues['29']."', `30` = '".$evalues['30']."', `31` = '".$evalues['31']."', `emp_code` = '".$data['emp_code']."', `status` = '1', `month` = '".$evalues['month']."', `year` = '".$evalues['year']."', `unit` = '".$data['unit']."' "; 
						$this->db->query($sql);
						//echo $sql;exit;
					}
				}
			}
			*/	
		}

		$insert2 = "INSERT INTO `oc_leave` SET 
					`emp_id` = '".$data['emp_code']."', 
					`emp_name` = '".$data['name']."', 
					`emp_doj` = '".$data['doj']."', 
					`year` = '".date('Y')."',
					`close_status` = '0' "; 
		$this->db->query($insert2);
	}

	public function editemployee($employee_id, $data) {
		$data['dept_head_list'] = array();
		$this->db->query("UPDATE " . DB_PREFIX . "employee SET 
							name = '" . $this->db->escape($data['name']) . "',
							card_number = '" . $this->db->escape($data['emp_code']) . "', 
							emp_code = '" . $this->db->escape($data['emp_code']) . "', 
							gender = '" . $this->db->escape($data['gender']) . "', 
							designation = '" . $this->db->escape(html_entity_decode($data['designation'])) . "', 
							designation_id = '" . $this->db->escape($data['designation_id']) . "',
							department = '" . $this->db->escape(html_entity_decode($data['department'])) . "', 
							department_id = '" . $this->db->escape($data['department_id']) . "',
							grade = '" . $this->db->escape($data['grade']) . "', 
							grade_id = '" . $this->db->escape($data['grade_id']) . "',
							dob = '" . $this->db->escape($data['dob']) . "', 
							doj = '" . $this->db->escape($data['doj']) . "', 
							doc = '" . $this->db->escape($data['doc']) . "',
							email = '" . $this->db->escape($data['email']) . "',  
							dol = '" . $this->db->escape($data['dol']) . "',  
							unit = '" . $this->db->escape($data['unit']) . "',
							is_dept = '" . $this->db->escape($data['is_dept']) . "',
							dept_head_list = '" . $this->db->escape(implode(',', $data['dept_head_list'])) . "',
							status = '" . $this->db->escape($data['status']) . "',
							reporting_to = '".$this->db->escape($data['reporting_to'])."',
							reporting_to_name = '".$this->db->escape($data['reporting_to_name'])."'
							WHERE employee_id = '" . (int)$employee_id . "'");
		
		if($data['password_reset'] == '1'){
			$emp_code = $data['emp_code'];
			$user_name = $emp_code;
			$salt = substr(md5(uniqid(rand(), true)), 0, 9);
			$password = sha1($salt . sha1($salt . sha1($emp_code)));

			$sql = "UPDATE `oc_employee` set `username` = '".$this->db->escape($emp_code)."', `password` = '".$this->db->escape($password)."', `salt` = '".$this->db->escape($salt)."', `is_set` = '0' WHERE `employee_id` = '".$employee_id."' ";
			$this->db->query($sql);
		}
		if($data['unit'] != $data['hidden_unit']){
			$emp_codes = $this->db->query("SELECT `emp_code` FROM `oc_employee` WHERE `unit` = '".$data['unit']."' AND `emp_code` <> '".$data['emp_code']."' LIMIT 1");
			
			$sql = "DELETE FROM `oc_shift_schedule` WHERE `emp_code` = '".$data['emp_code']."' AND `year` = '".date('Y')."' ";
			$this->db->query($sql);	
			if($emp_codes->num_rows > 0){
				$emp_codes = $emp_codes->row;
				$emp_code = $emp_codes['emp_code'];
				$exist_schedules = $this->db->query("SELECT * FROM `oc_shift_schedule` WHERE `emp_code` = '".$emp_code."' AND `year` = '".date('Y')."' ");
				if($exist_schedules->num_rows > 0){
					$exist_schedule = $exist_schedules->rows;
					foreach($exist_schedule as $ekeys => $evalues){
						$sql = "INSERT INTO `oc_shift_schedule` SET `1` = '".$evalues['1']."', `2` = '".$evalues['2']."', `3` = '".$evalues['3']."', `4` = '".$evalues['4']."', `5` = '".$evalues['5']."', `6` = '".$evalues['6']."', `7` = '".$evalues['7']."', `8` = '".$evalues['8']."', `9` = '".$evalues['9']."', `10` = '".$evalues['10']."', `11` = '".$evalues['11']."', `12` = '".$evalues['12']."', `13` = '".$evalues['13']."', `14` = '".$evalues['14']."', `15` = '".$evalues['15']."', `16` = '".$evalues['16']."', `17` = '".$evalues['17']."', `18` = '".$evalues['18']."', `19` = '".$evalues['19']."', `20` = '".$evalues['20']."', `21` = '".$evalues['21']."', `22` = '".$evalues['22']."', `23` = '".$evalues['23']."', `24` = '".$evalues['24']."', `25` = '".$evalues['25']."', `26` = '".$evalues['26']."', `27` = '".$evalues['27']."', `28` = '".$evalues['28']."', `29` = '".$evalues['29']."', `30` = '".$evalues['30']."', `31` = '".$evalues['31']."', `emp_code` = '".$data['emp_code']."', `status` = '1', `month` = '".$evalues['month']."', `year` = '".$evalues['year']."', `unit` = '".$evalues['unit']."' "; 
						$this->db->query($sql);
						//echo $sql;exit;
					}
				} else {
					foreach ($months_array as $key => $value) {
						$insert1 = "INSERT INTO `oc_shift_schedule` SET 
							`emp_code` = '".$data['emp_code']."',
							`1` = 'S_1',
							`2` = 'S_1',
							`3` = 'S_1',
							`4` = 'S_1',
							`5` = 'S_1',
							`6` = 'S_1',
							`7` = 'S_1',
							`8` = 'S_1',
							`9` = 'S_1',
							`10` = 'S_1',
							`11` = 'S_1',
							`12` = 'S_1', 
							`13` = 'S_1', 
							`14` = 'S_1', 
							`15` = 'S_1', 
							`16` = 'S_1', 
							`17` = 'S_1', 
							`18` = 'S_1', 
							`19` = 'S_1', 
							`20` = 'S_1', 
							`21` = 'S_1', 
							`22` = 'S_1', 
							`23` = 'S_1', 
							`24` = 'S_1', 
							`25` = 'S_1', 
							`26` = 'S_1', 
							`27` = 'S_1', 
							`28` = 'S_1', 
							`29` = 'S_1', 
							`30` = 'S_1', 
							`31` = 'S_1', 
							`month` = '".$key."',
							`year` = '".date('Y')."',
							`status` = '1' ,
							`unit` = '".$data['unit']."' "; 
							// echo "<pre>";
							// echo $insert1;
						$this->db->query($insert1);
					}	
				}
			} else {
				foreach ($months_array as $key => $value) {
					$insert1 = "INSERT INTO `oc_shift_schedule` SET 
						`emp_code` = '".$data['emp_code']."',
						`1` = 'S_1',
						`2` = 'S_1',
						`3` = 'S_1',
						`4` = 'S_1',
						`5` = 'S_1',
						`6` = 'S_1',
						`7` = 'S_1',
						`8` = 'S_1',
						`9` = 'S_1',
						`10` = 'S_1',
						`11` = 'S_1',
						`12` = 'S_1', 
						`13` = 'S_1', 
						`14` = 'S_1', 
						`15` = 'S_1', 
						`16` = 'S_1', 
						`17` = 'S_1', 
						`18` = 'S_1', 
						`19` = 'S_1', 
						`20` = 'S_1', 
						`21` = 'S_1', 
						`22` = 'S_1', 
						`23` = 'S_1', 
						`24` = 'S_1', 
						`25` = 'S_1', 
						`26` = 'S_1', 
						`27` = 'S_1', 
						`28` = 'S_1', 
						`29` = 'S_1', 
						`30` = 'S_1', 
						`31` = 'S_1', 
						`month` = '".$key."',
						`year` = '".date('Y')."',
						`status` = '1' ,
						`unit` = '".$data['unit']."' "; 
						// echo "<pre>";
						// echo $insert1;
					$this->db->query($insert1);
				}
			}
		}
		//$sql = "UPDATE `oc_shift_schedule` set `unit` = '".$this->db->escape($data['unit'])."' WHERE `emp_code` = '".$data['emp_code']."' AND `year` = '".date('Y')."' ";
		//$this->db->query($sql);
		//$this->db->query("UPDATE " . DB_PREFIX . "employee SET name = '" . $this->db->escape($data['name']) . "', grade = '" . $this->db->escape($data['grade']) . "', branch = '" . $this->db->escape($data['branch']) . "', department = '" . $this->db->escape($data['department']) . "', division = '" . $this->db->escape($data['division']) . "', group = '" . $this->db->escape($data['group']) . "', category = '" . $this->db->escape($data['category']) . "', unit = '" . $this->db->escape($data['unit']) . "', designation = '" . $this->db->escape($data['designation']) . "', dob = '" . $this->db->escape($data['dob']) . "', doj = '" . $this->db->escape($data['doj']) . "', doc = '" . $this->db->escape($data['doc']) . "', dol = '" . $this->db->escape($data['dol']) . "', emp_code = '" . $this->db->escape($data['emp_code']) . "', shift = '" . $this->db->escape($data['shift_id']) . "', card_number = '" . $this->db->escape($data['card_number']) . "', status = '" . $this->db->escape($data['status']) . "', daily_punch = '" . $this->db->escape($data['daily_punch']) . "', weekly_off = '" . $this->db->escape($data['weekly_off']) . "', gender = '" . $this->db->escape($data['gender']) . "' WHERE employee_id = '" . (int)$employee_id . "'");
		//echo "UPDATE " . DB_PREFIX . "employee SET card_number = '" . $this->db->escape($data['card_number']) . "', status = '" . $this->db->escape($data['status']) . "', daily_punch = '" . $this->db->escape($data['daily_punch']) . "', weekly_off = '" . $this->db->escape($data['weekly_off']) . "' WHERE employee_id = '" . (int)$employee_id . "'";
		//exit;
		//$this->log->write("UPDATE " . DB_PREFIX . "employee SET name = '" . $this->db->escape($data['name']) . "', location = '" . $this->db->escape($data['location_id']) . "', category = '" . $this->db->escape($data['category_id']) . "', emp_code = '" . $this->db->escape($data['emp_code']) . "', department = '" . $this->db->escape($data['department_id']) . "', shift = '" . $this->db->escape($data['shift_id']) . "', card_number = '" . $this->db->escape($data['card_number']) . "', status = '" . $this->db->escape($data['status']) . "', daily_punch = '" . $this->db->escape($data['daily_punch']) . "', weekly_off = '" . $this->db->escape($data['weekly_off']) . "', gender = '" . $this->db->escape($data['gender']) . "' WHERE employee_id = '" . (int)$employee_id . "'");
		//location = '" . $this->db->escape($data['location_id']) . "', category = '" . $this->db->escape($data['category_id']) . "', 
	}

	public function deleteemployee($employee_id) {
		$emp_code = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "employee WHERE employee_id = '" . (int)$employee_id . "'")->row['emp_code'];
		$this->db->query("DELETE FROM " . DB_PREFIX . "employee WHERE employee_id = '" . (int)$employee_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "shift_schedule WHERE emp_code = '" . (int)$emp_code . "'");
	}	

	public function getemployee($employee_id) {
		$query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "employee WHERE employee_id = '" . (int)$employee_id . "'");
		return $query->row;
	}

	public function getcatname($category_id) {
		$query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "categories WHERE id = '" . (int)$category_id . "'");
		if($query->num_rows > 0){
			return $query->row['name'];
		} else {
			return '';
		}
	}

	public function getdeptname($department_id) {
		$query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "department WHERE id = '" . (int)$department_id . "'");
		if($query->num_rows > 0){
			return $query->row['name'];
		} else {
			return '';
		}
	}

	public function getshiftname($shift_id) {
		$query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "shift WHERE shift_id = '" . (int)$shift_id . "'");
		if($query->num_rows > 0){
			return $query->row['name'];
		} else {
			return '';
		}
	}

	public function getweekname($week_id) {
		$query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "week WHERE week_id = '" . (int)$week_id . "'");
		if($query->num_rows > 0){
			return $query->row['name'];
		} else {
			return '';
		}
	}

	public function getholidayname($holiday_id) {
		$query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "holiday WHERE holiday_id = '" . (int)$holiday_id . "'");
		if($query->num_rows > 0){
			return $query->row['name'];
		} else {
			return '';
		}
	}

	public function getshift_id($emp_code, $day_date, $month, $year) {
		$query = $this->db->query("SELECT `".$day_date."` FROM " . DB_PREFIX . "shift_schedule WHERE emp_code = '" . (int)$emp_code . "' ");
		if($query->num_rows > 0){
			return $query->row[$day_date];
		} else {
			return '';
		}
	}

	public function getlocname($location_id) {
		$query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "location WHERE id = '" . (int)$location_id . "'");
		if($query->num_rows > 0){
			return $query->row['name'];
		} else {
			return '';
		}
	}

	public function getemployees($data = array()) {
		$sql = "SELECT * FROM " . DB_PREFIX . "employee WHERE 1=1 ";

		if (!empty($data['filter_name'])) {
			$data['filter_name'] = html_entity_decode($data['filter_name']);
			$sql .= " AND LOWER(name) LIKE '%" . $this->db->escape(strtolower($data['filter_name'])) . "%'";
			//$sql .= " AND LOWER(name) REGEXP '^" . $this->db->escape(strtolower($data['filter_name'])) . "'";
		}

		if (isset($data['filter_emp_code']) && !empty($data['filter_emp_code'])) {
			$filter_emp_code = $data['filter_emp_code'];
			$sql .= " AND `reporting_to` = '" . $this->db->escape($filter_emp_code) . "' ";
		}

		if (isset($data['filter_name_id']) && !empty($data['filter_name_id'])) {
			$sql .= " AND emp_code = '" . $data['filter_name_id'] . "' ";
		}

		if (isset($data['filter_code']) && !empty($data['filter_code'])) {
			$sql .= " AND `emp_code` = '" . $this->db->escape($data['filter_code']) . "' ";
		}

		if (isset($data['filter_department']) && !empty($data['filter_department'])) {
			$sql .= " AND LOWER(department) = '" . $this->db->escape(strtolower($data['filter_department'])) . "' ";
		}

		if (isset($data['filter_departments']) && !empty($data['filter_departments'])) {
			$sql .= " AND LOWER(`department`) IN (" . strtolower($data['filter_departments']) . ") ";
		}

		if (isset($data['filter_unit']) && !empty($data['filter_unit'])) {
			$sql .= " AND LOWER(unit) = '" . $this->db->escape(strtolower($data['filter_unit'])) . "' ";
		}

		if (isset($data['filter_shift_type'])) {
			$sql .= " AND shift_type = 'R' ";
			//$sql .= " AND LOWER(name) REGEXP '^" . $this->db->escape(strtolower($data['filter_name'])) . "'";
		}

		$sort_data = array(
			'name',
		);	

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];	
		} else {
			$sql .= " ORDER BY name";	
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}					

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}	

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}	
		//$this->log->write($sql);			
		//echo $sql;exit;
		$query = $this->db->query($sql);

		return $query->rows;
	}

	public function getemployees_dash($data = array()) {
		$sql = "SELECT * FROM " . DB_PREFIX . "employee WHERE 1=1 and status = '1'";

		if (!empty($data['filter_name'])) {
			$data['filter_name'] = html_entity_decode($data['filter_name']);
			$sql .= " AND LOWER(name) LIKE '%" . $this->db->escape(strtolower($data['filter_name'])) . "%'";
			//$sql .= " AND LOWER(name) REGEXP '^" . $this->db->escape(strtolower($data['filter_name'])) . "'";
		}

		if (isset($data['filter_emp_code']) && !empty($data['filter_emp_code'])) {
			$filter_emp_code = $data['filter_emp_code'];
			$sql .= " AND `reporting_to` = '" . $this->db->escape($filter_emp_code) . "' ";
		}

		if (isset($data['filter_name_id']) && !empty($data['filter_name_id'])) {
			$sql .= " AND emp_code = '" . $data['filter_name_id'] . "' ";
		}

		if (isset($data['filter_code']) && !empty($data['filter_code'])) {
			$sql .= " AND `emp_code` = '" . $this->db->escape($data['filter_code']) . "' ";
		}

		if (isset($data['filter_department']) && !empty($data['filter_department'])) {
			$sql .= " AND LOWER(department) = '" . $this->db->escape(strtolower($data['filter_department'])) . "' ";
		}

		if (isset($data['filter_departments']) && !empty($data['filter_departments'])) {
			$sql .= " AND LOWER(`department`) IN (" . strtolower($data['filter_departments']) . ") ";
		}

		if (isset($data['filter_unit']) && !empty($data['filter_unit'])) {
			$sql .= " AND LOWER(unit) = '" . $this->db->escape(strtolower($data['filter_unit'])) . "' ";
		}

		if (isset($data['filter_shift_type'])) {
			$sql .= " AND shift_type = 'R' ";
			//$sql .= " AND LOWER(name) REGEXP '^" . $this->db->escape(strtolower($data['filter_name'])) . "'";
		}

		$sort_data = array(
			'name',
		);	

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];	
		} else {
			$sql .= " ORDER BY name";	
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}					

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}	

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}	
		//$this->log->write($sql);			
		//echo $sql;exit;
		$query = $this->db->query($sql);

		return $query->rows;
	}

	public function getTotalemployees($data = array()) {
		$sql = "SELECT COUNT(*) AS total FROM " . DB_PREFIX . "employee WHERE 1=1 ";
		
		if (!empty($data['filter_name'])) {
			$sql .= " AND LOWER(name) LIKE '%" . $this->db->escape(strtolower($data['filter_name'])) . "%'";
		}

		if (isset($data['filter_code']) && !empty($data['filter_code'])) {
			$sql .= " AND `emp_code` = '" . $this->db->escape($data['filter_code']) . "' ";
		}

		if (isset($data['filter_emp_code']) && !empty($data['filter_emp_code'])) {
			$filter_emp_code = $data['filter_emp_code'];
			$sql .= " AND `reporting_to` = '" . $this->db->escape($filter_emp_code) . "' ";
		}

		if (isset($data['filter_department']) && !empty($data['filter_department'])) {
			$sql .= " AND LOWER(department) = '" . $this->db->escape(strtolower($data['filter_department'])) . "' ";
		}

		if (isset($data['filter_departments']) && !empty($data['filter_departments'])) {
			$sql .= " AND LOWER(`department`) IN (" . strtolower($data['filter_departments']) . ") ";
		}

		if (isset($data['filter_unit']) && !empty($data['filter_unit'])) {
			$sql .= " AND LOWER(unit) = '" . $this->db->escape(strtolower($data['filter_unit'])) . "' ";
		}

		if (isset($data['filter_shift_type'])) {
			$sql .= " AND shift_type = 'R' ";
			//$sql .= " AND LOWER(name) REGEXP '^" . $this->db->escape(strtolower($data['filter_name'])) . "'";
		}

		$query = $this->db->query($sql);
		return $query->row['total'];
	}

	public function getTotalemployees_dash($data = array()) {
		$sql = "SELECT COUNT(*) AS total FROM " . DB_PREFIX . "employee WHERE 1=1 and status = '1'";
		
		if (!empty($data['filter_name'])) {
			$sql .= " AND LOWER(name) LIKE '%" . $this->db->escape(strtolower($data['filter_name'])) . "%'";
		}

		if (isset($data['filter_code']) && !empty($data['filter_code'])) {
			$sql .= " AND `emp_code` = '" . $this->db->escape($data['filter_code']) . "' ";
		}

		if (isset($data['filter_emp_code']) && !empty($data['filter_emp_code'])) {
			$filter_emp_code = $data['filter_emp_code'];
			$sql .= " AND `reporting_to` = '" . $this->db->escape($filter_emp_code) . "' ";
		}

		if (isset($data['filter_department']) && !empty($data['filter_department'])) {
			$sql .= " AND LOWER(department) = '" . $this->db->escape(strtolower($data['filter_department'])) . "' ";
		}

		if (isset($data['filter_departments']) && !empty($data['filter_departments'])) {
			$sql .= " AND LOWER(`department`) IN (" . strtolower($data['filter_departments']) . ") ";
		}

		if (isset($data['filter_unit']) && !empty($data['filter_unit'])) {
			$sql .= " AND LOWER(unit) = '" . $this->db->escape(strtolower($data['filter_unit'])) . "' ";
		}

		if (isset($data['filter_shift_type'])) {
			$sql .= " AND shift_type = 'R' ";
			//$sql .= " AND LOWER(name) REGEXP '^" . $this->db->escape(strtolower($data['filter_name'])) . "'";
		}

		$query = $this->db->query($sql);
		return $query->row['total'];
	}

	public function getActiveEmployee() {
		$sql = "SELECT `emp_code`, `name`, `doj`, `grade`, `group` FROM ".DB_PREFIX."employee WHERE `status` = '1'";	
		$query = $this->db->query($sql);
		return $query->rows;	
	}
}
?>