<?php
session_start();
//unset($_SESSION['local']);
// if(!isset($_SESSION['local'])){
// 	//$response = @file_get_contents('http://125.99.122.186/attendance/admin/test.php');
// 	// $url = 'http://192.168.0.75/attendance/admin/test.php?get=1';
// 	// $curlInit = curl_init($url);
// 	// curl_setopt($curlInit,CURLOPT_CONNECTTIMEOUT,1);
// 	// curl_setopt($curlInit,CURLOPT_TIMEOUT,1);
// 	// curl_setopt($curlInit,CURLOPT_HEADER,true);
// 	// curl_setopt($curlInit,CURLOPT_NOBODY,true);
// 	// curl_setopt($curlInit,CURLOPT_RETURNTRANSFER,true);
// 	// //get answer
// 	// $response = curl_exec($curlInit);
// 	//curl_close($curlInit);
// 	if($_SERVER['HTTP_HOST'] == '125.99.122.186'){
// 		$response = false;
// 	} elseif($_SERVER['HTTP_HOST'] == '192.168.0.75') {
// 		$response = true;
// 	} else {
// 		$response = false;
// 	}
// } else {
// 	if($_SESSION['local'] == 1){
// 		$response = true;
// 	} else {
// 		$response = false;
// 	}
// }

date_default_timezone_set("Asia/Kolkata");
// HTTP
// if ($response){
// 	$_SESSION['local'] = 1;
// 	define('HTTP_SERVER', 'http://192.168.0.75/attendance/admin/');
// 	define('HTTP_CATALOG', 'http://192.168.0.75/attendance/');

// 	// HTTPS
// 	define('HTTPS_SERVER', 'http://192.168.0.75/attendance/admin/');
// 	define('HTTPS_CATALOG', 'http://192.168.0.75/attendance/');

// 	// DIR
// 	define('DIR_APPLICATION', '/usr/share/nginx/html/attendance/admin/');
// 	define('DIR_SYSTEM', '/usr/share/nginx/html/attendance/system/');
// 	define('DIR_DATABASE', '/usr/share/nginx/html/attendance/system/database/');
// 	define('DIR_LANGUAGE', '/usr/share/nginx/html/attendance/admin/language/');
// 	define('DIR_TEMPLATE', '/usr/share/nginx/html/attendance/admin/view/template/');
// 	define('DIR_CONFIG', '/usr/share/nginx/html/attendance/system/config/');
// 	define('DIR_IMAGE', '/usr/share/nginx/html/attendance/image/');
// 	define('DIR_CACHE', '/usr/share/nginx/html/attendance/system/cache/');
// 	//define('DIR_DOWNLOAD', '/usr/share/nginx/html/attendance/download/');
// 	define('DIR_DOWNLOAD', 'http://192.168.0.205/attendance/attdndat/');
// 	define('DIR_LOGS', '/usr/share/nginx/html/attendance/system/logs/');
// 	define('DIR_CATALOG', '/usr/share/nginx/html/attendance/catalog/');

// 	// DB
// 	define('DB_DRIVER', 'mysqli');
// 	define('DB_HOSTNAME', 'localhost');
// 	define('DB_USERNAME', 'root');
// 	define('DB_PASSWORD', 'rwitc');
// 	define('DB_DATABASE', 'db_attendance');
// 	define('DB_PREFIX', 'oc_');
// } else {
	//$_SESSION['local'] = 0;
define('HTTP_SERVER', 'http://172.16.10.58:80/attendance/admin/');
define('HTTP_CATALOG', 'http://172.16.10.58:80/attendance/');

// HTTPS
define('HTTPS_SERVER', 'http://172.16.10.58:80/attendance/admin/');
define('HTTPS_CATALOG', 'http://172.16.10.58:80/attendance/');

// DIR
define('DIR_APPLICATION', 'C:\xampp\htdocs\attendance/admin/');
define('DIR_SYSTEM', 'C:\xampp\htdocs\attendance/system/');
define('DIR_DATABASE', 'C:\xampp\htdocs\attendance/system/database/');
define('DIR_LANGUAGE', 'C:\xampp\htdocs\attendance/admin/language/');
define('DIR_TEMPLATE', 'C:\xampp\htdocs\attendance/admin/view/template/');
define('DIR_CONFIG', 'C:\xampp\htdocs\attendance/system/config/');
define('DIR_IMAGE', 'C:\xampp\htdocs\attendance/image/');
define('DIR_CACHE', 'C:\xampp\htdocs\attendance/system/cache/');
define('DIR_DOWNLOAD', 'C:\xampp\htdocs\attendance/download/');
define('DIR_LOGS', 'C:\xampp\htdocs\attendance/system/logs/');
define('DIR_CATALOG', 'C:\xampp\htdocs\attendance/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'db_attendance_blank');
define('DB_PREFIX', 'oc_');
//}
?>