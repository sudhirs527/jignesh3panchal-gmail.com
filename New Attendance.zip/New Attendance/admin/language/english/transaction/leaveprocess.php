<?php
// Heading
$_['heading_title']     = 'Leave Processing';

// Entry
$_['entry_date']  		= 'Date:';
?>