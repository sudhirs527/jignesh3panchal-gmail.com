<?php
// Heading
$_['heading_title']     = 'Day Closing';

// Entry
$_['entry_date']  		= 'Date:';
?>