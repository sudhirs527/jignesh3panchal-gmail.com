<?php
// Heading
$_['heading_title']      = 'Request Approval Form';

// Text
$_['text_success']       = 'Success: You have inserted a Entry!';

?>