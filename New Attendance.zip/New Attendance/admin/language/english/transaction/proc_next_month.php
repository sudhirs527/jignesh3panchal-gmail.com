<?php
// Heading
$_['heading_title']      = 'Close Month';
?>
