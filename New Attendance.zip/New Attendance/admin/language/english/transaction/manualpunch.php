<?php
// Heading
$_['heading_title']      = 'Manual Punch';

// Text
$_['text_success']       = 'Success: You have inserted a Entry!';

?>