<?php
// Heading
$_['heading_title']      = 'Self Request Form';

// Text
$_['text_success']       = 'Success: You have inserted a Entry!';

?>