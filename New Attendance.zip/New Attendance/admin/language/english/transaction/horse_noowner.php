<?php
// Heading
$_['heading_title']     = 'Treated Horse Without Owner';

// Text

// Column
$_['column_horse_name']   = 'Horse Name';
$_['column_trainer']      = 'Trainer';
$_['column_action']      = 'Action';

$_['text_edit'] = 'Edit';

$_['button_export'] = 'Export';
// Entry
?>