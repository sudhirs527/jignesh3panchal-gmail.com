<?php
// Heading
$_['heading_title']      = 'Leave';

// Text
$_['text_success']       = 'Success: You have inserted a Entry!';

?>