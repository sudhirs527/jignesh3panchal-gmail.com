<?php
// Heading
$_['heading_title']      = 'Holiday';

// Text
$_['text_success']       = 'Success: You have modified Holiday!';

?>
