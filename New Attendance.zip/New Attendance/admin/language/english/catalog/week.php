<?php
// Heading
$_['heading_title']      = 'Weekly Off';

// Text
$_['text_success']       = 'Success: You have modified Weekly Off!';

?>
