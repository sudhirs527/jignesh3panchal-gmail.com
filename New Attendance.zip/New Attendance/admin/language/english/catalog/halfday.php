<?php
// Heading
$_['heading_title']      = 'Half Day';

// Text
$_['text_success']       = 'Success: You have modified Half Day!';

?>
