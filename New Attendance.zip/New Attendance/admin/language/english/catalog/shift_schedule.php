<?php
// Heading
$_['heading_title']      = 'Shift Schedule';

// Text
$_['text_success']       = 'Success: You have modified Shift Schedule!';

?>
