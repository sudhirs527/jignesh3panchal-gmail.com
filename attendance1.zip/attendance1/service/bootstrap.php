<?php
define('DIR_APPLICATION', 'C:\xampp\htdocs\attendance/admin/');
define('DIR_SYSTEM', 'C:\xampp\htdocs\attendance/system/');
define('DIR_DATABASE', 'C:\xampp\htdocs\attendance/system/database/');
define('DIR_LANGUAGE', 'C:\xampp\htdocs\attendance/admin/language/');
define('DIR_TEMPLATE', 'C:\xampp\htdocs\attendance/admin/view/template/');
define('DIR_CONFIG', 'C:\xampp\htdocs\attendance/system/config/');
define('DIR_IMAGE', 'C:\xampp\htdocs\attendance/image/');
define('DIR_CACHE', 'C:\xampp\htdocs\attendance/system/cache/');
define('DIR_DOWNLOAD', 'C:\xampp\htdocs\attendance/download/');
define('DIR_LOGS', 'C:\xampp\htdocs\attendance/system/logs/');
define('DIR_CATALOG', 'C:\xampp\htdocs\attendance/catalog/');
// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'db_attendance_blank');
define('DB_PREFIX', 'oc_');
//require_once('../admin/config.php');
require_once(DIR_SYSTEM . 'engine/registry.php');
require_once(DIR_SYSTEM . "library/db.php");
require_once(DIR_SYSTEM . 'engine/model.php');
require_once(DIR_SYSTEM . "engine/loader.php");
require_once(DIR_SYSTEM . "library/log.php");

// Registry
$registry = new Registry();

// Database 
$db = new DB(DB_DRIVER, DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE, true);
$registry->set('db', $db);

// Loader
$loader = new Loader($registry);
$registry->set('load', $loader);

// Log 
$registry->set('log', new Log('service.txt'));
