<?php
header("Access-Control-Allow-Origin: *");
error_reporting(E_ALL);
ini_set("display_errors", 1);
require_once('snippet_config.php');
$CommonClass = new CommonClass();
$datas = $CommonClass->CommonWrapper();
exit(json_encode($datas));
//echo 'out';exit;
Class CommonClass {
  	public $link;
  
  	public function __construct() {
  		$this->link = new mysqli(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);

		if (mysqli_connect_error()) {
			throw new ErrorException('Error: Could not make a database link (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
		}

		$this->link->set_charset("utf8");
		$this->link->query("SET SQL_MODE = ''");
	    
	    // $this->dbh1 = @mysql_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD); 
	    // mysql_select_db('sport_events_be_db_demostore', $this->dbh1);
	    // mysql_query("SET NAMES 'utf8'", $this->dbh1);
	    // mysql_query("SET CHARACTER SET utf8", $this->dbh1);
	    // mysql_query("SET CHARACTER_SET_CONNECTION=utf8", $this->dbh1);
	    // mysql_query("SET SQL_MODE = ''", $this->dbh1);
  	}

  	public function db_query($sql) {
		$query = $this->link->query($sql);

		if (!$this->link->errno){
			if (isset($query->num_rows)) {
				$data = array();

				while ($row = $query->fetch_assoc()) {
					$data[] = $row;
				}

				$result = new stdClass();
				$result->num_rows = $query->num_rows;
				$result->row = isset($data[0]) ? $data[0] : array();
				$result->rows = $data;

				unset($data);

				$query->close();

				return $result;
			} else{
				return true;
			}
		} else {
			throw new ErrorException('Error: ' . $this->link->error . '<br />Error No: ' . $this->link->errno . '<br />' . $sql);
			exit();
		}
	}

	public function CommonWrapper(){
		$data = $this->getnumbers();
		return $data;
	}

  	public function getnumbers(){
		if(isset($_GET['category'])){
			$category = $_GET['category'];
		} else {
			$category = 'A';
		}
		$member_datas = $this->db_query("SELECT * FROM `member_data` WHERE `sent_status` = '0' AND `category` = '".$category."' ");
		$data = array();
		foreach($member_datas->rows as $mkeys => $mvalues){
			$data[] = array(
				'message' => 'Calling all party lovers for Bar nite @ miniclub house Mumbai,Enjoy drinks Live food Counters & dance to the tunes of DJ mervin 2nd Dec 2016 8.30PM.Call 9004065832',
				'number' => $mvalues['mobile'],
				'id' => $mvalues['id'],
				'category' => $mvalues['category'],
				'sent_status' => $mvalues['sent_status'],
			);
			$sql = "UPDATE `member_data` SET `sent_status` = '1' WHERE `id` = '".$mvalues['id']."' ";
			//$this->db->query($sql);
		}
		// echo '<pre>';
		// print_r($data);
		// exit;
		return $data;
	}
}
?>