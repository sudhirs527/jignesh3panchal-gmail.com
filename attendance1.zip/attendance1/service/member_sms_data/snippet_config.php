<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
define('DB_DRIVER', 'mysqli');
//define('DB_HOSTNAME', '125.99.122.186');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'root');
define('DB_DATABASE', 'db_smsdata');
define('DIR_DOWNLOAD', '/home/aaron/public_html/attendance/service/member_sms_data/download/');
?>