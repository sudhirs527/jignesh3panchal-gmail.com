<?php
header("Access-Control-Allow-Origin: *");
error_reporting(E_ALL);
ini_set("display_errors", 1);
require_once('snippet_config.php');
$CommonClass = new CommonClass();
$datas = $CommonClass->CommonWrapper();
exit(json_encode($datas));
//echo 'out';exit;
Class CommonClass {
  	public $link;
  
  	public function __construct() {
  		$this->link = new mysqli(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);

		if (mysqli_connect_error()) {
			throw new ErrorException('Error: Could not make a database link (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
		}

		$this->link->set_charset("utf8");
		$this->link->query("SET SQL_MODE = ''");
	    
	    // $this->dbh1 = @mysql_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD); 
	    // mysql_select_db('sport_events_be_db_demostore', $this->dbh1);
	    // mysql_query("SET NAMES 'utf8'", $this->dbh1);
	    // mysql_query("SET CHARACTER SET utf8", $this->dbh1);
	    // mysql_query("SET CHARACTER_SET_CONNECTION=utf8", $this->dbh1);
	    // mysql_query("SET SQL_MODE = ''", $this->dbh1);
  	}

  	public function db_query($sql) {
		$query = $this->link->query($sql);

		if (!$this->link->errno){
			if (isset($query->num_rows)) {
				$data = array();

				while ($row = $query->fetch_assoc()) {
					$data[] = $row;
				}

				$result = new stdClass();
				$result->num_rows = $query->num_rows;
				$result->row = isset($data[0]) ? $data[0] : array();
				$result->rows = $data;

				unset($data);

				$query->close();

				return $result;
			} else{
				return true;
			}
		} else {
			throw new ErrorException('Error: ' . $this->link->error . '<br />Error No: ' . $this->link->errno . '<br />' . $sql);
			exit();
		}
	}

	public function CommonWrapper(){
		/*
			A = Club
			B = Life
			C = Stand
			D = Lady Stand
			E = Local
			F = Local Corporate
			G = Temp(Art.33)
			H = Temp(Art.34)
			I = Short Term
			J = Invitee 
		*/
		//$data = $this->import_data('A');
		//$data = $this->import_data('B');
		$data = $this->import_data('D');
		return $data;
	}

  	public function import_data($category){
		//$t = DIR_DOWNLOAD."CLUBMUM.csv";
		//$t = DIR_DOWNLOAD."LIFE.csv";
		$t = DIR_DOWNLOAD."LADYSTAND AND STAND.csv";
		//echo $t;exit;
		$file=fopen($t,"r");
		$i=1;
		$data = array();
		$data['status'] = 0;
		//$this->db->query("TRUNCATE TABLE `tot_ticket_details`");
		while(($var=fgetcsv($file,1000,","))!==FALSE){
			if($i != 1) {
				$data['status'] = 1;
				$var0=addslashes($var[0]);//number
				$sql = "INSERT INTO `member_data` SET `number` = '".$var0."', `category` = '".$category."' ";
				//echo $sql;exit;
				$this->db_query($sql);
			}
			$i ++;
		}
		//echo 'Done';exit;
		return $data;
	}
}
?>