<?php
//echo 'aaaa';exit;
error_reporting(E_ALL);
ini_set("display_errors", 1);
require_once('bootstrap.php');
$file = 'C:\xampp\htdocs\attendance\service/services.txt';

$handle = fopen($file, 'a+'); 
fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- START RUNNING -------', true)  . "\n");

$DataprocessClass = new DataprocessClass($registry);
$DataprocessClass->dataprocess($handle);
fclose($handle);
echo 'out';exit;

Class DataprocessClass {
  	public $db;
  
  	public function __construct($registry) {
  		$this->db = $registry->get('db');
	    $this->log = $registry->get('log');
	    $this->load = $registry->get('load');
	    $this->registry = $registry;
  	}

  	public function dataprocess($handle){
  		// echo '<pre>';
  		// print_r($_GET);
  		// exit;
  		// echo 'aaaaaaa';exit;
		//$result = $this->getEmployees_dat('922');
		// echo '<pre>';
		// print_r($result);
		// exit;		
  		// DELETE FROM `oc_attendance` WHERE `punch_date` >= '2018-03-22';
		// DELETE FROM `oc_transaction` WHERE `date` >= '2018-03-22';
		// UPDATE `oc_leave_transaction_temp` SET `p_status` = '0' WHERE `date` >= '2018-03-22';
		// UPDATE `oc_leave_transaction` SET `p_status` = '0' WHERE `date` >= '2018-03-22';

		$batch_ids = $this->db->query("SELECT `batch_id` FROM `oc_transaction` ORDER BY `batch_id` DESC LIMIT 1");
		if($batch_ids->num_rows > 0){
			$batch_id = $batch_ids->row['batch_id'] + 1;
		} else {
			$batch_id = 1;
		}
		//echo 'aaaaa';exit;

		if(isset($_GET['date']) && isset($_GET['new'])){
			fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- GET INN DATA -------', true)  . "\n");

			$today_date = $_GET['date'];
			
			$this->db->query("DELETE FROM `oc_attendance` WHERE `punch_date` >= '".$today_date."' ");
			//$this->log->write("DELETE FROM `oc_attendance` WHERE `punch_date` >= '".$today_date."' ");
			$this->db->query("DELETE FROM `oc_transaction` WHERE `date` >= '".$today_date."' ");
			//$this->log->write("DELETE FROM `oc_transaction` WHERE `date` >= '".$today_date."' ");
			$this->db->query("UPDATE `oc_leave_transaction_temp` SET `p_status` = '0' WHERE `date` >= '".$today_date."' ");
			//$this->log->write("UPDATE `oc_leave_transaction_temp` SET `p_status` = '0' WHERE `date` >= '".$today_date."' ");
			$this->db->query("UPDATE `oc_leave_transaction` SET `p_status` = '0' WHERE `date` >= '".$today_date."' ");
			//$this->log->write("UPDATE `oc_leave_transaction` SET `p_status` = '0' WHERE `date` >= '".$today_date."' ");
			$today_date = date('Y-m-d');
			//$today_date = '2017-10-27';
			$today_date1 = date('Y-m-d', strtotime(date('Y-m-d') . ' -1 day'));
			//fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r($today_date1, true)  . "\n");
			//$today_date1 = '2017-10-26';
		} else {
			$today_date = date('Y-m-d');
			//$today_date = '2017-10-27';
			$today_date1 = date('Y-m-d', strtotime(date('Y-m-d') . ' -1 day'));
			$this->db->query("DELETE FROM `oc_attendance` WHERE `punch_date` >= '".$today_date1."' ");
			$this->db->query("DELETE FROM `oc_transaction` WHERE `date` >= '".$today_date1."' ");
			fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- GET out DATA -------', true)  . "\n");
			fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r($today_date1, true)  . "\n");
			//$today_date1 = date('Y-m-d');
			//$today_date1 = '2017-10-26';
		}

		// echo $today_date;
		// echo '<br />';
		// echo $today_date1;
		// echo '<br />';
		// exit;
			
		$device_last_dates = $this->db->query("SELECT `date` FROM `oc_transaction` ORDER BY `date` DESC LIMIT 1");
		if($device_last_dates->num_rows > 0){
			$device_last_date = $device_last_dates->row['date'];
		} else {
			$device_last_date = '2016-10-01';
		}
		$next_date = date('Y-m-d', strtotime($device_last_date . ' +1 day'));

		$day = array();
		//$today_date = '2020-05-03';
		$days = $this->GetDays($next_date, $today_date);
        foreach ($days as $dkey => $dvalue) {
        	$dates = explode('-', $dvalue);
        	$day[$dkey]['day'] = $dates[2];
        	$day[$dkey]['date'] = $dvalue;
        }
        //$day = array();
        // echo '<pre>';
        // print_r($day);
        // exit;
        foreach($day as $dkeys => $dvalues){
			$filter_date_start = $dvalues['date'];
			//echo $filter_date_start;exit;
			$exp_datas = array();
			$exp_datas_2 = array();
			$a = glob(DIR_DOWNLOAD."*.Txt");
			$b = glob(DIR_DOWNLOAD."*.txt");
			$c = glob(DIR_DOWNLOAD."*.TXT");
			$all_files = array_merge($a, $b, $c);
			$next_date = date('Y-m-d', strtotime($filter_date_start .' +1 day'));

			$in1 = 0;
			foreach($all_files as $file_name) {
				$exp_datas_temp = array();
				$texp = explode('/', $file_name);
				$comp_date = date('d-m-Y', strtotime($filter_date_start));
				$comp_text = $comp_date.'.txt';
				$dir_file_name = strtolower(end($texp));
				if($comp_text == $dir_file_name){
					$in1 = 1;
					$data = file_get_contents($file_name, FILE_USE_INCLUDE_PATH, null);
					$exp_datas_temp = explode(PHP_EOL, $data);
					$exp_datas = array_merge($exp_datas, $exp_datas_temp);
				}
			}

			$this->data['employees'] = array();
			$employees = array();
			$this->load->model('catalog/employee');		
			if(isset($exp_datas[0]) && $exp_datas[0] == ''){
				unset($exp_datas[0]);
				$rev_exp_datas = $exp_datas;
			} else {
				$rev_exp_datas = $exp_datas;			
			}
			

			$employees = array();
			$employees_final = array();

			foreach($rev_exp_datas as $data) {
				$tdata = trim($data);
				$emp_id  = substr($tdata, 0, 8);
				$in_date_raw = substr($tdata, 9, 11);
				$in_date = date('Y-m-d', strtotime($in_date_raw));
				$in_time_hour = substr($tdata, 21, 2);
				$in_time_min = substr($tdata, 24, 2);
				$in_time = $in_time_hour.':'.$in_time_min;

				if($emp_id != '') {
					$result = $this->getEmployees_dat($emp_id);
					if(isset($result['emp_code'])){
						$employees[] = array(
							'employee_id' => $result['emp_code'],
							'card_id' => $result['card_number'],
							'in_time' => $in_time,
							'punch_date' => $in_date,
							'fdate' => date('Y-m-d H:i:s', strtotime($in_date.' '.$in_time))
						);
					}
				}
			}

			// echo '<pre>';
			// print_r($employees);
			// exit;

			usort($employees, array($this, "sortByOrder"));
			
			$o_emp = array();
			foreach ($employees as $ekey => $evalue) {
				$employees_final[] = $evalue;
			}
			
			if (isset($this->request->get['unit'])) {
				$filter_unit = $this->request->get['unit'];
			} else {
				$filter_unit = 0;
			}

			if(isset($employees_final) && count($employees_final) > 0){
				foreach ($employees_final as $fkey => $employee) {
					$exist = $this->getorderhistory($employee);
					if($exist == 0){
						$mystring = $employee['in_time'];
						$findme   = ':';
						$pos = strpos($mystring, $findme);
						if($pos !== false){
							$in_times = substr($employee['in_time'], 0, 2). ":" .substr($employee['in_time'], 3, 2);
						} else {
							$in_times = substr($employee['in_time'], 0, 2). ":" .substr($employee['in_time'], 2, 2);
						}
						if($in_times != ':'){
							$in_time = date("h:i", strtotime($in_times));
						} else {
							$in_time = '';
						}
						$employee['in_time'] = $in_times;
						// echo '<pre>';
						// print_r($employee);
						// exit;
						$this->insert_attendance_data($employee);
					}
				}
			}
		}

		$next_date = date('Y-m-d', strtotime($device_last_date . ' +1 day'));
		//$today_date1 = '2020-05-03';
		$day = array();
		$days = $this->GetDays($next_date, $today_date1);
        foreach ($days as $dkey => $dvalue) {
        	$dates = explode('-', $dvalue);
        	$day[$dkey]['day'] = $dates[2];
        	$day[$dkey]['date'] = $dvalue;
        }
        fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- DAYS FOREACH -------', true)  . "\n");
        // echo '<pre>';
        // print_r($next_date);
        // echo '<pre>';
        // print_r($today_date1);
        // echo '<pre>';
        // print_r($day);
        // exit;
        foreach($day as $dkeys => $dvalues){
			$filter_date_start = $dvalues['date'];
			//echo $filter_date_start;exit;
			$response = array();
			//if($is_exist == 1){
				$data = array();
				$data['unit'] = $filter_unit;
				//$data['filter_name_id'] = '922';
				$results = $this->getemployees($data);
				foreach ($results as $rkey => $rvalue) {
					$rvaluess = $this->getrawattendance_group_date_custom($rvalue['emp_code'], $filter_date_start);
					// echo 'Emp Id : ' . $rvalue['emp_code'];
					// echo '<br />';

					//echo "<pre>"; print_r($rvaluess); exit;
					if($rvaluess) {
						$emp_data = $this->getempdata($rvaluess['emp_id']);
						$device_id = $rvaluess['device_id'];
						if(isset($emp_data['name']) && $emp_data['name'] != ''){
							
							$emp_name = $emp_data['name'];
							$department = $emp_data['department'];
							$unit = $emp_data['unit'];
							$group = $emp_data['group'];

							$day_date = date('j', strtotime($filter_date_start));
							$day = date('j', strtotime($filter_date_start));
							$month = date('n', strtotime($filter_date_start));
							$year = date('Y', strtotime($filter_date_start));

							//$update3 = "SELECT  `".$day_date."` FROM `oc_shift_schedule` WHERE `emp_code` = '".$rvaluess['emp_id']."' AND `month` = '".$month."' AND `year` = '".$year."' ";
							//$update3 = "SELECT  `".$day_date."` FROM `oc_shift_schedule` WHERE `month` ='".$month."' AND `year` = '".$year."' AND `emp_code` = '".$rvaluess['emp_id']."' ";


							$update33 = $this->db->query("SELECT  `".$day_date."` FROM `oc_shift_schedule` WHERE `emp_code` = '".$rvalue['emp_code']."' AND `month` = '".$month."' AND `year` = '".$year."' ");
							//$update3 = "SELECT  `".$day_date."` FROM `oc_shift_schedule` WHERE `month` ='".$month."' AND `year` = '".$year."' AND `emp_code` = '".$rvalue['emp_code']."' ";
							//$shift_schedule = $this->db->query($update3)->num_rows;

							if($update33->num_rows == 0){
									$insert1 = "INSERT INTO `oc_shift_schedule` SET 
										`emp_code` = '".$rvalue['emp_code']."',
										`1` = 'S_1',
										`2` = 'S_1',
										`3` = 'S_1',
										`4` = 'S_1',
										`5` = 'S_1',
										`6` = 'S_1',
										`7` = 'S_1',
										`8` = 'S_1',
										`9` = 'S_1',
										`10` = 'S_1',
										`11` = 'S_1',
										`12` = 'S_1', 
										`13` = 'S_1', 
										`14` = 'S_1', 
										`15` = 'S_1', 
										`16` = 'S_1', 
										`17` = 'S_1', 
										`18` = 'S_1', 
										`19` = 'S_1', 
										`20` = 'S_1', 
										`21` = 'S_1', 
										`22` = 'S_1', 
										`23` = 'S_1', 
										`24` = 'S_1', 
										`25` = 'S_1', 
										`26` = 'S_1', 
										`27` = 'S_1', 
										`28` = 'S_1', 
										`29` = 'S_1', 
										`30` = 'S_1', 
										`31` = 'S_1', 
										`month` = '".$month."',
										`year` = '".$year."',
										`status` = '1' ,
										`unit` = '".$unit."' "; 
									// echo "<pre>";
									// echo $insert1;
									$this->db->query($insert1);
									$update3 = "SELECT  `".$day_date."` FROM `oc_shift_schedule` WHERE `emp_code` = '".$rvalue['emp_code']."' AND `month` = '".$month."' AND `year` = '".$year."' ";
									fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- update query 1 -------', true)  . "\n");
									fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r($update3, true)  . "\n");
									$shift_schedule = $this->db->query($update3)->row;

							} else {
								$update3 = "SELECT  `".$day_date."` FROM `oc_shift_schedule` WHERE `emp_code` = '".$rvalue['emp_code']."' AND `month` = '".$month."' AND `year` = '".$year."' ";

								fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- update query 2 -------', true)  . "\n");
								fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r($update3, true)  . "\n");

								$shift_schedule = $this->db->query($update3)->row;

							}


							$shift_schedule = $this->db->query($update3)->row;
							$schedule_raw = explode('_', $shift_schedule[$day_date]);
							if(!isset($schedule_raw[2])){
								$schedule_raw[2] = 1;
							}
							if($schedule_raw[0] == 'S'){
								$shift_data = $this->getshiftdata($schedule_raw[1]);
								if(!isset($shift_data['shift_id'])){
									$shift_data = $this->getshiftdata('1');
								}
								if(isset($shift_data['shift_id'])){
									$abnormal_status = 0;
									$shift_intime = $shift_data['in_time'];
									$shift_outtime = $shift_data['out_time'];

									$act_intime = '00:00:00';
									$act_outtime = '00:00:00';
									$act_in_punch_date = $filter_date_start;
									$act_out_punch_date = $filter_date_start;
									
									$trans_exist_sql = "SELECT * FROM `oc_transaction` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$rvaluess['punch_date']."' ";
									$trans_exist = $this->db->query($trans_exist_sql);
									if($trans_exist->num_rows == 0){ 
										$act_intimes = $this->getrawattendance_in_time($rvaluess['emp_id'], $rvaluess['punch_date']);
										if(isset($act_intimes['punch_time'])) {
											$act_intime = $act_intimes['punch_time'];
											$act_in_punch_date = $act_intimes['punch_date'];
										}
										$act_outtimes = $this->getrawattendance_out_time($rvaluess['emp_id'], $rvaluess['punch_date'], $act_intime, $act_in_punch_date);
										if(isset($act_outtimes['punch_time'])) {
											$act_outtime = $act_outtimes['punch_time'];
											$act_out_punch_date = $act_outtimes['punch_date'];
										}
									} else {
										if($trans_exist->row['act_intime'] == '00:00:00'){
											$new_data_sql = "SELECT * FROM `oc_attendance` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `punch_date` = '".$rvaluess['punch_date']."' AND `status` = '0' ";
											$new_data_exist = $this->db->query($new_data_sql);
											if($new_data_exist->num_rows > 0){	
												$act_intimes = $this->getrawattendance_in_time($rvaluess['emp_id'], $rvaluess['punch_date']);
												if(isset($act_intimes['punch_time'])) {
													$act_intime = $act_intimes['punch_time'];
													$act_in_punch_date = $act_intimes['punch_date'];
												}
											}	
										} else {
											$act_intime = $trans_exist->row['act_intime'];
											$act_in_punch_date = $trans_exist->row['date'];	
										}
									
										$new_data_sql = "SELECT * FROM `oc_attendance` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `punch_date` = '".$rvaluess['punch_date']."' AND `status` = '0' ";
										$new_data_exist = $this->db->query($new_data_sql);
										if($new_data_exist->num_rows > 0){
											$act_outtimes = $this->getrawattendance_out_time($rvaluess['emp_id'], $rvaluess['punch_date'], $act_intime, $act_in_punch_date);
											if(isset($act_outtimes['punch_time'])) {
												$act_outtime = $act_outtimes['punch_time'];
												$act_out_punch_date = $act_outtimes['punch_date'];
											}
										} else {
											$act_outtime = $trans_exist->row['act_outtime'];
											$act_out_punch_date = $trans_exist->row['date_out'];
										}
									}

									if($act_intime == $act_outtime){
										$act_outtime = '00:00:00';
									}
									
									$first_half = 0;
									$second_half = 0;
									$late_time = '00:00:00';
									
									if($act_intime != '00:00:00'){
										$start_date = new DateTime($act_in_punch_date.' '.$shift_intime);
										$since_start = $start_date->diff(new DateTime($act_in_punch_date.' '.$act_intime));
										if($since_start->h > 12){
											$start_date = new DateTime($act_in_punch_date.' '.$shift_intime);
											$since_start = $start_date->diff(new DateTime($act_out_punch_date.' '.$act_intime));
										}
										$late_time = $since_start->h.':'.$since_start->i.':'.$since_start->s;
										if($since_start->invert == 1){
											$late_time = '00:00:00';
										}
										if($act_outtime != '00:00:00'){
											$first_half = 1;
											$second_half = 1;
											
										} else {
											$first_half = 0;
											$second_half = 0;
										}
									} else {
										$first_half = 0;
										$second_half = 0;
									}

									$working_time = '00:00:00';
									$early_time = '00:00:00';
									if($abnormal_status == 0){ //if abnormal status is zero calculate further 
										$early_time = '00:00:00';
										if($act_outtime != '00:00:00'){ //for getting early time i.e difference between shiftouttime and sctouttime 
											$start_date = new DateTime($act_in_punch_date.' '.$shift_outtime);
											$since_start = $start_date->diff(new DateTime($act_out_punch_date.' '.$act_outtime));
											if($since_start->h > 12){
												$start_date = new DateTime($act_out_punch_date.' '.$shift_outtime);
												$since_start = $start_date->diff(new DateTime($act_in_punch_date.' '.$act_outtime));
											}
											$early_time = $since_start->h.':'.$since_start->i.':'.$since_start->s;					
											if($since_start->invert == 0){
												$early_time = '00:00:00';
											}
										}					
										
										$working_time = '00:00:00';
										if($act_outtime != '00:00:00'){//for getting working time
											$start_date = new DateTime($act_in_punch_date.' '.$act_intime);
											$since_start = $start_date->diff(new DateTime($act_out_punch_date.' '.$act_outtime));
											$working_time = $since_start->h.':'.$since_start->i.':'.$since_start->s;
										}
									} else {
										$first_half = 0;
										$second_half = 0;
									}
									
									$abs_stat = 0;
									if($first_half == 1 && $second_half == 1){
										$present_status = 1;
										$absent_status = 0;
									} elseif($first_half == 1 && $second_half == 0){
										$present_status = 0.5;
										$absent_status = 0.5;
									} elseif($first_half == 0 && $second_half == 1){
										$present_status = 0.5;
										$absent_status = 0.5;
									} else {
										$present_status = 0;
										$absent_status = 1;
									}

									$day = date('j', strtotime($rvaluess['punch_date']));
									$month = date('n', strtotime($rvaluess['punch_date']));
									$year = date('Y', strtotime($rvaluess['punch_date']));
									//echo 'out';exit;
									if($trans_exist->num_rows == 0){
										if($abs_stat == 1){
											$act_intime = '00:00:00';
											$act_outtime = '00:00:00';
											$abnormal_status = 0;
											$act_out_punch_date = $filter_date_start;
											$sql = "INSERT INTO `oc_transaction` SET `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `day` = '".$day."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', halfday_status = '0', `compli_status` = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ";
											fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- insert query 1 -------', true)  . "\n");
											fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("INSERT INTO `oc_transaction` SET `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `day` = '".$day."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', halfday_status = '0', `compli_status` = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ", true)  . "\n");
										} else {
											$sql = "INSERT INTO `oc_transaction` SET `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `day` = '".$day."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', halfday_status = '0', `compli_status` = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ";
											fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- insert query 2 -------', true)  . "\n");
											fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("INSERT INTO `oc_transaction` SET `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `day` = '".$day."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', halfday_status = '0', `compli_status` = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ", true)  . "\n");
										}
										$this->db->query($sql);
										$transaction_id = $this->db->getLastId();
									} else {
										if($abs_stat == 1){
											$act_intime = '00:00:00';
											$act_outtime = '00:00:00';
											$abnormal_status = 0;
											$act_out_punch_date = $filter_date_start;
											$sql = "UPDATE `oc_transaction` SET `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', `weekly_off` = '0', `holiday_id` = '0', halfday_status = '0', `compli_status` = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ";

											fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- UPDATE query 3 -------', true)  . "\n");
											fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("UPDATE `oc_transaction` SET `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', `weekly_off` = '0', `holiday_id` = '0', halfday_status = '0', `compli_status` = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ", true)  . "\n");

										} else {
											$sql = "UPDATE `oc_transaction` SET `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', `weekly_off` = '0', `holiday_id` = '0', halfday_status = '0', `compli_status` = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ";
											fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- UPDATE query 4 -------', true)  . "\n");
											fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("UPDATE `oc_transaction` SET `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', `weekly_off` = '0', `holiday_id` = '0', halfday_status = '0', `compli_status` = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ", true)  . "\n");
										}
										$this->db->query($sql);
										$transaction_id = $this->db->query("SELECT `transaction_id` FROM `oc_transaction` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ")->row['transaction_id'];
									}
									// echo $sql.';';
									// echo '<br />';
									// exit;
									
								}
								//echo 'out1';exit;
							} elseif ($schedule_raw[0] == 'W') {
								$shift_data = $this->getshiftdata($schedule_raw[2]);
								if(!isset($shift_data['shift_id'])){
									$shift_data = $this->getshiftdata('1');
								}
								$shift_intime = $shift_data['in_time'];
								$shift_outtime = $shift_data['out_time'];

								$act_intime = '00:00:00';
								$act_outtime = '00:00:00';
								$act_in_punch_date = $filter_date_start;
								$act_out_punch_date = $filter_date_start;

								$trans_exist_sql = "SELECT * FROM `oc_transaction` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$rvaluess['punch_date']."' ";
								$trans_exist = $this->db->query($trans_exist_sql);
								if($trans_exist->num_rows == 0){ 
									$act_intimes = $this->getrawattendance_in_time($rvaluess['emp_id'], $rvaluess['punch_date']);
									if(isset($act_intimes['punch_time'])) {
										$act_intime = $act_intimes['punch_time'];
										$act_in_punch_date = $act_intimes['punch_date'];
									}
									$act_outtimes = $this->getrawattendance_out_time($rvaluess['emp_id'], $rvaluess['punch_date'], $act_intime, $act_in_punch_date);
									if(isset($act_outtimes['punch_time'])) {
										$act_outtime = $act_outtimes['punch_time'];
										$act_out_punch_date = $act_outtimes['punch_date'];
									}
								} else {
									if($trans_exist->row['act_intime'] == '00:00:00'){
										$new_data_sql = "SELECT * FROM `oc_attendance` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `punch_date` = '".$rvaluess['punch_date']."' AND `status` = '0' ";
										$new_data_exist = $this->db->query($new_data_sql);
										if($new_data_exist->num_rows > 0){	
											$act_intimes = $this->getrawattendance_in_time($rvaluess['emp_id'], $rvaluess['punch_date']);
											if(isset($act_intimes['punch_time'])) {
												$act_intime = $act_intimes['punch_time'];
												$act_in_punch_date = $act_intimes['punch_date'];
											}
										}	
									} else {
										$act_intime = $trans_exist->row['act_intime'];
										$act_in_punch_date = $trans_exist->row['date'];	
									}
									
									$new_data_sql = "SELECT * FROM `oc_attendance` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `punch_date` = '".$rvaluess['punch_date']."' AND `status` = '0' ";
									$new_data_exist = $this->db->query($new_data_sql);
									if($new_data_exist->num_rows > 0){
										$act_outtimes = $this->getrawattendance_out_time($rvaluess['emp_id'], $rvaluess['punch_date'], $act_intime, $act_in_punch_date);
										if(isset($act_outtimes['punch_time'])) {
											$act_outtime = $act_outtimes['punch_time'];
											$act_out_punch_date = $act_outtimes['punch_date'];
										}
									} else {
										$act_outtime = $trans_exist->row['act_outtime'];
										$act_out_punch_date = $trans_exist->row['date_out'];
									}
								}
								$abnormal_status = 0;

								$working_time = '00:00:00';
								if($act_outtime != '00:00:00'){//for getting working time
									$start_date = new DateTime($act_in_punch_date.' '.$act_intime);
									$since_start = $start_date->diff(new DateTime($act_out_punch_date.' '.$act_outtime));
									$working_time = $since_start->h.':'.$since_start->i.':'.$since_start->s;
								}

								$abs_stat = 0;
								if($filter_date_start != $act_in_punch_date){
									$abs_stat = 1;
									$act_in_punch_date = $filter_date_start;
								}

								// if($act_intime == '00:00:00' || $act_outtime == '00:00:00'){
								// 	$abnormal_status = 1;
								// }
								
								if($act_intime == $act_outtime){
									$act_outtime = '00:00:00';
								}

								if($trans_exist->num_rows == 0){
									if($abs_stat == 1){
										$act_intime = '00:00:00';
										$act_outtime = '00:00:00';
										$abnormal_status = 0;
										$act_out_punch_date = $filter_date_start;
										$sql = "INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `working_time` = '".$working_time."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'WO', `secondhalf_status` = 'WO', `weekly_off` = '".$schedule_raw[1]."', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '".$abnormal_status."', halfday_status = '0', compli_status = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ";
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- insert query 3 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `working_time` = '".$working_time."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'WO', `secondhalf_status` = 'WO', `weekly_off` = '".$schedule_raw[1]."', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '".$abnormal_status."', halfday_status = '0', compli_status = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ", true)  . "\n");
									} else {
										$sql = "INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `working_time` = '".$working_time."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'WO', `secondhalf_status` = 'WO', `weekly_off` = '".$schedule_raw[1]."', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '".$abnormal_status."', halfday_status = '0', compli_status = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ";

										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- insert query 4 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `working_time` = '".$working_time."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'WO', `secondhalf_status` = 'WO', `weekly_off` = '".$schedule_raw[1]."', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '".$abnormal_status."', halfday_status = '0', compli_status = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ", true)  . "\n");
									}
									$this->db->query($sql);
									$transaction_id = $this->db->getLastId();
								} else {
									if($abs_stat == 1){
										$act_intime = '00:00:00';
										$act_outtime = '00:00:00';
										$abnormal_status = 0;
										$act_out_punch_date = $filter_date_start;
										$sql = "UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `working_time` = '".$working_time."', abnormal_status = '".$abnormal_status."', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', compli_status = '0', `firsthalf_status` = 'WO', `secondhalf_status` = 'WO', `weekly_off` = '".$schedule_raw[1]."', halfday_status = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ";
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- UPDATE query 5 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `working_time` = '".$working_time."', abnormal_status = '".$abnormal_status."', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', compli_status = '0', `firsthalf_status` = 'WO', `secondhalf_status` = 'WO', `weekly_off` = '".$schedule_raw[1]."', halfday_status = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ", true)  . "\n");
									} else {
										$sql = "UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `working_time` = '".$working_time."', abnormal_status = '".$abnormal_status."', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', compli_status = '0', `firsthalf_status` = 'WO', `secondhalf_status` = 'WO', `weekly_off` = '".$schedule_raw[1]."', halfday_status = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ";

										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- UPDATE query 6 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `working_time` = '".$working_time."', abnormal_status = '".$abnormal_status."', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', compli_status = '0', `firsthalf_status` = 'WO', `secondhalf_status` = 'WO', `weekly_off` = '".$schedule_raw[1]."', halfday_status = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ", true)  . "\n");
									}
									$this->db->query($sql);
									$transaction_id = $this->db->query("SELECT `transaction_id` FROM `oc_transaction` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ")->row['transaction_id'];
								}
								//echo $sql.';';
								//echo '<br />';
								
							} elseif ($schedule_raw[0] == 'H') {
								$shift_data = $this->getshiftdata($schedule_raw[2]);
								if(!isset($shift_data['shift_id'])){
									$shift_data = $this->getshiftdata('1');
								}
								$shift_intime = $shift_data['in_time'];
								$shift_outtime = $shift_data['out_time'];

								$act_intime = '00:00:00';
								$act_outtime = '00:00:00';
								$act_in_punch_date = $filter_date_start;
								$act_out_punch_date = $filter_date_start;
								
								$trans_exist_sql = "SELECT * FROM `oc_transaction` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$rvaluess['punch_date']."' ";
								$trans_exist = $this->db->query($trans_exist_sql);
								if($trans_exist->num_rows == 0){ 
									$act_intimes = $this->getrawattendance_in_time($rvaluess['emp_id'], $rvaluess['punch_date']);
									if(isset($act_intimes['punch_time'])) {
										$act_intime = $act_intimes['punch_time'];
										$act_in_punch_date = $act_intimes['punch_date'];
									}
									$act_outtimes = $this->getrawattendance_out_time($rvaluess['emp_id'], $rvaluess['punch_date'], $act_intime, $act_in_punch_date);
									if(isset($act_outtimes['punch_time'])) {
										$act_outtime = $act_outtimes['punch_time'];
										$act_out_punch_date = $act_outtimes['punch_date'];
									}
								} else {
									if($trans_exist->row['act_intime'] == '00:00:00'){
										$new_data_sql = "SELECT * FROM `oc_attendance` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `punch_date` = '".$rvaluess['punch_date']."' AND `status` = '0' ";
										$new_data_exist = $this->db->query($new_data_sql);
										if($new_data_exist->num_rows > 0){	
											$act_intimes = $this->getrawattendance_in_time($rvaluess['emp_id'], $rvaluess['punch_date']);
											if(isset($act_intimes['punch_time'])) {
												$act_intime = $act_intimes['punch_time'];
												$act_in_punch_date = $act_intimes['punch_date'];
											}
										}	
									} else {
										$act_intime = $trans_exist->row['act_intime'];
										$act_in_punch_date = $trans_exist->row['date'];	
									}


									$new_data_sql = "SELECT * FROM `oc_attendance` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `punch_date` = '".$rvaluess['punch_date']."' AND `status` = '0' ";
									$new_data_exist = $this->db->query($new_data_sql);
									if($new_data_exist->num_rows > 0){
										$act_outtimes = $this->getrawattendance_out_time($rvaluess['emp_id'], $rvaluess['punch_date'], $act_intime, $act_in_punch_date);
										if(isset($act_outtimes['punch_time'])) {
											$act_outtime = $act_outtimes['punch_time'];
											$act_out_punch_date = $act_outtimes['punch_date'];
										}
									} else {
										$act_outtime = $trans_exist->row['act_outtime'];
										$act_out_punch_date = $trans_exist->row['date_out'];
									}
								}

								$abnormal_status = 0;

								$working_time = '00:00:00';
								if($act_outtime != '00:00:00'){//for getting working time
									$start_date = new DateTime($act_in_punch_date.' '.$act_intime);
									$since_start = $start_date->diff(new DateTime($act_out_punch_date.' '.$act_outtime));
									$working_time = $since_start->h.':'.$since_start->i.':'.$since_start->s;
								}
								
								$abs_stat = 0;
								if($filter_date_start != $act_in_punch_date){
									$abs_stat = 1;
									$act_in_punch_date = $filter_date_start;
								}

								// if($act_intime == '00:00:00' || $act_outtime == '00:00:00'){
								// 	$abnormal_status = 1;
								// }
								
								if($act_intime == $act_outtime){
									$act_outtime = '00:00:00';
								}

								if($trans_exist->num_rows == 0){
									if($abs_stat == 1){
										$act_intime = '00:00:00';
										$act_outtime = '00:00:00';
										$abnormal_status = 0;
										$act_out_punch_date = $filter_date_start;
										$sql = "INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `working_time` = '".$working_time."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'HLD', `secondhalf_status` = 'HLD', `weekly_off` = '0', `holiday_id` = '".$schedule_raw[1]."', `present_status` = '0', `absent_status` = '0', `abnormal_status` = '".$abnormal_status."', `halfday_status` = '0', `compli_status` = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ";
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- INSERT query 5 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `working_time` = '".$working_time."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'HLD', `secondhalf_status` = 'HLD', `weekly_off` = '0', `holiday_id` = '".$schedule_raw[1]."', `present_status` = '0', `absent_status` = '0', `abnormal_status` = '".$abnormal_status."', `halfday_status` = '0', `compli_status` = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ", true)  . "\n");
									} else {
										$sql = "INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `working_time` = '".$working_time."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'HLD', `secondhalf_status` = 'HLD', `weekly_off` = '0', `holiday_id` = '".$schedule_raw[1]."', `present_status` = '0', `absent_status` = '0', `abnormal_status` = '".$abnormal_status."', `halfday_status` = '0', `compli_status` = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ";
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- INSERT query 6 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `working_time` = '".$working_time."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'HLD', `secondhalf_status` = 'HLD', `weekly_off` = '0', `holiday_id` = '".$schedule_raw[1]."', `present_status` = '0', `absent_status` = '0', `abnormal_status` = '".$abnormal_status."', `halfday_status` = '0', `compli_status` = '0', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ", true)  . "\n");
									}
									$this->db->query($sql);
									$transaction_id = $this->db->getLastId();
								} else {
									if($abs_stat == 1){
										$act_intime = '00:00:00';
										$act_outtime = '00:00:00';
										$abnormal_status = 0;
										$act_out_punch_date = $filter_date_start;
										$sql = "UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `working_time` = '".$working_time."', abnormal_status = '".$abnormal_status."', `weekly_off` = '0', `present_status` = '0', `absent_status` = '0', `halfday_status` = '0', `compli_status` = '0', `firsthalf_status` = 'HLD', `secondhalf_status` = 'HLD', `holiday_id` = '".$schedule_raw[1]."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ";
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- UPDATE query 7 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `working_time` = '".$working_time."', abnormal_status = '".$abnormal_status."', `weekly_off` = '0', `present_status` = '0', `absent_status` = '0', `halfday_status` = '0', `compli_status` = '0', `firsthalf_status` = 'HLD', `secondhalf_status` = 'HLD', `holiday_id` = '".$schedule_raw[1]."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ", true)  . "\n");
									} else {
										$sql = "UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `working_time` = '".$working_time."', abnormal_status = '".$abnormal_status."', `weekly_off` = '0', `present_status` = '0', `absent_status` = '0', `halfday_status` = '0', `compli_status` = '0', `firsthalf_status` = 'HLD', `secondhalf_status` = 'HLD', `holiday_id` = '".$schedule_raw[1]."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ";
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- UPDATE query 8 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `working_time` = '".$working_time."', abnormal_status = '".$abnormal_status."', `weekly_off` = '0', `present_status` = '0', `absent_status` = '0', `halfday_status` = '0', `compli_status` = '0', `firsthalf_status` = 'HLD', `secondhalf_status` = 'HLD', `holiday_id` = '".$schedule_raw[1]."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ", true)  . "\n");
									}
									$this->db->query($sql);
									$transaction_id = $this->db->query("SELECT `transaction_id` FROM `oc_transaction` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ")->row['transaction_id'];
								}
								//echo $sql.';';
								//echo '<br />';
							} elseif ($schedule_raw[0] == 'HD') {
								$shift_data = $this->getshiftdata($schedule_raw[2]);
								if(!isset($shift_data['shift_id'])){
									$shift_data = $this->getshiftdata('1');
								}
								$shift_intime = $shift_data['in_time'];
								$shift_outtime = Date('H:i:s', strtotime($shift_intime .' +4 hours'));
								//$shift_outtime = $shift_data['out_time'];

								$act_intime = '00:00:00';
								$act_outtime = '00:00:00';
								$act_in_punch_date = $filter_date_start;
								$act_out_punch_date = $filter_date_start;
								
								$trans_exist_sql = "SELECT * FROM `oc_transaction` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$rvaluess['punch_date']."' ";
								$trans_exist = $this->db->query($trans_exist_sql);
								if($trans_exist->num_rows == 0){ 
									$act_intimes = $this->getrawattendance_in_time($rvaluess['emp_id'], $rvaluess['punch_date']);
									if(isset($act_intimes['punch_time'])) {
										$act_intime = $act_intimes['punch_time'];
										$act_in_punch_date = $act_intimes['punch_date'];
									}
									$act_outtimes = $this->getrawattendance_out_time($rvaluess['emp_id'], $rvaluess['punch_date'], $act_intime, $act_in_punch_date);
									if(isset($act_outtimes['punch_time'])) {
										$act_outtime = $act_outtimes['punch_time'];
										$act_out_punch_date = $act_outtimes['punch_date'];
									}
								} else {
									if($trans_exist->row['act_intime'] == '00:00:00'){
										$new_data_sql = "SELECT * FROM `oc_attendance` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `punch_date` = '".$rvaluess['punch_date']."' AND `status` = '0' ";
										$new_data_exist = $this->db->query($new_data_sql);
										if($new_data_exist->num_rows > 0){	
											$act_intimes = $this->getrawattendance_in_time($rvaluess['emp_id'], $rvaluess['punch_date']);
											if(isset($act_intimes['punch_time'])) {
												$act_intime = $act_intimes['punch_time'];
												$act_in_punch_date = $act_intimes['punch_date'];
											}
										}	
									} else {
										$act_intime = $trans_exist->row['act_intime'];
										$act_in_punch_date = $trans_exist->row['date'];	
									}
									
									
									$new_data_sql = "SELECT * FROM `oc_attendance` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `punch_date` = '".$rvaluess['punch_date']."' AND `status` = '0' ";
									$new_data_exist = $this->db->query($new_data_sql);
									if($new_data_exist->num_rows > 0){
										$act_outtimes = $this->getrawattendance_out_time($rvaluess['emp_id'], $rvaluess['punch_date'], $act_intime, $act_in_punch_date);
										if(isset($act_outtimes['punch_time'])) {
											$act_outtime = $act_outtimes['punch_time'];
											$act_out_punch_date = $act_outtimes['punch_date'];
										}
									} else {
										$act_outtime = $trans_exist->row['act_outtime'];
										$act_out_punch_date = $trans_exist->row['date_out'];
									}
								}

								$abnormal_status = 0;
								$abs_stat = 0;
								if($act_intime == $act_outtime){
									$act_outtime = '00:00:00';
								}

								
								$first_half = 0;
								$second_half = 0;
								$late_time = '00:00:00';
								
								// $act_intime = '12:05:00';
								// $act_outtime = '17:55:00';

								if($act_intime != '00:00:00'){
									$start_date = new DateTime($act_in_punch_date.' '.$shift_intime);
									$since_start = $start_date->diff(new DateTime($act_in_punch_date.' '.$act_intime));
									if($since_start->h > 12){
										$start_date = new DateTime($act_in_punch_date.' '.$shift_intime);
										$since_start = $start_date->diff(new DateTime($act_out_punch_date.' '.$act_intime));
									}
									$late_time = $since_start->h.':'.$since_start->i.':'.$since_start->s;
									if($since_start->invert == 1){
										$late_time = '00:00:00';
									}
									
									if($act_outtime != '00:00:00'){
										$first_half = 1;
										$second_half = 'HD';
									} else {
										$first_half = 0;
										$second_half = 0;
									}
								} else {
									$first_half = 0;
									$second_half = 0;
								}

								$working_time = '00:00:00';
								$early_time = '00:00:00';
								if($abnormal_status == 0){ //if abnormal status is zero calculate further 
									$early_time = '00:00:00';
									if($act_outtime != '00:00:00'){ //for getting early time i.e difference between shiftouttime and sctouttime 
										$start_date = new DateTime($act_in_punch_date.' '.$shift_outtime);
										$since_start = $start_date->diff(new DateTime($act_out_punch_date.' '.$act_outtime));
										if($since_start->h > 12){
											$start_date = new DateTime($act_out_punch_date.' '.$shift_outtime);
											$since_start = $start_date->diff(new DateTime($act_in_punch_date.' '.$act_outtime));
										}
										$early_time = $since_start->h.':'.$since_start->i.':'.$since_start->s;					
										if($since_start->invert == 0){
											$early_time = '00:00:00';
										}
									}					
									
									$working_time = '00:00:00';
									if($act_outtime != '00:00:00'){//for getting working time
										$start_date = new DateTime($act_in_punch_date.' '.$act_intime);
										$since_start = $start_date->diff(new DateTime($act_out_punch_date.' '.$act_outtime));
										$working_time = $since_start->h.':'.$since_start->i.':'.$since_start->s;
									}
								} else {
									$first_half = 0;
									$second_half = 0;
								}
								

								$abs_stat = 0;
								if($first_half == 1 && $second_half == 'HD'){
									$present_status = 1;
									$absent_status = 0;
								} else {
									$present_status = 0;
									$absent_status = 1;
								}

								if($trans_exist->num_rows == 0){
									if($abs_stat == 1){
										$act_intime = '00:00:00';
										$act_outtime = '00:00:00';
										$abnormal_status = 0;
										$act_out_punch_date = $filter_date_start;
										$sql = "INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', `halfday_status` = '".$schedule_raw[1]."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ";
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- INSERT query 7 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', `halfday_status` = '".$schedule_raw[1]."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ", true)  . "\n");
									} else {
										$sql = "INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', `halfday_status` = '".$schedule_raw[1]."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ";
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- INSERT query 8 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', `halfday_status` = '".$schedule_raw[1]."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ", true)  . "\n");
									}
									$this->db->query($sql);
									$transaction_id = $this->db->getLastId();
								} else {
									if($abs_stat == 1){
										$act_intime = '00:00:00';
										$act_outtime = '00:00:00';
										$abnormal_status = 0;
										$act_out_punch_date = $filter_date_start;
										$sql = "UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', `halfday_status` = '".$schedule_raw[1]."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ";
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- UPDATE query 9 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', `halfday_status` = '".$schedule_raw[1]."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ", true)  . "\n");
									} else {
										$sql = "UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', `halfday_status` = '".$schedule_raw[1]."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ";
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- UPDATE query 10 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `firsthalf_status` = '".$first_half."', `secondhalf_status` = '".$second_half."', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '".$present_status."', `absent_status` = '".$absent_status."', abnormal_status = '".$abnormal_status."', `halfday_status` = '".$schedule_raw[1]."', `late_time` = '".$late_time."', `early_time` = '".$early_time."', `working_time` = '".$working_time."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ", true)  . "\n");
									}
									$this->db->query($sql);
									$transaction_id = $this->db->query("SELECT `transaction_id` FROM `oc_transaction` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ")->row['transaction_id'];
								}
								//echo $sql.';';
								//echo '<br />';
							}  elseif ($schedule_raw[0] == 'C') {
								$shift_data = $this->getshiftdata($schedule_raw[2]);
								if(!isset($shift_data['shift_id'])){
									$shift_data = $this->getshiftdata('1');
								}
								$shift_intime = $shift_data['in_time'];
								$shift_outtime = $shift_data['out_time'];

								$act_intime = '00:00:00';
								$act_outtime = '00:00:00';
								$act_in_punch_date = $filter_date_start;
								$act_out_punch_date = $filter_date_start;
								
								$trans_exist_sql = "SELECT * FROM `oc_transaction` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$rvaluess['punch_date']."' ";
								$trans_exist = $this->db->query($trans_exist_sql);
								if($trans_exist->num_rows == 0){ 
									$act_intimes = $this->getrawattendance_in_time($rvaluess['emp_id'], $rvaluess['punch_date']);
									if(isset($act_intimes['punch_time'])) {
										$act_intime = $act_intimes['punch_time'];
										$act_in_punch_date = $act_intimes['punch_date'];
									}
									$act_outtimes = $this->getrawattendance_out_time($rvaluess['emp_id'], $rvaluess['punch_date'], $act_intime, $act_in_punch_date);
									if(isset($act_outtimes['punch_time'])) {
										$act_outtime = $act_outtimes['punch_time'];
										$act_out_punch_date = $act_outtimes['punch_date'];
									}
								} else {
									if($trans_exist->row['act_intime'] == '00:00:00'){
										$new_data_sql = "SELECT * FROM `oc_attendance` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `punch_date` = '".$rvaluess['punch_date']."' AND `status` = '0' ";
										$new_data_exist = $this->db->query($new_data_sql);
										if($new_data_exist->num_rows > 0){	
											$act_intimes = $this->getrawattendance_in_time($rvaluess['emp_id'], $rvaluess['punch_date']);
											if(isset($act_intimes['punch_time'])) {
												$act_intime = $act_intimes['punch_time'];
												$act_in_punch_date = $act_intimes['punch_date'];
											}
										}	
									} else {
										$act_intime = $trans_exist->row['act_intime'];
										$act_in_punch_date = $trans_exist->row['date'];	
									}
									
									$new_data_sql = "SELECT * FROM `oc_attendance` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `punch_date` = '".$rvaluess['punch_date']."' AND `status` = '0' ";
									$new_data_exist = $this->db->query($new_data_sql);
									if($new_data_exist->num_rows > 0){
										$act_outtimes = $this->getrawattendance_out_time($rvaluess['emp_id'], $rvaluess['punch_date'], $act_intime, $act_in_punch_date);
										if(isset($act_outtimes['punch_time'])) {
											$act_outtime = $act_outtimes['punch_time'];
											$act_out_punch_date = $act_outtimes['punch_date'];
										}
									} else {
										$act_outtime = $trans_exist->row['act_outtime'];
										$act_out_punch_date = $trans_exist->row['date_out'];
									}
								}

								$abnormal_status = 0;

								$working_time = '00:00:00';
								if($act_outtime != '00:00:00'){//for getting working time
									$start_date = new DateTime($act_in_punch_date.' '.$act_intime);
									$since_start = $start_date->diff(new DateTime($act_out_punch_date.' '.$act_outtime));
									$working_time = $since_start->h.':'.$since_start->i.':'.$since_start->s;
								}
								
								$abs_stat = 0;
								if($filter_date_start != $act_in_punch_date){
									$abs_stat = 1;
									$act_in_punch_date = $filter_date_start;
								}

								// if($act_intime == '00:00:00' || $act_outtime == '00:00:00'){
								// 	$abnormal_status = 1;
								// }
								
								if($act_intime == $act_outtime){
									$act_outtime = '00:00:00';
								}

								if($trans_exist->num_rows == 0){
									if($abs_stat == 1){
										$act_intime = '00:00:00';
										$act_outtime = '00:00:00';
										$abnormal_status = 0;
										$act_out_punch_date = $filter_date_start;
										$sql = "INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `working_time` = '".$working_time."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'COF', `secondhalf_status` = 'COF', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '".$abnormal_status."', `halfday_status` = '0', `compli_status` = '".$schedule_raw[1]."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ";
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- INSERT query 9 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `working_time` = '".$working_time."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'COF', `secondhalf_status` = 'COF', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '".$abnormal_status."', `halfday_status` = '0', `compli_status` = '".$schedule_raw[1]."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ", true)  . "\n");
									} else {
										$sql = "INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `working_time` = '".$working_time."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'COF', `secondhalf_status` = 'COF', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '".$abnormal_status."', `halfday_status` = '0', `compli_status` = '".$schedule_raw[1]."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ";
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- INSERT query 10 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvaluess['emp_id']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `working_time` = '".$working_time."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$act_in_punch_date."', `date_out` = '".$act_out_punch_date."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'COF', `secondhalf_status` = 'COF', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '".$abnormal_status."', `halfday_status` = '0', `compli_status` = '".$schedule_raw[1]."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' ", true)  . "\n");
									}
									$this->db->query($sql);
									$transaction_id = $this->db->getLastId();
								} else {
									if($abs_stat == 1){
										$act_intime = '00:00:00';
										$act_outtime = '00:00:00';
										$abnormal_status = 0;
										$act_out_punch_date = $filter_date_start;
										$sql = "UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `working_time` = '".$working_time."', `firsthalf_status` = 'COF', `secondhalf_status` = 'COF', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '".$abnormal_status."', `halfday_status` = '0', `compli_status` = '".$schedule_raw[1]."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ";
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- UPDATE query 11 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `working_time` = '".$working_time."', `firsthalf_status` = 'COF', `secondhalf_status` = 'COF', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '".$abnormal_status."', `halfday_status` = '0', `compli_status` = '".$schedule_raw[1]."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ", true)  . "\n");
									} else {
										$sql = "UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `working_time` = '".$working_time."', `firsthalf_status` = 'COF', `secondhalf_status` = 'COF', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '".$abnormal_status."', `halfday_status` = '0', `compli_status` = '".$schedule_raw[1]."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ";	
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- UPDATE query 12 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `act_intime` = '".$act_intime."', `date` = '".$act_in_punch_date."', `act_outtime` = '".$act_outtime."', `date_out` = '".$act_out_punch_date."', `working_time` = '".$working_time."', `firsthalf_status` = 'COF', `secondhalf_status` = 'COF', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '".$abnormal_status."', `halfday_status` = '0', `compli_status` = '".$schedule_raw[1]."', `device_id` = '".$device_id."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ", true)  . "\n");
									}
									$this->db->query($sql);
									$transaction_id = $this->db->query("SELECT `transaction_id` FROM `oc_transaction` WHERE `emp_id` = '".$rvaluess['emp_id']."' AND `date` = '".$act_in_punch_date."' ")->row['transaction_id'];
								}
								//echo $sql.';';
								//echo '<br />';
							}
							if($act_in_punch_date == $act_out_punch_date) {
								if($act_intime != '00:00:00' && $act_outtime != '00:00:00'){
									$update = "UPDATE `oc_attendance` SET `status` = '1', `transaction_id` = '".$transaction_id."' WHERE `punch_date` = '".$act_in_punch_date."' AND `punch_time` >= '".$act_intime."' AND `punch_time` <= '".$act_outtime."' AND `emp_id` = '".$rvaluess['emp_id']."' ";
									//echo $update;exit;
									$this->db->query($update);
									$this->log->write($update);
								} elseif($act_intime != '00:00:00' && $act_outtime == '00:00:00') {
									$update = "UPDATE `oc_attendance` SET `status` = '1', `transaction_id` = '".$transaction_id."' WHERE `punch_date` = '".$act_in_punch_date."' AND `punch_time` = '".$act_intime."' AND `emp_id` = '".$rvaluess['emp_id']."' ";
									//echo $update;exit;
									$this->db->query($update);
									$this->log->write($update);
								} elseif($act_intime == '00:00:00' && $act_outtime != '00:00:00') {
									$update = "UPDATE `oc_attendance` SET `status` = '1', `transaction_id` = '".$transaction_id."' WHERE `punch_date` = '".$act_out_punch_date."' AND `punch_time` = '".$act_outtime."' AND `emp_id` = '".$rvaluess['emp_id']."' ";
									//echo $update;exit;
									$this->db->query($update);
									$this->log->write($update);
								}
							} else {
								$update = "UPDATE `oc_attendance` SET `status` = '1', `transaction_id` = '".$transaction_id."' WHERE `punch_date` = '".$act_in_punch_date."' AND `punch_time` >= '".$act_intime."' AND `emp_id` = '".$rvaluess['emp_id']."' ";
								$this->db->query($update);
								$this->log->write($update);

								$update = "UPDATE `oc_attendance` SET `status` = '1', `transaction_id` = '".$transaction_id."' WHERE `punch_date` = '".$act_out_punch_date."' AND `punch_time` <= '".$act_outtime."' AND `emp_id` = '".$rvaluess['emp_id']."' ";
								$this->db->query($update);
								$this->log->write($update);
							}
						}
					} else {
						$emp_data = $this->getempdata($rvalue['emp_code']);
						if(isset($emp_data['name']) && $emp_data['name'] != ''){
							$emp_name = $emp_data['name'];
							$department = $emp_data['department'];
							$unit = $emp_data['unit'];
							$group = $emp_data['group'];

							$day_date = date('j', strtotime($filter_date_start));
							$month = date('n', strtotime($filter_date_start));
							$year = date('Y', strtotime($filter_date_start));

							$update33 = $this->db->query("SELECT  `".$day_date."` FROM `oc_shift_schedule` WHERE `emp_code` = '".$rvalue['emp_code']."' AND `month` = '".$month."' AND `year` = '".$year."' ");
							//$update3 = "SELECT  `".$day_date."` FROM `oc_shift_schedule` WHERE `month` ='".$month."' AND `year` = '".$year."' AND `emp_code` = '".$rvalue['emp_code']."' ";
							//$shift_schedule = $this->db->query($update3)->num_rows;

							if($update33->num_rows == 0){
									$insert1 = "INSERT INTO `oc_shift_schedule` SET 
										`emp_code` = '".$rvalue['emp_code']."',
										`1` = 'S_1',
										`2` = 'S_1',
										`3` = 'S_1',
										`4` = 'S_1',
										`5` = 'S_1',
										`6` = 'S_1',
										`7` = 'S_1',
										`8` = 'S_1',
										`9` = 'S_1',
										`10` = 'S_1',
										`11` = 'S_1',
										`12` = 'S_1', 
										`13` = 'S_1', 
										`14` = 'S_1', 
										`15` = 'S_1', 
										`16` = 'S_1', 
										`17` = 'S_1', 
										`18` = 'S_1', 
										`19` = 'S_1', 
										`20` = 'S_1', 
										`21` = 'S_1', 
										`22` = 'S_1', 
										`23` = 'S_1', 
										`24` = 'S_1', 
										`25` = 'S_1', 
										`26` = 'S_1', 
										`27` = 'S_1', 
										`28` = 'S_1', 
										`29` = 'S_1', 
										`30` = 'S_1', 
										`31` = 'S_1', 
										`month` = '".$month."',
										`year` = '".$year."',
										`status` = '1' ,
										`unit` = '".$unit."' "; 
									// echo "<pre>";
									// echo $insert1;
									$this->db->query($insert1);
									$update3 = "SELECT  `".$day_date."` FROM `oc_shift_schedule` WHERE `emp_code` = '".$rvalue['emp_code']."' AND `month` = '".$month."' AND `year` = '".$year."' ";
									$shift_schedule = $this->db->query($update3)->row;
									fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- SELECT query 1 -------', true)  . "\n");
									fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r($update3, true)  . "\n");
								
							} else {
								$update3 = "SELECT  `".$day_date."` FROM `oc_shift_schedule` WHERE `emp_code` = '".$rvalue['emp_code']."' AND `month` = '".$month."' AND `year` = '".$year."' ";
								fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- SELECT query 2 -------', true)  . "\n");
								fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r($update3, true)  . "\n");
								$shift_schedule = $this->db->query($update3)->row;

							}


							$schedule_raw = explode('_', $shift_schedule[$day_date]);
							if(!isset($schedule_raw[2])){
								$schedule_raw[2]= 1;
							}
							if($schedule_raw[0] == 'S'){
								$shift_data = $this->getshiftdata($schedule_raw[1]);
								if(isset($shift_data['shift_id'])){
									$shift_intime = $shift_data['in_time'];
									$shift_outtime = $shift_data['out_time'];
									
									$day = date('j', strtotime($filter_date_start));
									$month = date('n', strtotime($filter_date_start));
									$year = date('Y', strtotime($filter_date_start));

									$trans_exist_sql = "SELECT * FROM `oc_transaction` WHERE `emp_id` = '".$rvalue['emp_code']."' AND `date` = '".$filter_date_start."' ";
									$trans_exist = $this->db->query($trans_exist_sql);
									if($trans_exist->num_rows == 0){
										$sql = "INSERT INTO `oc_transaction` SET `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `day` = '".$day."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '0', `secondhalf_status` = '0', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '1', abnormal_status = '0', halfday_status = '0', batch_id = '".$batch_id."' ";
										//echo $sql.';';
										//echo '<br />';
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- insert query 13 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("INSERT INTO `oc_transaction` SET `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `day` = '".$day."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '0', `secondhalf_status` = '0', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '1', abnormal_status = '0', halfday_status = '0', batch_id = '".$batch_id."' ", true)  . "\n");
										$this->db->query($sql);
									} else {
										$sql = "UPDATE `oc_transaction` SET `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `day` = '".$day."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '0', `secondhalf_status` = '0', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '1', abnormal_status = '0', halfday_status = '0', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvalue['emp_code']."' AND `date` = '".$filter_date_start."'";
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- update query 13 -------', true)  . "\n");
										fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("UPDATE `oc_transaction` SET `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `day` = '".$day."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '0', `secondhalf_status` = '0', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '1', abnormal_status = '0', halfday_status = '0', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvalue['emp_code']."' AND `date` = '".$filter_date_start."'", true)  . "\n");
										//echo $sql.';';
										//echo '<br />';
										//$this->db->query($sql);
									}
								} else {
									$shift_data = $this->getshiftdata('1');
									$shift_intime = $shift_data['in_time'];
									$shift_outtime = $shift_data['out_time'];
									
									$day = date('j', strtotime($filter_date_start));
									$month = date('n', strtotime($filter_date_start));
									$year = date('Y', strtotime($filter_date_start));

									$trans_exist_sql = "SELECT * FROM `oc_transaction` WHERE `emp_id` = '".$rvalue['emp_code']."' AND `date` = '".$filter_date_start."' ";
									$trans_exist = $this->db->query($trans_exist_sql);
									if($trans_exist->num_rows == 0){
										$sql = "INSERT INTO `oc_transaction` SET `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `day` = '".$day."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '0', `secondhalf_status` = '0', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '1', abnormal_status = '0', halfday_status = '0', batch_id = '".$batch_id."' ";
										//echo $sql.';';
										//echo '<br />';
										$this->db->query($sql);
									} else {
										$sql = "UPDATE `oc_transaction` SET `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `day` = '".$day."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '0', `secondhalf_status` = '0', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '1', abnormal_status = '0', halfday_status = '0', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvalue['emp_code']."' AND `date` = '".$filter_date_start."' ";
										//echo $sql.';';
										//echo '<br />';
										//$this->db->query($sql);
									}
								}
							} elseif ($schedule_raw[0] == 'W') {
								$shift_data = $this->getshiftdata($schedule_raw[2]);
								if(!isset($shift_data['shift_id'])){
									$shift_data = $this->getshiftdata('1');
								}
								$shift_intime = $shift_data['in_time'];
								$shift_outtime = $shift_data['out_time'];

								$act_intime = '00:00:00';
								$act_outtime = '00:00:00';
								$trans_exist_sql = "SELECT * FROM `oc_transaction` WHERE `emp_id` = '".$rvalue['emp_code']."' AND `date` = '".$filter_date_start."' ";
								$trans_exist = $this->db->query($trans_exist_sql);
								
								if($trans_exist->num_rows == 0){
									$sql = "INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'WO', `secondhalf_status` = 'WO', `weekly_off` = '".$schedule_raw[1]."', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '0', halfday_status = '0', batch_id = '".$batch_id."' ";
									//echo $sql.';';
									//echo '<br />';
									$this->db->query($sql);
								} else {
									$sql = "UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'WO', `secondhalf_status` = 'WO', `weekly_off` = '".$schedule_raw[1]."', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '0', halfday_status = '0', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvalue['emp_code']."' AND `date` = '".$filter_date_start."' ";
									//echo $sql.';';
									//echo '<br />';
									//$this->db->query($sql);
								}
							} elseif ($schedule_raw[0] == 'H') {
								$shift_data = $this->getshiftdata($schedule_raw[2]);
								if(!isset($shift_data['shift_id'])){
									$shift_data = $this->getshiftdata('1');
								}
								$shift_intime = $shift_data['in_time'];
								$shift_outtime = $shift_data['out_time'];

								$act_intime = '00:00:00';
								$act_outtime = '00:00:00';
								
								$trans_exist_sql = "SELECT * FROM `oc_transaction` WHERE `emp_id` = '".$rvalue['emp_code']."' AND `date` = '".$filter_date_start."' ";
								$trans_exist = $this->db->query($trans_exist_sql);
								if($trans_exist->num_rows == 0){
									$sql = "INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'HLD', `secondhalf_status` = 'HLD', `weekly_off` = '0', `holiday_id` = '".$schedule_raw[1]."', `present_status` = '0', `absent_status` = '0', abnormal_status = '0', halfday_status = '0', batch_id = '".$batch_id."'  ";
									//echo $sql.';';
									//echo '<br />';
									$this->db->query($sql);
								} else {
									$sql = "UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'HLD', `secondhalf_status` = 'HLD', `weekly_off` = '0', `holiday_id` = '".$schedule_raw[1]."', `present_status` = '0', `absent_status` = '0', abnormal_status = '0', halfday_status = '0', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvalue['emp_code']."' AND `date` = '".$filter_date_start."' ";
									//echo $sql.';';
									//echo '<br />';
									//$this->db->query($sql);
								}
							} elseif ($schedule_raw[0] == 'HD') {
								$shift_data = $this->getshiftdata($schedule_raw[2]);
								if(!isset($shift_data['shift_id'])){
									$shift_data = $this->getshiftdata('1');
								}
								$shift_intime = $shift_data['in_time'];
								$shift_outtime = Date('H:i:s', strtotime($shift_intime .' +4 hours'));
								//$shift_outtime = $shift_data['out_time'];

								$act_intime = '00:00:00';
								$act_outtime = '00:00:00';
								
								$trans_exist_sql = "SELECT * FROM `oc_transaction` WHERE `emp_id` = '".$rvalue['emp_code']."' AND `date` = '".$filter_date_start."' ";
								$trans_exist = $this->db->query($trans_exist_sql);
								if($trans_exist->num_rows == 0){
									$sql = "INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '0', `secondhalf_status` = '0', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '1', abnormal_status = '0', halfday_status = '".$schedule_raw[1]."', batch_id = '".$batch_id."' ";
									//echo $sql.';';
									//echo '<br />';
									$this->db->query($sql);
								} else {
									$sql = "UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = '0', `secondhalf_status` = '0', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '1', abnormal_status = '0', halfday_status = '".$schedule_raw[1]."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvalue['emp_code']."' AND `date` = '".$filter_date_start."' ";
									//echo $sql.';';
									//echo '<br />';
									//$this->db->query($sql);
								}
							}  elseif ($schedule_raw[0] == 'C') {
								$shift_data = $this->getshiftdata($schedule_raw[2]);
								if(!isset($shift_data['shift_id'])){
									$shift_data = $this->getshiftdata('1');
								}
								$shift_intime = $shift_data['in_time'];
								$shift_outtime = $shift_data['out_time'];

								$act_intime = '00:00:00';
								$act_outtime = '00:00:00';
								
								$trans_exist_sql = "SELECT * FROM `oc_transaction` WHERE `emp_id` = '".$rvalue['emp_code']."' AND `date` = '".$filter_date_start."' ";
								$trans_exist = $this->db->query($trans_exist_sql);
								if($trans_exist->num_rows == 0){
									$sql = "INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'COF', `secondhalf_status` = 'COF', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '0', halfday_status = '0', compli_status = '".$schedule_raw[1]."', batch_id = '".$batch_id."' ";
									fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- iNSErt query 13 -------', true)  . "\n");
									fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("INSERT INTO `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'COF', `secondhalf_status` = 'COF', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '0', halfday_status = '0', compli_status = '".$schedule_raw[1]."', batch_id = '".$batch_id."' ", true)  . "\n");
									//echo $sql.';';
									//echo '<br />';
									$this->db->query($sql);
								} else {
									$sql = "UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'COF', `secondhalf_status` = 'COF', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '0', halfday_status = '0', compli_status = '".$schedule_raw[1]."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvalue['emp_code']."' AND `date` = '".$filter_date_start."' ";
									fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- uPdATe query 14 -------', true)  . "\n");
									fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("UPDATE `oc_transaction` SET `shift_intime` = '".$shift_intime."', `shift_outtime` = '".$shift_outtime."', `emp_id` = '".$rvalue['emp_code']."', `emp_name` = '".$emp_name."', `act_intime` = '".$act_intime."', `act_outtime` = '".$act_outtime."', `day` = '".$day_date."', `month` = '".$month."', `year` = '".$year."', `date` = '".$filter_date_start."', `date_out` = '".$filter_date_start."', `department` = '".$department."', `unit` = '".$unit."', `group` = '".$group."', `firsthalf_status` = 'COF', `secondhalf_status` = 'COF', `weekly_off` = '0', `holiday_id` = '0', `present_status` = '0', `absent_status` = '0', abnormal_status = '0', halfday_status = '0', compli_status = '".$schedule_raw[1]."', batch_id = '".$batch_id."' WHERE `emp_id` = '".$rvalue['emp_code']."' AND `date` = '".$filter_date_start."' ", true)  . "\n");
									//echo $sql.';';
									//echo '<br />';
									//$this->db->query($sql);
								}
							}
							// $update = "UPDATE `oc_attendance` SET `status` = '1' WHERE `punch_date` = '".$filter_date_start."' AND `punch_time` >= '".$act_intime."' AND `punch_time` <= '".$act_outtime."' AND `emp_id` = '".$rvalue['emp_code']."' ";
							fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r('-------- uPdATe query 15 -------', true)  . "\n");
							fwrite($handle, date('Y-m-d G:i:s') . ' - ' . print_r("UPDATE `oc_attendance` SET `status` = '1' WHERE `punch_date` = '".$filter_date_start."' AND `punch_time` >= '".$act_intime."' AND `punch_time` <= '".$act_outtime."' AND `emp_id` = '".$rvalue['emp_code']."' ", true)  . "\n");
							// $this->db->query($update);
							// $this->log->write($update);
						}	
					}
				}

				$this->load->model('transaction/dayprocess');

				$absent = $this->getAbsent($filter_date_start,$filter_unit);
				// echo '<pre>';
				// print_r($absent);
				// exit;
				foreach($absent as $data) {
					$check_leave = $this->checkLeave($data['date'],$data['emp_id']);
				}
				$this->update_close_day($filter_date_start, $filter_unit);
				//$this->db->query("commit;");
				//$response['success'] = 'Transaction Generated';
			//} else {
				//$this->db->query("commit;");
				//$response['warning'] = 'No Data available';
			//}
		}

		$this->load->model('transaction/leaveprocess');
		$this->load->model('transaction/dayprocess');

		if (isset($this->request->get['unit'])) {
			$unit = $this->request->get['unit'];
		} else {
			$unit = '';
		}

		$unprocessed = $this->getUnprocessedLeaveTillDate_2($unit);
		
		foreach($unprocessed as $data) {
			$is_closed = $this->is_closed_stat($data['date'], $data['emp_id']); 
			if($is_closed == 1){
				$this->checkLeave($data['date'], $data['emp_id']);
			}
		}
		//echo 'Done';exit;	
	}

	public function getEmployees_dat($emp_code) {
		$sql = "SELECT * FROM `" . DB_PREFIX . "employee` WHERE `emp_code` = '".$emp_code."'";
		//echo $sql;exit;
		$query = $this->db->query($sql);
		return $query->row;
	}

	public function getorderhistory($data){
		$sql = "SELECT * FROM `" . DB_PREFIX . "attendance` WHERE `punch_date` = '".$data['punch_date']."' AND `punch_time` = '".$data['in_time']."' AND `emp_id` = '".$data['employee_id']."' ";
		$query = $this->db->query($sql);
		if($query->num_rows > 0){
			return 1;
		} else {
			return 0;
		}
	}

	public function insert_attendance_data($data) {
		$sql = $this->db->query("INSERT INTO `oc_attendance` SET `emp_id` = '".$data['employee_id']."', `card_id` = '".$data['card_id']."', `punch_date` = '".$data['punch_date']."', `punch_time` = '".$data['in_time']."', `status` = '0' ");
	}

	public function getemployees($data = array()) {
		$sql = "SELECT `emp_code`, `name`, `department`, `designation`, `unit`, `group` FROM " . DB_PREFIX . "employee WHERE 1=1 ";
		
		if (!empty($data['unit'])) {
			$sql .= " AND LOWER(`unit`) = '" . $this->db->escape(strtolower($data['unit'])) . "'";
		}

		//$sql .= " AND `status` = '1' AND `emp_code` = '22848' ";
		$sql .= " AND `status` = '1' ";
		//echo $sql;exit;
		$sql .= " ORDER BY `shift_type` ";		
		$query = $this->db->query($sql);
		return $query->rows;
	}

	public function getrawattendance_group_date_custom($emp_code, $date) {
		$query = $this->db->query("SELECT `emp_id`, `punch_date`, `card_id`, `manual_status`, `leave`, `holiday`, `weekly_off`, `present`, absent, `device_id` FROM `" . DB_PREFIX . "attendance` WHERE `punch_date` = '".$date."' AND `emp_id` = '".$emp_code."' GROUP by `punch_date` ");
		//$this->log->write("SELECT `emp_id`, `punch_date`, `card_id`, `manual_status`, `leave`, `holiday`, `weekly_off`, `present`, absent FROM `" . DB_PREFIX . "attendance` WHERE `punch_date` = '".$date."' AND `emp_id` = '".$emp_code."' GROUP by `punch_date` ");
		return $query->row;
	}

	public function getempdata($emp_id) {
		$query = $this->db->query("SELECT `name`, `shift`, `weekly_off`, `department`, `unit`, `group`, `shift_type` FROM " . DB_PREFIX . "employee WHERE `emp_code` = '".$emp_id."' ");
		if($query->num_rows > 0){
			return $query->row;
		} else {
			return array();
		}
	}

	public function getshiftdata($shift_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "shift WHERE `shift_id` = '".$shift_id."' ");
		if($query->num_rows > 0){
			return $query->row;
		} else {
			return array();
		}
	}

	public function getrawattendance_in_time($emp_id, $punch_date) {
		$future_date = date('Y-m-d', strtotime($punch_date .' +1 day'));
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "attendance WHERE emp_id = '".$emp_id."' AND (`punch_date` = '".$punch_date."' OR `punch_date` = '".$future_date."') AND `status` = '0' ORDER by date(`punch_date`) ASC, time(`punch_time`) ASC, `id` ASC ");
		$array = $query->row;
		return $array;
	}


	public function getrawattendance_out_time($emp_id, $punch_date, $act_intime, $act_punch_date) {
		$future_date = date('Y-m-d', strtotime($punch_date .' +1 day'));
		if($emp_id == '922'){
			$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "attendance WHERE emp_id = '".$emp_id."' AND (`punch_date` = '".$punch_date."' OR `punch_date` = '".$future_date."') AND `status` = '0' ORDER by date(`punch_date`) ASC, time(`punch_time`) ASC");
		} else {
			$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "attendance WHERE emp_id = '".$emp_id."' AND (`punch_date` = '".$punch_date."') AND `status` = '0' ORDER by date(`punch_date`) ASC, time(`punch_time`) ASC");
		}
		$act_outtime = array();
		if($query->num_rows > 0){
			$first_punch = $query->rows['0'];
			$array = $query->rows;
			$comp_array = array();
			$hour_array = array();
			
			// echo '<pre>';
			// print_r($array);

			foreach ($array as $akey => $avalue) {
				$start_date = new DateTime($act_punch_date.' '.$act_intime);
				$since_start = $start_date->diff(new DateTime($avalue['punch_date'].' '.$avalue['punch_time']));
				if($since_start->d == 0){
					$comp_array[] = $since_start->h.':'.$since_start->i.':'.$since_start->s;
					$hour_array[] = $since_start->h;
					$act_array[] = $avalue;
				}
			}

			// echo '<pre>';
			// print_r($hour_array);

			// echo '<pre>';
			// print_r($comp_array);

			foreach ($hour_array as $ckey => $cvalue) {
				if($cvalue > 18){
					unset($hour_array[$ckey]);
				}
			}

			// echo '<pre>';
			// print_r($hour_array);
			
			$act_outtimes = max($hour_array);

			// echo '<pre>';
			// print_r($act_outtimes);

			foreach ($hour_array as $akey => $avalue) {
				if($avalue == $act_outtimes){
					$act_outtime = $act_array[$akey];
				}
			}
		}
		// echo '<pre>';
		// print_r($act_outtime);
		// exit;		
		return $act_outtime;
	}

	public function getAbsent($date, $unit) {
		//$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "transaction WHERE `date` = '".$date."' AND `unit` = '".$unit."' AND `emp_id` = '21463' AND `absent_status` = '1' ORDER BY `date` ASC");
		$sql = "SELECT * FROM " . DB_PREFIX . "transaction WHERE `date` = '".$date."' AND `absent_status` = '1' ";
		if($unit){
			$sql .= " AND `unit` = '".$unit."' ";
		}
		$sql .= " ORDER BY `date` ASC";
		$query = $this->db->query($sql);
		if(isset($query->rows)) {
			return $query->rows;	
		} else {
			return 0;
		}
	}

	public function checkLeave($date, $emp_id) {
		$this->load->model('transaction/transaction');
		$query = $this->db->query("SELECT * FROM ".DB_PREFIX."leave_transaction WHERE `emp_id` = '".$emp_id."' AND `date` = '".$date."' AND `p_status` = '0' AND `a_status` = '1' ");
		if($query->num_rows > 0) {
			$this->log->write('----start---');
			if($query->row['type'] != ''){
				//echo 'aaaa';exit;
				$trans_data = $this->db->query("SELECT * FROM ".DB_PREFIX."transaction WHERE `emp_id` = '".$emp_id."' AND `date` = '".$date."' ")->row;
				if($query->row['type'] == 'F'){
					$this->db->query("UPDATE " . DB_PREFIX . "transaction SET `firsthalf_status` = '".$query->row['leave_type']."', `secondhalf_status` = '".$query->row['leave_type']."', `leave_status` = '1', absent_status = '0' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");		
					$this->log->write("UPDATE " . DB_PREFIX . "transaction SET `firsthalf_status` = '".$query->row['leave_type']."', `secondhalf_status` = '".$query->row['leave_type']."', `leave_status` = '1', absent_status = '0' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");		
					
					$this->db->query("UPDATE " . DB_PREFIX . "leave_transaction SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' AND `type` = '".$query->row['type']."' ");	
					$this->log->write("UPDATE " . DB_PREFIX . "leave_transaction SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' AND `type` = '".$query->row['type']."' ");
				
					$this->db->query("UPDATE " . DB_PREFIX . "leave_transaction_temp SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' AND `type` = '".$query->row['type']."' ");	
					$this->log->write("UPDATE " . DB_PREFIX . "leave_transaction_temp SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' AND `type` = '".$query->row['type']."' ");
					
				} elseif($query->row['type'] == '1'){
					$this->db->query("UPDATE " . DB_PREFIX . "transaction SET `firsthalf_status` = '".$query->row['leave_type']."', `leave_status` = '0.5' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");			
					$this->log->write("UPDATE " . DB_PREFIX . "transaction SET `firsthalf_status` = '".$query->row['leave_type']."', `leave_status` = '0.5' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");			
					if($trans_data['halfday_status'] != 0){
						$this->db->query("UPDATE " . DB_PREFIX . "transaction SET `secondhalf_status` = 'HD', `absent_status` = '0' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
						$this->log->write("UPDATE " . DB_PREFIX . "transaction SET `secondhalf_status` = 'HD', `absent_status` = '0' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
					} elseif($trans_data['secondhalf_status'] == 'COF'){
						$this->db->query("UPDATE " . DB_PREFIX . "transaction SET `absent_status` = '0', `present_status` = '0', `leave_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
						$this->log->write("UPDATE " . DB_PREFIX . "transaction SET `absent_status` = '0', `present_status` = '0', `leave_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
					} elseif($trans_data['secondhalf_status'] == 1){
						$this->db->query("UPDATE " . DB_PREFIX . "transaction SET `absent_status` = '0', `present_status` = '0.5' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
						$this->log->write("UPDATE " . DB_PREFIX . "transaction SET `absent_status` = '0', `present_status` = '0.5' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
					} elseif($trans_data['secondhalf_status'] == 0){
						$this->db->query("UPDATE " . DB_PREFIX . "transaction SET `absent_status` = '0.5', `present_status` = '0' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
						$this->log->write("UPDATE " . DB_PREFIX . "transaction SET `absent_status` = '0.5', `present_status` = '0' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
					} 
					$this->db->query("UPDATE " . DB_PREFIX . "leave_transaction SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' AND `type` = '".$query->row['type']."' ");	
					$this->log->write("UPDATE " . DB_PREFIX . "leave_transaction SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' AND `type` = '".$query->row['type']."' ");
					
					$this->db->query("UPDATE " . DB_PREFIX . "leave_transaction_temp SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' AND `type` = '".$query->row['type']."' ");	
					$this->log->write("UPDATE " . DB_PREFIX . "leave_transaction_temp SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' AND `type` = '".$query->row['type']."' ");
				
				} elseif($query->row['type'] == '2'){
					$this->db->query("UPDATE " . DB_PREFIX . "transaction SET `secondhalf_status` = '".$query->row['leave_type']."', `leave_status` = '0.5' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");			
					$this->log->write("UPDATE " . DB_PREFIX . "transaction SET `secondhalf_status` = '".$query->row['leave_type']."', `leave_status` = '0.5' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");			
					if($trans_data['halfday_status'] != 0){
						$this->db->query("UPDATE " . DB_PREFIX . "transaction SET `firsthalf_status` = 'HD', `absent_status` = '0' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
						$this->log->write("UPDATE " . DB_PREFIX . "transaction SET `firsthalf_status` = 'HD', `absent_status` = '0' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
					} elseif($trans_data['firsthalf_status'] == 'COF'){
						$this->db->query("UPDATE " . DB_PREFIX . "transaction SET `absent_status` = '0', `present_status` = '0', `leave_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
						$this->log->write("UPDATE " . DB_PREFIX . "transaction SET `absent_status` = '0', `present_status` = '0', `leave_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
					} elseif($trans_data['firsthalf_status'] == 1){
						$this->db->query("UPDATE " . DB_PREFIX . "transaction SET `absent_status` = '0', `present_status` = '0.5' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
						$this->log->write("UPDATE " . DB_PREFIX . "transaction SET `absent_status` = '0', `present_status` = '0.5' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
					} elseif($trans_data['firsthalf_status'] == 0){
						$this->db->query("UPDATE " . DB_PREFIX . "transaction SET `absent_status` = '0.5', `present_status` = '0' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
						$this->log->write("UPDATE " . DB_PREFIX . "transaction SET `absent_status` = '0.5', `present_status` = '0' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");
					}
					$this->db->query("UPDATE " . DB_PREFIX . "leave_transaction SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' AND `type` = '".$query->row['type']."' ");	
					$this->log->write("UPDATE " . DB_PREFIX . "leave_transaction SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' AND `type` = '".$query->row['type']."' ");

					$this->db->query("UPDATE " . DB_PREFIX . "leave_transaction_temp SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' AND `type` = '".$query->row['type']."' ");	
					$this->log->write("UPDATE " . DB_PREFIX . "leave_transaction_temp SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' AND `type` = '".$query->row['type']."' ");
				}
					
				$sql = "SELECT * FROM `oc_leave` WHERE `emp_id` = '".$emp_id."' AND `close_status` = '0' ";
				$query1 = $this->db->query($sql);
				if($query1->num_rows > 0){
					if($query->row['leave_type'] == 'PL'){
						//$balance = $query1->row['pl_bal'];

						$total_bal = $this->gettotal_bal($emp_id);
						$total_bal_pro = $this->gettotal_bal_pro($emp_id, 'PL');
						$total_bal_pro1 = $this->gettotal_bal_pro1($emp_id, 'PL');
						$total_bal_pl = 0;
						if(isset($total_bal['pl_acc'])){
							if(isset($total_bal_pro['bal_p'])){
								$total_bal_pl = $total_bal['pl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro['encash'] + $total_bal_pro1['leave_amount']);
							} else {
								$total_bal_pl = $total_bal['pl_acc'];
							}
						}

						$balance = $total_bal_pl - $query->row['leave_amount'];
						$upd_bal_sql = "UPDATE `oc_leave` SET `pl_bal` = '".$balance."' WHERE `emp_id` = '".$emp_id."' AND `close_status` = '0' ";
						$this->db->query($upd_bal_sql);
						$this->log->write($upd_bal_sql);
					} elseif($query->row['leave_type'] == 'CL'){
						//$balance = $query1->row['cl_bal'];
						
						$total_bal = $this->gettotal_bal($emp_id);
						$total_bal_pro = $this->gettotal_bal_pro($emp_id, 'CL');
						$total_bal_pro1 = $this->gettotal_bal_pro1($emp_id, 'CL');
						$total_bal_cl = 0;
						if(isset($total_bal['cl_acc'])){
							if(isset($total_bal_pro['bal_p'])){
								$total_bal_cl = $total_bal['cl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
							} else {
								$total_bal_cl = $total_bal['cl_acc'];
							}
						}

						$balance = $total_bal_cl - $query->row['leave_amount'];
						$upd_bal_sql = "UPDATE `oc_leave` SET `cl_bal` = '".$balance."' WHERE `emp_id` = '".$emp_id."' AND `close_status` = '0' ";
						$this->db->query($upd_bal_sql);
						$this->log->write($upd_bal_sql);
					} elseif($query->row['leave_type'] == 'SL'){
						//$balance = $query1->row['sl_bal'];
						
						$total_bal = $this->gettotal_bal($emp_id);
						$total_bal_pro = $this->gettotal_bal_pro($emp_id, 'SL');
						$total_bal_pro1 = $this->gettotal_bal_pro1($emp_id, 'SL');
						$total_bal_sl = 0;
						if(isset($total_bal['sl_acc'])){
							if(isset($total_bal_pro['bal_p'])){
								$total_bal_sl = $total_bal['sl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
							} else {
								$total_bal_sl = $total_bal['sl_acc'];
							}
						}

						$balance = $total_bal_sl - $query->row['leave_amount'];
						$upd_bal_sql = "UPDATE `oc_leave` SET `sl_bal` = '".$balance."' WHERE `emp_id` = '".$emp_id."' AND `close_status` = '0' ";
						$this->db->query($upd_bal_sql);
						$this->log->write($upd_bal_sql);
					} 
				}
			} else {
				$this->db->query("UPDATE " . DB_PREFIX . "transaction SET `firsthalf_status` = '".$query->row['leave_type']."', `secondhalf_status` = '".$query->row['leave_type']."', `leave_status` = '1', absent_status = '0', `present_status` = '0' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");		
				$this->log->write("UPDATE " . DB_PREFIX . "transaction SET `firsthalf_status` = '".$query->row['leave_type']."', `secondhalf_status` = '".$query->row['leave_type']."', `leave_status` = '1', absent_status = '0', `present_status` = '0' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");		
				
				$this->db->query("UPDATE " . DB_PREFIX . "leave_transaction SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");		
				$this->log->write("UPDATE " . DB_PREFIX . "leave_transaction SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."'");		
				
				$this->db->query("UPDATE " . DB_PREFIX . "leave_transaction_temp SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' ");	
				$this->log->write("UPDATE " . DB_PREFIX . "leave_transaction_temp SET `p_status` = '1' WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' ");

				$sql = "SELECT * FROM `oc_leave` WHERE `emp_id` = '".$emp_id."' AND `close_status` = '0' ";
				$query1 = $this->db->query($sql);
				if($query1->num_rows > 0){
					if($query->row['leave_type'] == 'PL'){
						//echo 'in pl';exit;
						//$balance = $query1->row['pl_bal'];
						
						$total_bal = $this->gettotal_bal($emp_id);
						$total_bal_pro = $this->gettotal_bal_pro($emp_id, 'PL');
						$total_bal_pro1 = $this->gettotal_bal_pro1($emp_id, 'PL');
						$total_bal_pl = 0;
						if(isset($total_bal['pl_acc'])){
							if(isset($total_bal_pro['bal_p'])){
								$total_bal_pl = $total_bal['pl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro['encash'] + $total_bal_pro1['leave_amount']);
							} else {
								$total_bal_pl = $total_bal['pl_acc'];
							}
						}

						$balance = $total_bal_pl - 1;
						$upd_bal_sql = "UPDATE `oc_leave` SET `pl_bal` = '".$balance."' WHERE `emp_id` = '".$emp_id."' AND `close_status` = '0' ";
						$this->db->query($upd_bal_sql);
						$this->log->write($upd_bal_sql);
					} elseif($query->row['leave_type'] == 'CL'){
						//echo 'in cl';exit;
						//$balance = $query1->row['cl_bal'];
						
						$total_bal = $this->gettotal_bal($emp_id);
						$total_bal_pro = $this->gettotal_bal_pro($emp_id, 'CL');
						$total_bal_pro1 = $this->gettotal_bal_pro1($emp_id, 'CL');
						$total_bal_cl = 0;
						if(isset($total_bal['cl_acc'])){
							if(isset($total_bal_pro['bal_p'])){
								$total_bal_cl = $total_bal['cl_acc'] - ($total_bal_pro['bal_p'] - $total_bal_pro1['leave_amount']);
							} else {
								$total_bal_cl = $total_bal['cl_acc'];
							}
						}

						$balance = $total_bal_cl - 1;
						$upd_bal_sql = "UPDATE `oc_leave` SET `cl_bal` = '".$balance."' WHERE `emp_id` = '".$emp_id."' AND `close_status` = '0' ";
						$this->db->query($upd_bal_sql);
						$this->log->write($upd_bal_sql);
					} elseif($query->row['leave_type'] == 'SL'){
						//$balance = $query1->row['sl_bal'];
						
						$total_bal = $this->gettotal_bal($emp_id);
						$total_bal_pro = $this->gettotal_bal_pro($emp_id, 'SL');
						$total_bal_pro1 = $this->gettotal_bal_pro1($emp_id, 'SL');
						// echo '<pre>';
						// print_r($total_bal);

						// echo '<pre>';
						// print_r($total_bal_pro);


						$total_bal_sl = 0;
						if(isset($total_bal['sl_acc'])){
							if(isset($total_bal_pro['bal_p'])){
								$total_bal_sl = $total_bal['sl_acc'] - ($total_bal_pro['bal_p'] + $total_bal_pro1['leave_amount']);
							} else {
								$total_bal_sl = $total_bal['sl_acc'];
							}
						}

						// echo $total_bal_sl;
						// echo '<br />';
						

						$balance = $total_bal_sl - 1;

						// echo $balance;
						// exit;

						$upd_bal_sql = "UPDATE `oc_leave` SET `sl_bal` = '".$balance."' WHERE `emp_id` = '".$emp_id."' AND `close_status` = '0' ";
						$this->db->query($upd_bal_sql);
						$this->log->write($upd_bal_sql);
					} 
				}	
			}
			$this->log->write('----end---');
			//echo 'out';exit;
			//return $query->rows;	
		} else {
			return 0;
		}	
	}

	public function update_close_day($date, $unit) {
		$sql = "UPDATE " . DB_PREFIX . "transaction SET `day_close_status` = '1' WHERE `date` = '".$date."' ";
		if($unit){
			$sql .= " AND `unit` = '".$unit."' ";
		}
		$this->db->query($sql);
	}

	public function getUnprocessedLeaveTillDate_2($unit) {
		$sql = "SELECT lt.*, (SELECT e.name FROM `oc_employee` e WHERE e.emp_code = lt.emp_id ) AS ename FROM " . DB_PREFIX . "leave_transaction lt WHERE lt.p_status = '0' AND (lt.a_status = '1') ";
		if($unit){
			$sql .= " AND lt.`unit` = '".$unit."' ";
		}
		$data = $this->db->query($sql);
		if($data->rows) {
			return $data->rows;
		} else {
			return array();
		}
	}

	public function is_closed_stat($date, $emp_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "transaction WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' AND `day_close_status` = '1' ");
		//echo "SELECT * FROM " . DB_PREFIX . "transaction WHERE `date` = '".$date."' AND `emp_id` = '".$emp_id."' AND `day_close_status` = '1' ";
		if($query->num_rows > 0) {
			return 1;	
		} else {
			return 0;
		}
	}

	public function gettotal_bal($emp_code) {
		$sql = "SELECT `pl_bal`, `cl_bal`, `sl_bal`, `pl_acc`, `cl_acc`, `sl_acc`, `cof_acc` FROM `oc_leave` WHERE `emp_id` = '".$emp_code."' AND `close_status` = '0' ";
		$query = $this->db->query($sql);
		return $query->row;
	}

	public function gettotal_bal_p($emp_code, $type) {
		$sql = "SELECT COUNT(*) as `bal_p`, encash FROM `oc_leave_transaction` WHERE `emp_id` = '" . $emp_code . "' AND `leave_amount`= '' AND `leave_type`= '".$type."' AND (`p_status` = '0') AND `a_status` = '1' ";
		//echo $sql;exit;
		//$sql .= " AND `a_status` = '1' AND `p_status` = '0' GROUP BY batch_id ";
		$query = $this->db->query($sql);
		return $query->row;
	}

	public function gettotal_bal_p1($emp_code, $type) {
		$sql = "SELECT SUM(`leave_amount`) as leave_amount FROM `oc_leave_transaction` WHERE `emp_id` = '" . $emp_code . "' AND `days` = '' AND `leave_type`= '".$type."' AND (`p_status` = '0') AND `a_status` = '1' ";
		//echo $sql;exit;
		//$sql .= " AND `a_status` = '1' AND `p_status` = '0' GROUP BY batch_id ";
		$query = $this->db->query($sql);
		return $query->row;
	}

	public function gettotal_bal_pro($emp_code, $type) {
		$sql = "SELECT `year` FROM `oc_leave` WHERE `emp_id` = '".$emp_code."' AND `close_status` = '0' ";
		//$this->log->write($sql);
		$query = $this->db->query($sql);
		$year = $query->row['year'];
		$comp_date = $year.'-01-01';
		$sql = "SELECT COUNT(*) as `bal_p`, `encash` FROM `oc_leave_transaction` WHERE `emp_id` = '" . $emp_code . "' AND `leave_amount` = '' AND `leave_type`= '".$type."' AND (`p_status` = '1') AND `a_status` = '1' AND date(`date`) >= '".$comp_date."' ";
		//echo $sql;exit;
		//$sql .= " AND `a_status` = '1' AND `p_status` = '0' GROUP BY batch_id ";
		$query = $this->db->query($sql);
		return $query->row;
	}

	public function gettotal_bal_pro1($emp_code, $type) {
		$sql = "SELECT `year` FROM `oc_leave` WHERE `emp_id` = '".$emp_code."' AND `close_status` = '0' ";
		//$this->log->write($sql);
		$query = $this->db->query($sql);
		$year = $query->row['year'];
		$comp_date = $year.'-01-01';
		$sql = "SELECT SUM(`leave_amount`) as leave_amount FROM `oc_leave_transaction` WHERE `emp_id` = '" . $emp_code . "' AND `days` = '' AND `leave_type`= '".$type."' AND (`p_status` = '1') AND `a_status` = '1' AND date(`date`) >= '".$comp_date."' ";
		//echo $sql;exit;
		//$sql .= " AND `a_status` = '1' AND `p_status` = '0' GROUP BY batch_id ";
		$query = $this->db->query($sql);
		return $query->row;
	}

	public function db_query($sql) {
		$query = $this->link->query($sql);

		if (!$this->link->errno){
			if (isset($query->num_rows)) {
				$data = array();

				while ($row = $query->fetch_assoc()) {
					$data[] = $row;
				}

				$result = new stdClass();
				$result->num_rows = $query->num_rows;
				$result->row = isset($data[0]) ? $data[0] : array();
				$result->rows = $data;

				unset($data);

				$query->close();

				return $result;
			} else{
				return true;
			}
		} else {
			throw new ErrorException('Error: ' . $this->link->error . '<br />Error No: ' . $this->link->errno . '<br />' . $sql);
			exit();
		}
	}

	public function sortByOrder($a, $b) {
		$v1 = strtotime($a['fdate']);
	   	$v2 = strtotime($b['fdate']);
	   	return $v1 - $v2; // $v2 - $v1 to reverse direction
		// if ($a['punch_date'] == $b['punch_date']) {
	 		//return ($a['in_time'] > $b['in_time']) ? -1 : 1;;
	 	//}
	 	//return $a['punch_date'] - $b['punch_date'];
	}

	public function GetDays($sStartDate, $sEndDate){  
		// Firstly, format the provided dates.  
		// This function works best with YYYY-MM-DD  
		// but other date formats will work thanks  
		// to strtotime().  
		$sStartDate = date("Y-m-d", strtotime($sStartDate));  
		$sEndDate = date("Y-m-d", strtotime($sEndDate));  
		// Start the variable off with the start date  
		$aDays[] = $sStartDate;  
		// Set a 'temp' variable, sCurrentDate, with  
		// the start date - before beginning the loop  
		$sCurrentDate = $sStartDate;  
		// While the current date is less than the end date  
		while($sCurrentDate < $sEndDate){  
		// Add a day to the current date  
		$sCurrentDate = date("Y-m-d", strtotime("+1 day", strtotime($sCurrentDate)));  
			// Add this new day to the aDays array  
		$aDays[] = $sCurrentDate;  
		}
		// Once the loop has finished, return the  
		// array of days.  
		return $aDays;  
	}

	public function array_sort($array, $on, $order=SORT_ASC){

	    $new_array = array();
	    $sortable_array = array();

	    if (count($array) > 0) {
	        foreach ($array as $k => $v) {
	            if (is_array($v)) {
	                foreach ($v as $k2 => $v2) {
	                    if ($k2 == $on) {
	                        $sortable_array[$k] = $v2;
	                    }
	                }
	            } else {
	                $sortable_array[$k] = $v;
	            }
	        }

	        switch ($order) {
	            case SORT_ASC:
	                asort($sortable_array);
	                break;
	            case SORT_DESC:
	                arsort($sortable_array);
	                break;
	        }

	        foreach ($sortable_array as $k => $v) {
	            $new_array[$k] = $array[$k];
	        }
	    }

	    return $new_array;
	}
}
?>