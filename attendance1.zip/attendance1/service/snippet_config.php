<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'db_attendance_blank');
define('DB_PREFIX', 'oc_');
define('DIR_SYSTEM', 'C:\xampp\htdocs\attendance/system/');
?>