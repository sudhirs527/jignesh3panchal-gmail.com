<?php
/*
Plugin Name: WFH, Rota system for PL
Description: A custom plugin for interacting with a custom REST API.
Site url: https://wewant360.com/
Author: Wewant360
Author URI: https://wewant360.com/
*/
?>

<?php
function isHoliday($date,$holidays=array()) {
   
    return in_array($date, $holidays);
}

function isLeave($date,$leaves=array()) {
    
    return in_array($date, $leaves);
}

function isWeekend($date) {
   
    $dayOfWeek = date('N', strtotime($date));
    return ($dayOfWeek == 5 || $dayOfWeek == 1); // Friday or Monday
}

function isBeforeOrAfterHoliday($date, $holidays) {
   
    $previousDay = date('Y-m-d', strtotime($date . ' -1 day'));
    $nextDay = date('Y-m-d', strtotime($date . ' +1 day'));
    return isHoliday($previousDay, $holidays) || isHoliday($nextDay, $holidays);
}
function isBeforeOrAfterLeave($date, $leaves) {
  
    $previousDay = date('Y-m-d', strtotime($date . ' -1 day'));
    $nextDay = date('Y-m-d', strtotime($date . ' +1 day'));
    return isLeave($previousDay, $leaves) || isLeave($nextDay, $leaves);
}
?>